﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.Model.Main
{
    public partial class City
    {
        //public City(GeoBoundary input)
        //{
        //    this.GeoBoundary = input;
        //}
        //public City(string code, string description)
        //{
        //    this.GeoBoundary = new GeoBoundary()
        //    {
        //        idgeobou = Guid.NewGuid().ToString(),
        //        geocode = code,
        //        description = description,
        //    };
        //}
        //public void setParent(City ParentCity)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = ParentCity.GeoBoundary;
        //    this.GeoBoundary.idparent = ParentCity.GeoBoundary.idgeobou;
        //}
        //public void setProvince(Province ProvinceParent)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = ProvinceParent.GeoBoundary;
        //    this.GeoBoundary.idparent = ProvinceParent.GeoBoundary.idgeobou;

        //}

        //public void setParent(GeoBoundary geoParent)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = geoParent;
        //    this.GeoBoundary.idparent = geoParent.idgeobou;

        //}
    }
}
