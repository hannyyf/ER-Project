﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.Model.Main
{
    public partial class District
    {
        //public District(GeoBoundary input)
        //{
        //    this.GeoBoundary = input;
        //}
        //public District(string code, string description)
        //{
        //    this.GeoBoundary = new GeoBoundary()
        //    {
        //        idgeobou = Guid.NewGuid().ToString(),
        //        geocode = code,
        //        description = description,
        //    };
        //}

        //public void setParrentCity(City ParentVillage)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = ParentVillage.GeoBoundary;
        //    this.GeoBoundary.idparent = ParentVillage.GeoBoundary.idgeobou;
        //}
    }
}
