﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.Model.Main
{
    public partial class Province
    {
        //public Province(GeoBoundary input)
        //{
        //    this.GeoBoundary = input;
        //}

        //public Province(string code, string description)
        //{
        //    this.GeoBoundary = new GeoBoundary()
        //    {
        //        idgeobou = Guid.NewGuid().ToString(),
        //        geocode = code,
        //        description = description,
        //        //idgeoboutype = 10,
        //    };
        //}

        //public void setParrentCity(City ParentCity)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = ParentCity.GeoBoundary;
        //    this.GeoBoundary.idparent = ParentCity.GeoBoundary.idgeobou;
        //}
    }
}
