﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DMS.Model.Main
{
    public partial class Village
    {
        //public Village(GeoBoundary input)
        //{
        //    this.GeoBoundary = input;
        //}

        //public Village(string code, string description)
        //{
        //    this.GeoBoundary = new GeoBoundary()
        //    {
        //        idgeobou = Guid.NewGuid().ToString(),
        //        geocode = code,
        //        description = description,
        //        //idgeoboutype = 10,
        //    };
        //}

        //public void setParrentDistrict(District ParentCity)
        //{
        //    this.GeoBoundary.GeoBoundaryParrent = ParentCity.GeoBoundary;
        //    this.GeoBoundary.idparent = ParentCity.GeoBoundary.idgeobou;
        //}
    }
}
