namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("agreement")]
    public partial class Agreement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Agreement()
        //{
        //    agreement_status = new HashSet<agreement_status>();
        //    agreement_item = new HashSet<agreement_item>();
        //    agreement_role = new HashSet<agreement_role>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idagreement { get; set; }

        [ForeignKey("AgreementType")]
        public int? idagrtyp { get; set; }
        public AgreementType AgreementType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<AgreementStatus>AgreementStatus { get; set; }
        public ICollection<AgreementRole> AgreementRole { get; set; }
        public ICollection<AgreementItem> AgreementItem { get; set; }

    }
}
