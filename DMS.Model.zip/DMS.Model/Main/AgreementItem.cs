namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("agreement_item")]
    public partial class AgreementItem
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public AgreementItem()
        //{
        //    price_component = new HashSet<price_component>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idagrite { get; set; }

        [ForeignKey("Agreement")]
        [MaxLength(16)]
        public byte[] idagreement { get; set; }
        public Agreement Agreement { get; set; }

        //public virtual Agreement agreement { get; set; }
        public ICollection<PriceComponent> PriceComponents { get; set; }
    }
}
