namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("agreement_role")]
    public partial class AgreementRole
    {
        [Key]
        [MaxLength(16)]
        public byte[] idrole { get; set; }

        [ForeignKey("Agreement")]
        [MaxLength(16)]
        public byte[] idagreement { get; set; }
        public Agreement Agreement { get; set; }

        [ForeignKey ("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }


    }
}
