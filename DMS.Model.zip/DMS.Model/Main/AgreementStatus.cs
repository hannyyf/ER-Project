namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("agreement_status")]
    public partial class AgreementStatus
    {
        [Key]
        [MaxLength(16)]
        public byte[] idstatus { get; set; }

        [ForeignKey("Agreement")]
        [MaxLength(16)]
        public byte[] idagreement { get; set; }
        public Agreement Agreement { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [ForeignKey("ReasonType")]
        public int? idreason { get; set; }
        public ReasonType ReasonType { get; set; } // di gambar erd dari reason bukan reason type

        [StringLength(300)]
        public string reason { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

    }
}
