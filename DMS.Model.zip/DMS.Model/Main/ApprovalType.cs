namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("approval_type")]
    public partial class ApprovalType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public ApprovalType()
        //{
        //    approvals = new HashSet<Approval>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idapptyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Approval> Approvals { get; set; }
    }
}
