namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("association_type")]
    public partial class AssociationType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public association_type()
        //{
        //    product_association = new HashSet<product_association>();
        //}

        [Key]
        public int idasstyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<ProductAssociation> ProductAssociation { get; set; }
    }
}
