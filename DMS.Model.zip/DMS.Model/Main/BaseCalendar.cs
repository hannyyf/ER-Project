namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("base_calendar")]
    public partial class BaseCalendar
    {

        [Key]
        public int idcalendar { get; set; }

        [ForeignKey("BaseCalendarParrent")]
        public int? idparent { get; set; }
        public BaseCalendar BaseCalendarParrent { get; set; }

        [ForeignKey("CalendarType")]
        public int? idcaltyp { get; set; }
        public CalendarType CalendarType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtkey { get; set; }

        [StringLength(5)]
        public string workday { get; set; }

        public int? seqnum { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<BookingSlot> BookingSlot { get; set; }

        //public standard_calendar StandardCalendar { get; set; }
    }
}
