namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("bill_to")]
    public partial class BillTo
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public BillTo()
        //{
        //    billing_disbursement = new HashSet<billing_disbursement>();
        //    billing_receipt = new HashSet<BillingReceipt>();
        //    customer_order = new HashSet<customer_order>();
        //    disbursements = new HashSet<disbursement>();
        //    receipts = new HashSet<receipt>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    vendor_order = new HashSet<vendor_order>();
        //}

        [Key]
        [StringLength(30)]
        public string idbillto { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        //public virtual party_role_type party_role_type { get; set; }
        //public virtual customer_bill_to customer_bill_to { get; set; }
        //public virtual internal_bill_to internal_bill_to { get; set; }
        //public virtual vendor_bill_to vendor_bill_to { get; set; }

        public ICollection<BillingDisbursement> BillingDisbursement { get; set; }

        public ICollection<BillingReceipt> BillingReceipt { get; set; }

        public ICollection<CustomerOrder> CustomerOrder { get; set; }

        public ICollection<Disbursement> Disbursements { get; set; }

        public ICollection<Receipt> Receipts { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }

        public ICollection<VendorOrder> VendorOrder { get; set; }
    }
}
