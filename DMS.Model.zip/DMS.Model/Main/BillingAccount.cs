namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("billing_account")]
    public partial class BillingAccount
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public BillingAccount()
        //{
        //    billing_receipt = new HashSet<BillingReceipt>();
        //    billing_disbursement = new HashSet<billing_disbursement>();
        //    payment_application = new HashSet<payment_application>();
        //}
        
        [Key]
        public int idbilacc { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<BillingReceipt> BillingReceipt { get; set; }
        public ICollection<BillingDisbursement> BillingDisbursement { get; set; }
        public ICollection<PaymentApplication> PaymentApplication { get; set; }
    }
}
