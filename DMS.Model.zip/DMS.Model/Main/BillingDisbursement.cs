namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("billing_disbursement")]
    public partial class BillingDisbursement
    {
        [Key]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }

        [ForeignKey("BillingAccount")]
        public int? idbilacc { get; set; }
        public BillingAccount BillingAccount { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
        public BillTo BillTo { get; set; }
        

    }
}
