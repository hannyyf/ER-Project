namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("billing_item")]
    public partial class BillingItem
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public BillingItem()
        //{
        //    pkb_part_billing_item = new HashSet<pkb_part_billing_item>();
        //    pkb_service_billing_item = new HashSet<pkb_service_billing_item>();
        //    order_item = new HashSet<order_item>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idbilite { get; set; }

        [ForeignKey("Billing")]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        public Billing Billing { get; set; }

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        [ForeignKey("WeType")]
        public int? idwetyp { get; set; }
        public WeType WeType { get; set; }

        //[ForeignKey("BillingItemType2")]
        //public int? idbilitetyp { get; set; }
        //public BillingItemType BillingItemType2;

        [ForeignKey("Feature")]
        public int? idfeature { get; set; }
        public Feature Feature { get; set; }

        [StringLength(50)]
        public string itemdescription { get; set; }

        public decimal? qty { get; set; }

        public decimal? baseprice { get; set; }

        public decimal? unitprice { get; set; }

        public decimal? discount { get; set; }

        public decimal? taxamount { get; set; }

        public decimal? totalamount { get; set; }

        
    }
}
