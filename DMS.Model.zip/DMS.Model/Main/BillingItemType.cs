namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("billing_item_type")]
    public partial class BillingItemType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public billing_item_type()
        //{
        //    billing_item = new HashSet<BillingItem>();
        //}

        [Key]
        public int idbilitetyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<BillingItem> BillingItem { get; set; }
    }
}
