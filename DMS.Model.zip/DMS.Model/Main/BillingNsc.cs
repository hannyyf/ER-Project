namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("billing_nsc")]
    public partial class BillingNsc :Billing
    {
        //[ForeignKey("Billing")]
        //[MaxLength(16)]
        //public byte[] idbilling { get; set; }
        //public virtual Billing Billing { get; set; }

        [Required]
        [StringLength(10)]
        public string NoNsc { get; set; }

        [Column(TypeName = "money")]
        public decimal? totalbaseprice { get; set; }

        [Column(TypeName = "money")]
        public decimal? totaltaxamount { get; set; }

        [Column(TypeName = "money")]
        public decimal? mischarge { get; set; }

        [Column(TypeName = "money")]
        public decimal? totalunitprice { get; set; }

        [Column(TypeName = "money")]
        public decimal? totaldiscount { get; set; }

        [Column(TypeName = "money")]
        public decimal? grandtotalamount { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        
    }
}
