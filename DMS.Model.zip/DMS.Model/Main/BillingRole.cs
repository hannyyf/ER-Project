namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("billing_role")]
    public partial class BillingRole
    {
        [Key]
        [MaxLength(16)]
        public byte[] idrole { get; set; }

        [ForeignKey("Billing")]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        public Billing Billing { get; set; }

        [ForeignKey("Roltype")]
        public int? idroletype { get; set; }
        public RoleType Roltype { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

    }
}
