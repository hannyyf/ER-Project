namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("billing_type")]
    public partial class BillingType
    {
      
        [Key]
        public int idbiltyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Billing>Billings { get; set; }
    }
}
