namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class BookingSlot
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public booking_slot()
        //{
        //    work_order_booking = new HashSet<work_order_booking>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idbooslo { get; set; }

        [ForeignKey("BaseCalendar")]
        public int? idcalendar { get; set; }
        public BaseCalendar BaseCalendar { get; set; }

        [ForeignKey("BookingSlotStandard")]
        [MaxLength(16)]
        public byte[] idbooslostd { get; set; }
        public BookingSlotStandard BookingSlotStandard { get; set; }

        [StringLength(30)]
        public string slotnumber { get; set; }

        public ICollection<WorkOrderBooking> WorkOrderBooking { get; set; }
    }
}
