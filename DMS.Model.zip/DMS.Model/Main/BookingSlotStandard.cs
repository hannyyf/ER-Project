namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("booking_slot_standard")]
    public partial class BookingSlotStandard
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public booking_slot_standard()
        //{
        //    booking_slot = new HashSet<BookingSlot>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idbooslostd { get; set; }

        [ForeignKey("BookingType")]
        public int? idboktyp { get; set; }
        public BookingType BookingType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public int? capacity { get; set; }

        public int? starthour { get; set; }

        public int? startminute { get; set; }

        public int? endhour { get; set; }

        public int? endminute { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        public ICollection<BookingSlot> BookingSlot { get; set; }
        
    }
}
