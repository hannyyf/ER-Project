namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("booking_status")]
    public partial class BookingStatus
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public booking_status()
        //{
        //    bookings = new HashSet<Booking>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdBookingStatus { get; set; }

        [StringLength(30)]
        public string Description { get; set; }

        public ICollection<Booking> Bookings { get; set; }
    }
}
