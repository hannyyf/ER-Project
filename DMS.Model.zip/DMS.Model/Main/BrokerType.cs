namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("broker_type")]
    public partial class BrokerType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public broker_type()
        //{
        //    sales_broker = new HashSet<sales_broker>();
        //}

        [Key]
        public int idbrotyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }
        public ICollection<SalesBroker> SalesBroker { get; set; }
    }
}
