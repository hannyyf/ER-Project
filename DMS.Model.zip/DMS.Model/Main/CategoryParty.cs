namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("category_party")]
    public partial class CategoryParty
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public category_party()
        //{
        //    branches = new HashSet<branch>();
        //    customers = new HashSet<Customer>();
        //    price_component = new HashSet<PriceComponent>();
        //    parties = new HashSet<Party>();
        //}

        [Key]
        public int idcategory { get; set; }

        [ForeignKey("CategoryType")]
        public int? idcattyp { get; set; }
        public CategoryType CategoryType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [StringLength(30)]
        public string refkey { get; set; }

        public ICollection<Branch> Branch { get; set; }
        public ICollection<Customer> Customer { get; set; }
        public ICollection<PriceComponent> PriceComponent { get; set; }
        public ICollection<Party> Parties { get; set; }

    }
}
