namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("category_product")]
    public partial class CategoryProduct
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idcategory { get; set; }

        [ForeignKey("CategoryType")]
        public int? idcattyp { get; set; }
        public CategoryType CategoryType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [StringLength(30)]
        public string refkey { get; set; }

        public ICollection<Summary> Summary { get; set; }
        public ICollection<PriceComponent> PriceComponent { get; set; }
        public ICollection<Product> Products { get; set; }
        
    }
}
