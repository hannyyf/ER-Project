namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("category_type")]
    public partial class CategoryType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public CategoryType()
        //{
        //    categories = new HashSet<category>();
        //    category_party = new HashSet<category_party>();
        //    category_product = new HashSet<category_product>();
        //    category_type1 = new HashSet<CategoryType>();
        //}

        [Key]
        public int idcattyp { get; set; }

        [ForeignKey("CategoryTypeParrent")]
        public int? idparent { get; set; }
        public CategoryType CategoryTypeParrent { get; set; }

        [ForeignKey("RuleType")]
        public int? idrultyp { get; set; }
        public RuleType RuleType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<CategoryParty> CategoryParty { get; set; }
        public ICollection<Category> Category { get; set; }
        public  ICollection <CategoryProduct>CategoryProduct { get; set; }
        public ICollection<CategoryType> CategoryType1 { get; set; }
    }
}
