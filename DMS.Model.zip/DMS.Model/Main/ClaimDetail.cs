namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("claim_detail")]
    public partial class ClaimDetail
    {
        [Key]
        public int IdClaim { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }

        [ForeignKey("SympthomDataM")]
        public int? IdSympthomDataM { get; set; }
        public SympthomDataM SympthomDataM { get; set; }

        [ForeignKey("DataDamage")]
        public int? IdDataDamage { get; set; }
        public DataDamage DataDamage { get; set; }

        public int NoClaim { get; set; }

        [StringLength(5)]
        public string ClaimType { get; set; }

        [StringLength(20)]
        public string StatusClaim { get; set; }

        [StringLength(20)]
        public string NoTicket { get; set; }

        [StringLength(20)]
        public string SubmissionGroup_ { get; set; }

        [StringLength(30)]
        public string NoLkh { get; set; }

        public DateTime? DateLkh { get; set; }

        public DateTime? NoHo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DateHo { get; set; }

        [StringLength(5)]
        public string NoType { get; set; }

        [StringLength(30)]
        public string MarketName { get; set; }

        public DateTime? DateBuy { get; set; }

        [StringLength(15)]
        public string NoProduction { get; set; }

        public DateTime? BrokenDate { get; set; }

        public int? KmBroken { get; set; }

        public DateTime? ServiceDate { get; set; }

        [StringLength(1)]
        public string Rank { get; set; }

        public DateTime? FinishDate { get; set; }

        [StringLength(100)]
        public string AnalysisResult { get; set; }

        [Column(TypeName = "money")]
        public decimal? Amount { get; set; }

        public bool? MainPart { get; set; }

        [Column(TypeName = "money")]
        public decimal? DSubtotalJob { get; set; }

        public DateTime? TransferDate { get; set; }

        [Column(TypeName = "money")]
        public decimal? NominalTransfer { get; set; }

        [StringLength(15)]
        public string NoDocs { get; set; }

        [StringLength(10)]
        public string Replace { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        
    }
}
