namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("communication_event")]
    public partial class CommunicationEvent
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public communication_event()
        //{
        //    communication_event_status = new HashSet<communication_event_status>();
        //    communication_event_role = new HashSet<communication_event_role>();
        //    purpose_type = new HashSet<PurposeType>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idcomevt { get; set; }

        [ForeignKey("PartyRelationship")]
        [MaxLength(16)]
        public byte[] idparrel { get; set; }
        public PartyRelationship PartyRelationship { get; set; }

        [ForeignKey("EventType")]
        public int? idevetyp { get; set; }
        public EventType EventType { get; set; }

        [StringLength(300)]
        public string note { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<CommunicationEventStatus> CommunicationEventStatus { get; set; }
        public ICollection<CommunicationEventRole> CommunicationEventRole { get; set; }
        public ICollection<PurposeType> PurposeType { get; set; }

        //public virtual CommunicationEventCdb communication_event_cdb { get; set; }

        //public virtual CommunicationEventProspect communication_event_prospect { get; set; }


    }
}
