namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("communication_event_cdb")]
    public partial class CommunicationEventCdb :CommunicationEvent
    {
        [StringLength(900)]
        public string hobby { get; set; }

        [StringLength(900)]
        public string homestatus { get; set; }

        [StringLength(900)]
        public string exponemonth { get; set; }

        [StringLength(900)]
        public string job { get; set; }

        [StringLength(900)]
        public string lasteducation { get; set; }

        [StringLength(900)]
        public string owncellphone { get; set; }

        [StringLength(900)]
        public string hondarefference { get; set; }

        [StringLength(900)]
        public string ownvehiclebrand { get; set; }

        [StringLength(900)]
        public string ownvehicletype { get; set; }

        [StringLength(900)]
        public string buyfor { get; set; }

        [StringLength(900)]
        public string vehicleuser { get; set; }

        [StringLength(300)]
        public string facebook { get; set; }

        [StringLength(300)]
        public string instagram { get; set; }

        [StringLength(300)]
        public string twitter { get; set; }

        [StringLength(300)]
        public string youtube { get; set; }

        [StringLength(300)]
        public string email { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }
        

    }
}
