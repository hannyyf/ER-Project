namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("communication_event_delivery")]
    public partial class CommunicationEventDelivery
    {
        [Key]
        [MaxLength(16)]
        public byte[] idcomevt { get; set; }

        [StringLength(15)]
        public string bussinesscode { get; set; }

        [StringLength(15)]
        public string b1 { get; set; }

        [StringLength(15)]
        public string b2 { get; set; }

        [StringLength(15)]
        public string b3 { get; set; }

        [StringLength(15)]
        public string b4 { get; set; }

        public int? c11rate { get; set; }

        [StringLength(150)]
        public string c11reason { get; set; }

        [StringLength(150)]
        public string c11hope { get; set; }

        public int? c12rate { get; set; }

        [StringLength(150)]
        public string c12reason { get; set; }

        [StringLength(150)]
        public string c13hope { get; set; }

        public int? c14rate { get; set; }

        [StringLength(150)]
        public string c14reason { get; set; }

        [StringLength(150)]
        public string c14hope { get; set; }

        public int? c15rate { get; set; }

        [StringLength(150)]
        public string c15reason { get; set; }

        [StringLength(150)]
        public string c15hope { get; set; }

        public int? c16rate { get; set; }

        [StringLength(150)]
        public string c16reason { get; set; }

        [StringLength(150)]
        public string c16hope { get; set; }

        public int? c17rate { get; set; }

        [StringLength(150)]
        public string c17reason { get; set; }

        [StringLength(150)]
        public string c17hope { get; set; }

        public int? c18rate { get; set; }

        [StringLength(150)]
        public string c18reason { get; set; }

        [StringLength(150)]
        public string c18hope { get; set; }

        public int? c19rate { get; set; }

        [StringLength(150)]
        public string c19reason { get; set; }

        [StringLength(150)]
        public string c19hope { get; set; }

        public int? c110rate { get; set; }

        [StringLength(150)]
        public string c110reason { get; set; }

        [StringLength(150)]
        public string c110hope { get; set; }

        public int? c2rate { get; set; }

        [StringLength(150)]
        public string c3option { get; set; }

        [StringLength(150)]
        public string d1name { get; set; }

        [StringLength(150)]
        public string d2gender { get; set; }

        public int? d3age { get; set; }

        [StringLength(150)]
        public string d4phone { get; set; }

        [StringLength(150)]
        public string d5vehicle { get; set; }

        [StringLength(150)]
        public string d6education { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public virtual _internal Internal { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }

    }
}
