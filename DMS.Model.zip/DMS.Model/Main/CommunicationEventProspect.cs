namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("communication_event_prospect")]
    public partial class CommunicationEventProspect :CommunicationEvent
    {
        [ForeignKey("Prospect")]
        [MaxLength(16)]
        public byte[] idprospect { get; set; }
        public Prospect Prospect { get; set; }

        [ForeignKey("SaleType")]
        public int? idsaletype { get; set; }
        public SaleType SaleType { get; set; }

        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Motor Motor { get; set; }

        [ForeignKey("Feature")]
        public int? idcolor { get; set; }
        public Feature Feature { get; set; }

        [StringLength(5)]
        public string interest { get; set; }

        public decimal? qty { get; set; }

        [StringLength(30)]
        public string purchaseplan { get; set; }

        [StringLength(5)]
        public string connect { get; set; }
        
    }
}
