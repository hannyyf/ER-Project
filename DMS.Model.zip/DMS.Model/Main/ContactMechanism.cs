namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("contact_mechanism")]
    public partial class ContactMechanism
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public contact_mechanism()
        //{
        //    facility_contact_mechanism = new HashSet<FacilityContactMechanism>();
        //    party_contact_mechanism = new HashSet<PartyContactMechanism>();
        //    purpose_type = new HashSet<PurposeType>();
        //    facilities = new HashSet<Facility>();
        //    parties = new HashSet<Party>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idcontact { get; set; }

        public int? idcontacttype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        //public virtual ElectronicAddress electronic_address { get; set; }

        public ICollection<FacilityContactMechanism> FacilityContactMechanism { get; set; }

        public ICollection<PartyContactMechanism> PartyContactMechanism { get; set; }

        public ICollection<PurposeType> PurposeType { get; set; }

        public ICollection<Facility> Facility { get; set; }

        public ICollection<Party> Party { get; set; }
    }

    public class ContactMechanismDTO
    {
        [MaxLength(16)]
        public byte[] idcontact { get; set; }
        public int? idcontacttype { get; set; }
        public int idpurposetype { get; set; }

        public override bool Equals (object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            ContactMechanismDTO contactMechanismDTO = (ContactMechanismDTO) obj;
            if (contactMechanismDTO.idcontact == null || idcontact == null) { 
                return false;
            }
            return object.Equals(idcontact, contactMechanismDTO.idcontact);
        }

        public override int GetHashCode()
        {
            return idcontact.GetHashCode();
        }
        public override string ToString()
        {
            return "ContactMechanismDTO{" + "id='" + idcontact + "', idContactType='" + idcontacttype + "', idPurposeType='" + idpurposetype + "'}";
        }
    }
}
