namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("container")]
    public partial class Container
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public container()
        //{
        //    good_container = new HashSet<good_container>();
        //    inventory_item = new HashSet<InventoryItem>();
        //    moving_slip = new HashSet<moving_slip>();
        //    moving_slip1 = new HashSet<moving_slip>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idcontainer { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("ContainerType")]
        public int? idcontyp { get; set; }
        public ContainerType ContainerType { get; set; }

        [StringLength(30)]
        public string containercode { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<GoodContainer> GoodContainer { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }

        public ICollection<MovingSlip> MovingSlip { get; set; }

        public ICollection<MovingSlip> MovingSlip1 { get; set; }
    }

    public class ContainerDTO
    {
        [MaxLength(16)]
        public byte[] idcontainer { get; set; }
        [StringLength(30)]
        public string containercode { get; set; }
        [StringLength(50)]
        public string description { get; set; }
        public byte[] idfacility { get; set; }
        public string facilitydescription { get; set; }
        public int? idcontyp { get; set; }
        public string containertypedescription { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            ContainerDTO containerDTO = (ContainerDTO)obj;
            if (containerDTO.idcontainer == null || idcontainer == null)
            {
                return false;
            }
            return Object.Equals(idcontainer, containerDTO.idcontainer);
        }

        public override int GetHashCode()
        {
            return idcontainer.GetHashCode();
        }

        public override string ToString()
        {
            return "ContainerDTO{" + "id='" + idcontainer + "', containerCode='" + containercode + "', description='" + description + "'}";
        }

    }
}
