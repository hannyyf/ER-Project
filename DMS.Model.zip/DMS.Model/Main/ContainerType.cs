namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("container_type")]
    public partial class ContainerType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public container_type()
        //{
        //    containers = new HashSet<Container>();
        //}

        [Key]
        public int idcontyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Container> Container { get; set; }
    }

    public class ContainerTypeDTO
    {
        public int? idcontyp { get; set; }
        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            ContainerTypeDTO containerTypeDTO = (ContainerTypeDTO)obj;
            if (containerTypeDTO.idcontyp == null || idcontyp == null)
            {
                return false;
            }
            return Object.Equals(idcontyp, containerTypeDTO.idcontyp);
        }

        public override int GetHashCode()
        {
            return idcontyp.GetHashCode();
        }

        public override string ToString()
        {
            return "ContainerTypeDTO{" + "id='" + idcontyp + "', description='" + description + "'}";
        }

    }
}
