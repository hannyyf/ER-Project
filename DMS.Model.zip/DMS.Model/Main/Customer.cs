namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("customer")]
    public partial class Customer
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public customer()
        //{
        //    claim_detail = new HashSet<claim_detail>();
        //    communication_event_cdb = new HashSet<communication_event_cdb>();
        //    communication_event_delivery = new HashSet<communication_event_delivery>();
        //    customer_relationship = new HashSet<customer_relationship>();
        //    customer_order = new HashSet<customer_order>();
        //    customer_quotation = new HashSet<customer_quotation>();
        //    pkbs = new HashSet<pkb>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    vehicle_work_requirement = new HashSet<vehicle_work_requirement>();
        //    vehicle_identification = new HashSet<vehicle_identification>();
        //    vehicle_sales_billing = new HashSet<vehicle_sales_billing>();
        //}

        [Key]
        [StringLength(30)]
        public string idcustomer { get; set; }

        [ForeignKey("CategoryParty")]
        public int? idmarketcategory { get; set; }
        public CategoryParty CategoryParty { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [ForeignKey("CostumerType")]
        public int? IdCostumerType { get; set; }
        public CostumerType CostumerType { get; set; }

        public int? idsegmen { get; set; }

        //public virtual organization_customer organization_customer { get; set; }

        //public virtual personal_customer personal_customer { get; set; }


        public ICollection<ClaimDetail> ClaimDetail { get; set; }

        public ICollection<CommunicationEventCdb> CommunicationEventCdb { get; set; }

        public ICollection<CommunicationEventDelivery> CommunicationEventDelivery { get; set; }
         
        public ICollection<CustomerRelationship> CustomerRelationship { get; set; }
        public ICollection<CustomerOrder> CustomerOrder { get; set; }

        public ICollection<CustomerQuotation> CustomerQuotation { get; set; }
        public ICollection<Pkb> Pkb { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public ICollection<VehicleWorkRequirement> VehicleWorkRequirement { get; set; }

        public ICollection<VehicleIdentification> VehicleIdentification { get; set; }

        public ICollection<VehicleSalesBilling> VehicleSalesBilling { get; set; }


    }

    public class CustomerDTO
    {
        [StringLength(30)]
        public string idcustomer { get; set; }
        public int? idroletype { get; set; }
        public byte[] idparty { get; set; }
        public string partyname { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            CustomerDTO customerDTO = (CustomerDTO)obj;
            if (customerDTO.idcustomer == null || idcustomer == null)
            {
                return false;
            }
            return Object.Equals(idcustomer, customerDTO.idcustomer);
        }
        public override int GetHashCode()
        {
            return idcustomer.GetHashCode();
        }

        public override string ToString()
        {
            return "CustomerDTO{" + "idcustomer='" + idcustomer + "', idroletype='" + idroletype + "'}";
        }
    }
}
