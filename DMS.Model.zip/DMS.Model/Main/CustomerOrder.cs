namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("customer_order")]
    public partial class CustomerOrder :Order
    {
        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
            

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }
        

        //public virtual return_sales_order return_sales_order { get; set; }

        //public virtual sales_order sales_order { get; set; }
    }

    public class CustomerOrderDTO:OrdersDTO
    {
        public string idinternal { get; set; }
        public string idcustomer { get; set; }
        public string idbillto { get; set; }

        public override string ToString()
        {
            return "CustomerOrderDTO{" + "id=" + idorder + "'" + '}';
        }
    }
}
