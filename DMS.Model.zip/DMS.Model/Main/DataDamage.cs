namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("data_damage")]
    public partial class DataDamage
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public data_damage()
        //{
        //    claim_detail = new HashSet<ClaimDetail>();
        //}

        [Key]
        public int IdDataDamage { get; set; }

        [StringLength(30)]
        public string DescDamage { get; set; }
        public ICollection<ClaimDetail> ClaimDetail { get; set; }
    }
}
