namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("dealer_reminder_type")]
    public partial class DealerReminderType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public dealer_reminder_type()
        //{
        //    service_reminder = new HashSet<service_reminder>();
        //}

        [Key]
        public int idremindertype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [StringLength(600)]
        public string messages { get; set; }

        public ICollection<ServiceReminder> ServiceReminder { get; set; }
    }
}
