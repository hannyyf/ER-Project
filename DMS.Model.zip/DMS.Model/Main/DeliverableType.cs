namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("deliverable_type")]
    public partial class DeliverableType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public DeliverableType()
        //{
        //    unit_deliverable = new HashSet<unit_deliverable>();
        //}

        [Key]
        public int iddeltype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<UnitDeliverable> UnitDeliverable { get; set; }
    }
}
