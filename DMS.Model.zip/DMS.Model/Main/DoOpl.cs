namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("do_opl")]
    public partial class DoOpl
    {
        [Key]
        public int IDDOOPL { get; set; }

        [ForeignKey("PO")]
        public int? IdPo { get; set; }
        public PO PO { get; set; }

        [Required]
        [StringLength(25)]
        public string DONUMBER { get; set; }

        public DateTime? DODATE { get; set; }

        [Required]
        [StringLength(25)]
        public string NUMBERINVOICE { get; set; }

        [StringLength(20)]
        public string STATUSDO { get; set; }

        [Column(TypeName = "money")]
        public decimal PRICE { get; set; }

        public double DISCOUNT { get; set; }

        public double PPN { get; set; }

        [Column(TypeName = "money")]
        public decimal DiscountAmount { get; set; }

        [Column(TypeName = "money")]
        public decimal? TotalPrice { get; set; }

        [Column(TypeName = "money")]
        public decimal? Total { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        
    }
}
