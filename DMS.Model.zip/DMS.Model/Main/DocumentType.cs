namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("document_type")]
    public partial class DocumentType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public DocumentType()
        //{
        //    documents = new HashSet<document>();
        //    document_type1 = new HashSet<DocumentType>();
        //}

        [Key]
        public int iddoctype { get; set; }

        [ForeignKey("DocumentTypeParrent")]
        public int? idparent { get; set; }
        public DocumentType DocumentTypeParrent { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Document> Documents { get; set; }

        public ICollection<DocumentType> DocumentType1 { get; set; }

    }
}
