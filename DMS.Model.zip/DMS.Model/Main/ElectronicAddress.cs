namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("electronic_address")]
    public partial class ElectronicAddress : ContactMechanism
    {
        [StringLength(60)]
        public string address { get; set; }
        
    }

    public class ElectronicAddressDTO : ContactMechanismDTO
    {
        public string address { get; set; }
        public override string ToString()
        {
            return "ElectronicAddressDTO{" + "id='" + idcontact + "', address='" + address + "'}";
        }

    }
}
