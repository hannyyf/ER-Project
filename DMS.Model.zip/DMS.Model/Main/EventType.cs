namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("event_type")]
    public partial class EventType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public event_type()
        //{
        //    communication_event = new HashSet<CommunicationEvent>();
        //    event_type1 = new HashSet<event_type>();
        //    prospects = new HashSet<prospect>();
        //    work_order_booking = new HashSet<work_order_booking>();
        //}

        [Key]
        public int idevetyp { get; set; }

        [ForeignKey("EventTypeParrent")]
        public int? idprneve { get; set; }
        public EventType EventTypeParrent { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<CommunicationEvent> CommunicationEvent { get; set; }

        public ICollection<EventType> EventType1 { get; set; }

        public ICollection<Prospect> Prospects { get; set; }

        public ICollection<WorkOrderBooking> WorkOrderBooking { get; set; }
    }

    public class EventTypeDTO
    {
        public int? idevetyp { get; set; }
        public int? idprneve { get; set; }
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            EventTypeDTO eventTypeDTO = (EventTypeDTO)obj;
            if (eventTypeDTO.idevetyp == null || idevetyp == null)
            {
                return false;
            }
            return Object.Equals(idevetyp, eventTypeDTO.idevetyp);
        }

        public override int GetHashCode()
        {
            return idevetyp.GetHashCode();
        }
        public override string ToString()
        {
            return "EventTypeDTO{" + "id=" + idevetyp + ", description='" + description + "'" +"}";
        }


    }
}
