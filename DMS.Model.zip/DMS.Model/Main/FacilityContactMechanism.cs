namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("facility_contact_mechanism")]
    public partial class FacilityContactMechanism
    {
        [Key]
        [MaxLength(16)]
        public byte[] idconmecpur { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("ContactMechanism")]
        [MaxLength(16)]
        public byte[] idcontact { get; set; }
        public ContactMechanism ContactMechanism { get; set; }

        [ForeignKey("PurposeType")]
        public int? idpurposetype { get; set; }
        public PurposeType PurposeType { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
        
        
    }

    public class FacilityContactMechanismDTO
    {
        [MaxLength(16)]
        public byte[] idconmecpur { get; set; }
        public int? idpurposetype { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public string facilitydescription { get; set; }

        [MaxLength(16)]
        public byte[] idcontact { get; set; }
        public string contactdescription { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            FacilityContactMechanismDTO facilityContactMechanismDTO = (FacilityContactMechanismDTO)obj;
            if (facilityContactMechanismDTO.idconmecpur == null || idconmecpur == null)
            {
                return false;
            }
            return Object.Equals(idconmecpur, facilityContactMechanismDTO.idconmecpur);
        }

        public override int GetHashCode()
        {
            return idconmecpur.GetHashCode();
        }

        public override string ToString()
        {
            return "FacilityContactMechanismDTO{" +
            "id=" + idconmecpur +
            ", idPurposeType='" + idpurposetype + "'" +
            ", dateFrom='" + dtfrom + "'" +
            ", dateThru='" + dtthru + "'" +
            "}";
        }

    }
}
