namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("facility_type")]
    public partial class FacilityType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public facility_type()
        //{
        //    facilities = new HashSet<Facility>();
        //}

        [Key]
        public int idfacilitytype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Facility> Facility { get; set; }
    }

    public class FacilityTypeDTO
    {
        public int? idfacilitytype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            FacilityTypeDTO facilityTypeDTO = (FacilityTypeDTO)obj;
            if (facilityTypeDTO.idfacilitytype == null || idfacilitytype == null)
            {
                return false;
            }
            return Object.Equals(idfacilitytype, facilityTypeDTO.idfacilitytype);
        }

        public override int GetHashCode()
        {
            return idfacilitytype.GetHashCode();
        }

        public override string ToString()
        {
            return "FacilityTypeDTO{" +
            "id=" + idfacilitytype +
            ", description='" + description + "'" +
            "}";
        }
    }
}
