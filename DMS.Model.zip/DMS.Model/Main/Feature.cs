namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("feature")]
    public partial class Feature
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Feature()
        //{
        //    billing_item = new HashSet<BillingItem>();
        //    communication_event_prospect = new HashSet<communication_event_prospect>();
        //    inventory_item = new HashSet<inventory_item>();
        //    order_item = new HashSet<order_item>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    shipment_item = new HashSet<shipment_item>();
        //    shipment_receipt = new HashSet<shipment_receipt>();
        //    vehicles = new HashSet<vehicle>();
        //    products = new HashSet<product>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idfeature { get; set; }
        
        [ForeignKey("FeatureType")]
        public int? idfeatyp { get; set; }
        public FeatureType FeatureType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [StringLength(30)]
        public string refkey { get; set; }
        
        public ICollection<InventoryItem> InventoryItem { get; set; }
        public ICollection<OrderItem> OrderItem { get; set; }
        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }
        public ICollection<ShipmentItem> ShipmentItem { get; set; }
        public ICollection<ShipmentReceipt> ShipmentReceipt { get; set; }
        public ICollection<Vehicle> Vehicle { get; set; }
        public ICollection<Product> Product { get; set; }
        
    }

    public class FeatureDTO
    {
        public int? idfeature { get; set; }
        public int? idfeatyp { get; set; }
        [StringLength(50)]
        public string featypdescription { get; set; }
        [StringLength(50)]
        public string description { get; set; }

        [StringLength(30)]
        public string refkey { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            FeatureDTO featureDTO = (FeatureDTO)obj;
            if (featureDTO.idfeature == null || idfeature == null)
            {
                return false;
            }
            return Object.Equals(idfeature, featureDTO.idfeature);
        }

        public override int GetHashCode()
        {
            return idfeature.GetHashCode();
        }

        public override string ToString()
        {
            return "FeatureDTO{" + "id=" + idfeature + ", description='" + description + "'" + ", refKey='" + refkey + "'" + "}";
        }

    }
}
