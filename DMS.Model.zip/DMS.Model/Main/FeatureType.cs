namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("feature_type")]
    public partial class FeatureType
    {
 
        [Key]
        public int idfeatyp { get; set; }

        [ForeignKey("RuleType")]
        public int? idrultyp { get; set; }
        public RuleType RuleType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Feature> Feature { get; set; }

    }

    public class FeatureTypeDTO
    {
        public int? idfeatyp { get; set; }
        [StringLength(50)]
        public string description { get; set; }
        public string refkey { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            FeatureTypeDTO featureTypeDTO = (FeatureTypeDTO)obj;
            if (featureTypeDTO.idfeatyp == null || idfeatyp == null)
            {
                return false;
            }
            return Object.Equals(idfeatyp, featureTypeDTO.idfeatyp);
        }

        public override int GetHashCode()
        {
            return idfeatyp.GetHashCode();
        }

        public override string ToString()
        {
            return "FeatureTypeDTO{" + "id=" + idfeatyp + ", description='" + description + "'" + ", refKey='" + refkey + "'" + "}";
        }
    }
}
