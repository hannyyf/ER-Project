namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("fixed_asset")]
    public partial class FixedAsset
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public FixedAsset()
        //{
        //    facilities = new HashSet<facility>();
        //    inventory_item = new HashSet<inventory_item>();
        //}

        [Key]
        public int idfa { get; set; }

        [ForeignKey("FixedAssetType")]
        public int? idfatype { get; set; }
        public FixedAssetType FixedAssetType { get; set; }

        [ForeignKey("Uom")]
        [StringLength(30)]
        public string iduom { get; set; }
        public Uom Uom { get; set; }

        [StringLength(30)]
        public string name { get; set; }

        public DateTime? dtacquired { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Facility> Facilities { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }
    }
}
