namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("fixed_asset_type")]
    public partial class FixedAssetType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public fixed_asset_type()
        //{
        //    fixed_asset = new HashSet<fixed_asset>();
        //    fixed_asset_type1 = new HashSet<fixed_asset_type>();
        //}

        [Key]
        public int idfatype { get; set; }

        [ForeignKey("FixedAssetTypeParrent")]
        public int? idparent { get; set; }
        public FixedAssetType FixedAssetTypeParrent { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<FixedAsset> FixedAsset { get; set; }

        public ICollection<FixedAssetType> FixedAssetTypeParrentss { get; set; }
    }
}
