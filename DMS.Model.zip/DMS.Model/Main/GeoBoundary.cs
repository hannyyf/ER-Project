namespace DMS.Model.Main
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Runtime.Serialization;

    [Table("geo_boundary")]
    public partial class GeoBoundary
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public GeoBoundary()
        //{
        //    geo_boundary1 = new HashSet<GeoBoundary>();
        //    price_component = new HashSet<PriceComponent>();
        //}

        [Key]
        [StringLength(36)]
        public string idgeobou { get; set; }

        [ForeignKey("GeoBoundaryParrent")]
        [StringLength(36)]
        public string idparent { get; set; }
        public GeoBoundary GeoBoundaryParrent { get; set; }

        [ForeignKey("GeoBoundaryType")]
        public int? idgeoboutype { get; set; }
        public GeoBoundaryType GeoBoundaryType { get; set; }

        [StringLength(30)]
        public string geocode { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [JsonIgnore]
        public ICollection<GeoBoundary> GeoBoundaries { get; set; }
        [JsonIgnore]
        public ICollection<PriceComponent> PriceComponent { get; set; }

        public class GeoBoundaryDTO
        {
            [StringLength(36)]
            public string idgeobou { get; set; }
            [StringLength(30)]
            public string geocode { get; set; }
            [StringLength(50)]
            public string description { get; set; }

            public override string ToString()
            {
                return "GeoBoundaryDTO{"+"idgeobou='" + idgeobou + "', geocode='" + geocode + "', description='" + description + "'}";
            }

            //public override bool Equals(object obj)
            //{
            //    if (this == obj)
            //    {
            //        return true;
            //    }
            //    GeoBoundary geoBoundary = new GeoBoundary();
            //    return object.Equals(this.idgeobou, )
            //}
        }
    }
}
