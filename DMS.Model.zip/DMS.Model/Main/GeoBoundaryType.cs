namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("geo_boundary_type")]
    public partial class GeoBoundaryType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public geo_boundary_type()
        //{
        //    geo_boundary = new HashSet<geo_boundary>();
        //}

        [Key]
        public int idgeoboutype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<GeoBoundary> GeoBoundary { get; set; }
    }

    public class GeoBoundaryTypeDTO
    {
        public int? idgeoboutype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            GeoBoundaryTypeDTO geoBoundaryTypeDTO = (GeoBoundaryTypeDTO)obj;
            if (geoBoundaryTypeDTO.idgeoboutype == null || idgeoboutype == null)
            {
                return false;
            }
            return Object.Equals(idgeoboutype, geoBoundaryTypeDTO.idgeoboutype);
        }

        public override int GetHashCode()
        {
            return idgeoboutype.GetHashCode();
        }

        public override string ToString()
        {
            return "GeoBoundaryTypeDTO{" +
            "id=" + idgeoboutype +
            ", description='" + description + "'" +
            "}";
        }

    }
}
