namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("internal_order")]
    public partial class InternalOrder :Order
    {
        [ForeignKey("InternalTO")]
        [StringLength(30)]
        public string idintto { get; set; }
        public _internal InternalTO { get; set; }

        [ForeignKey("Internal1Fro")]
        [StringLength(30)]
        public string idintfro { get; set; }
        public _internal Internal1Fro { get; set; }

        
    }
}
