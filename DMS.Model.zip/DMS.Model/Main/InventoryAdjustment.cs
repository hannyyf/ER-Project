namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("inventory_adjustment")]
    public partial class InventoryAdjustment
    {
        [Key]
        [MaxLength(16)]
        public byte[] idinvadj { get; set; }

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        public decimal? qty { get; set; }

        
    }
}
