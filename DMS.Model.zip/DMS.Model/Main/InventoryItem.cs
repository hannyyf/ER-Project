namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("inventory_item")]
    public partial class InventoryItem
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public InventoryItem()
        //{
        //    billing_item = new HashSet<BillingItem>();
        //    inventory_adjustment = new HashSet<inventory_adjustment>();
        //    inventory_item_status = new HashSet<inventory_item_status>();
        //    item_issuance = new HashSet<item_issuance>();
        //    memos = new HashSet<memo>();
        //    memos1 = new HashSet<memo>();
        //    moving_slip = new HashSet<moving_slip>();
        //    moving_slip1 = new HashSet<moving_slip>();
        //    picking_slip = new HashSet<picking_slip>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idowner { get; set; }
        public Party Party { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }
        
        [ForeignKey("Container")]
        [MaxLength(16)]
        public byte[] idcontainer { get; set; }
        public Container Container { get; set; }

        [ForeignKey("ShipmentReceipt")]
        [MaxLength(16)]
        public byte[] idreceipt { get; set; }
        public ShipmentReceipt ShipmentReceipt { get; set; }

        [ForeignKey("Feature")]
        public int? idfeature { get; set; }
        public Feature Feature { get; set; }

        [ForeignKey("FixedAsset")]
        public int? idfa { get; set; }
        public FixedAsset FixedAsset { get; set; }

        public DateTime? dtcreated { get; set; }

        public decimal? qty { get; set; }

        public decimal? qtybooking { get; set; }

        [StringLength(50)]
        public string idframe { get; set; }

        [StringLength(50)]
        public string idmachine { get; set; }

        public int? yearassembly { get; set; }

        public ICollection<BillingItem> BillingItem { get; set; }

        public ICollection<InventoryAdjustment> InventoryAdjustment { get; set; }

        public ICollection<InventoryItemStatus> InventoryItemStatus { get; set; }

        public ICollection<ItemIssuance> ItemIssuance { get; set; }

        public ICollection<Memo> Memos { get; set; }

        public ICollection<Memo> Memos1 { get; set; }

        public ICollection<MovingSlip> MovingSlip { get; set; }

        public ICollection<MovingSlip> MovingSlip1 { get; set; }

        public ICollection<PickingSlip> PickingSlip { get; set; }
    }
}
