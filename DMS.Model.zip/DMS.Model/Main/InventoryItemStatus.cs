namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("inventory_item_status")]
    public partial class InventoryItemStatus
    {
        [Key]
        [MaxLength(16)]
        public byte[] idstatus { get; set; }

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [ForeignKey("ReasonType")]
        public int? idreason { get; set; }
        public ReasonType ReasonType { get; set; }

        [StringLength(300)]
        public string reason { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

 
    }
}
