namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("inventory_movement")]
    public partial class InventoryMovement:MovingSlip
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public inventory_movement()
        //{
        //    inventory_movement_status = new HashSet<inventory_movement_status>();
        //}

        public DateTime? dtcreate { get; set; }

        public ICollection<InventoryMovementStatus> InventoryMovementStatus { get; set; }
        
        //public virtual picking_slip picking_slip { get; set; }
    }
}
