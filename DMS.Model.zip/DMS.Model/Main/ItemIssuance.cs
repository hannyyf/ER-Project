namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("item_issuance")]
    public partial class ItemIssuance
    {
        [Key]
        [MaxLength(16)]
        public byte[] iditeiss { get; set; }

        [ForeignKey("ShipmentItem")]
        [MaxLength(16)]
        public byte[] idshiite { get; set; }
        public ShipmentItem ShipmentItem { get; set; }

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        [ForeignKey("PickingSlip")]
        [MaxLength(16)]
        public byte[] idslip { get; set; }
        public PickingSlip PickingSlip { get; set; }

        public decimal? qty { get; set; }

    }
}
