namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("jhi_authority")]
    public partial class JhiAuthority
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public jhi_authority()
        //{
        //    rule_sales_discount = new HashSet<rule_sales_discount>();
        //    jhi_user = new HashSet<jhi_user>();
        //    position_type = new HashSet<position_type>();
        //}

        [Key]
        [StringLength(30)]
        public string name { get; set; }

        public ICollection<RuleSalesDiscount> RuleSalesDiscount { get; set; }

        public ICollection<JhiUser> JhiUser { get; set; }

        public ICollection<PositionType> PositionType { get; set; }
    }
}
