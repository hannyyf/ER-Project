namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("jhi_persistent_audit_event")]
    public partial class JhiPersistentAuditEvent
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public jhi_persistent_audit_event()
        //{
        //    jhi_persistent_audit_evt_data = new HashSet<jhi_persistent_audit_evt_data>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long event_id { get; set; }

        [Required]
        [StringLength(150)]
        public string principal { get; set; }

        public DateTime? event_date { get; set; }

        [StringLength(765)]
        public string event_type { get; set; }

        public ICollection<JhiPersistentAuditEvtData> JhiPersistentAuditEvtData { get; set; }
    }
}
