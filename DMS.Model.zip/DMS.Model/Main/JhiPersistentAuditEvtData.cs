namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("jhi_persistent_audit_evt_data")]
    public partial class JhiPersistentAuditEvtData
    {
        [ForeignKey("JhiPersistentAuditEvent")]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long event_id { get; set; }
        public JhiPersistentAuditEvent JhiPersistentAuditEvent { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(450)]
        public string name { get; set; }

        [StringLength(765)]
        public string value { get; set; }

        
    }
}
