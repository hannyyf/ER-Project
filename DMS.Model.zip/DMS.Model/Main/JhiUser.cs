namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("jhi_user")]
    public partial class JhiUser
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public jhi_user()
        //{
        //    user_mediator = new HashSet<user_mediator>();
        //    jhi_authority = new HashSet<JhiAuthority>();
        //}

        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long id { get; set; }

        [Required]
        [StringLength(150)]
        public string login { get; set; }

        [StringLength(180)]
        public string password_hash { get; set; }

        [StringLength(150)]
        public string first_name { get; set; }

        [StringLength(150)]
        public string last_name { get; set; }

        [StringLength(300)]
        public string email { get; set; }

        [StringLength(768)]
        public string image_url { get; set; }

        [Required]
        [StringLength(1)]
        public string activated { get; set; }

        [StringLength(15)]
        public string lang_key { get; set; }

        [StringLength(60)]
        public string activation_key { get; set; }

        [StringLength(60)]
        public string reset_key { get; set; }

        [Required]
        [StringLength(150)]
        public string created_by { get; set; }

        public DateTime? created_date { get; set; }

        public DateTime? reset_date { get; set; }

        [StringLength(150)]
        public string last_modified_by { get; set; }

        public DateTime? last_modified_date { get; set; }

        public ICollection<UserMediator> UserMediator { get; set; }

        public ICollection<JhiAuthority> JhiAuthority { get; set; }
    }
}
