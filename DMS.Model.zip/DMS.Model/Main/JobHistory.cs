namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("job_history")]
    public partial class JobHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdJobHistory { get; set; }

        [ForeignKey("Job")]
        public int? IdJob { get; set; }
        public Job Job { get; set; }

        [ForeignKey("JobStatus")]
        public int? IdJobStatus { get; set; }
        public JobStatus JobStatus { get; set; }

        [ForeignKey("PendingReason")]
        public int? IdPendingReason { get; set; }
        public PendingReason PendingReason { get; set; }

        [ForeignKey("Mechanic")]
        [MaxLength(16)]
        public byte[] idparrol { get; set; }
        public virtual Mechanic Mechanic { get; set; }

        public DateTime? Time { get; set; }

        public int? Duration { get; set; }

    }
}
