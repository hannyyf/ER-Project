namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("job_service")]
    public partial class JobService
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdJobService { get; set; }

        [ForeignKey("Job")]
        public int? IdJob { get; set; }
        public Job Job { get; set; }

        [ForeignKey("Service")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Service Service { get; set; }

    }
}
