namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("job_status")]
    public partial class JobStatus
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public job_status()
        //{
        //    jobs = new HashSet<Job>();
        //    job_history = new HashSet<JobHistory>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdJobStatus { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [StringLength(30)]
        public string Desc { get; set; }

        public ICollection<Job> Job { get; set; }

        public ICollection<JobHistory> JobHistory { get; set; }

        
    }
}
