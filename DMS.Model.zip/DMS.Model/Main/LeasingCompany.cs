namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("leasing_company")]
    public partial class LeasingCompany :PartyRole
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public leasing_company()
        //{
        //    leasing_tenor_provide = new HashSet<leasing_tenor_provide>();
        //    sales_unit_leasing = new HashSet<sales_unit_leasing>();
        //    vehicle_sales_order = new HashSet<vehicle_sales_order>();
        //}

        //[Key]
        //[MaxLength(16)]
        //public byte[] idparrol { get; set; }
        //public virtual party_role party_role { get; set; }

        [StringLength(30)]
        public string idleacom { get; set; }

        public ICollection<LeasingTenorProvide> LeasingTenorProvide { get; set; }

        public ICollection<SalesUnitLeasing> SalesUnitLeasing { get; set; }

        public ICollection<VehicleSalesOrder> VehicleSalesOrder { get; set; }
    }

    public class LeasingCompanyDTO : PartyRoleDTO
    {
        [StringLength(30)]
        public string idleacom { get; set; }
    }
}
