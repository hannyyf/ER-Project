namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("leasing_tenor_provide")]
    public partial class LeasingTenorProvide
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public leasing_tenor_provide()
        //{
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    sales_unit_leasing = new HashSet<sales_unit_leasing>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idlsgpro { get; set; }

        [ForeignKey("LeasingCompany")]
        [MaxLength(16)]
        public byte[] idleacom { get; set; }
        public LeasingCompany LeasingCompany { get; set; }

        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Motor Motor { get; set; }

        public int? tenor { get; set; }

        public decimal? installment { get; set; }

        public decimal? downpayment { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public ICollection<SalesUnitLeasing> SalesUnitLeasing { get; set; }
    }
}
