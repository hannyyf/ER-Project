namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("master_numbering")]
    public partial class MasterNumbering
    {
        [Key]
        [MaxLength(16)]
        public byte[] idnumbering { get; set; }

        [StringLength(50)]
        public string idtag { get; set; }

        [StringLength(50)]
        public string idvalue { get; set; }

        public int? nextvalue { get; set; }
    }
}
