namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("memo")]
    public partial class Memo
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public memo()
        //{
        //    memo_status = new HashSet<memo_status>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idmemo { get; set; }

        [ForeignKey("Billing")]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        public Billing Billing { get; set; }

        [ForeignKey("MemoType")]
        public int? idmemotype { get; set; }
        public MemoType MemoType { get; set; }

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        [ForeignKey("OldInventoryItem")]
        [MaxLength(16)]
        public byte[] idoldinvite { get; set; }
        public InventoryItem OldInventoryItem { get; set; }

        public DateTime? dtcreated { get; set; }

        [StringLength(30)]
        public string memonumber { get; set; }

        public decimal? bbn { get; set; }

        public decimal? discount { get; set; }

        public decimal? unitprice { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }
        
        public ICollection<MemoStatus> MemoStatus { get; set; }
    }

    public class MemosDTO
    {
        [MaxLength(16)]
        public byte[] idmemo { get; set; }
        [StringLength(30)]
        public string memonumber { get; set; }

        public decimal? bbn { get; set; }

        public decimal? discount { get; set; }

        public decimal? unitprice { get; set; }
        public int currentstatus { get; set; }
        public string iddealer { get; set; }
        public string dealername { get; set; }
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        public int? idmemotype { get; set; }
        public string memotypedescription { get; set; }
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        [MaxLength(16)]
        public byte[] idoldinvite { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            MemosDTO memosDTO = (MemosDTO)obj;
            if (memosDTO.idmemo == null || idmemo == null)
            {
                return false;
            }
            return Object.Equals(idmemo, memosDTO.idmemo);
        }

        public override int GetHashCode()
        {
            return idmemo.GetHashCode();
        }

        public override string ToString()
        {
            return "MemosDTO{" +
            "id=" + idmemo +
            ", memoNumber='" + memonumber + "'" +
            ", bbn='" + bbn + "'" +
            ", discount='" + discount + "'" +
            ", unitPrice='" + unitprice + "'" +
            "}";
        }
    }
}
