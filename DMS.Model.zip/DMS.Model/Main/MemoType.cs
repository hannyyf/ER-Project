namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("memo_type")]
    public partial class MemoType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public memo_type()
        //{
        //    memos = new HashSet<memo>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idmemotype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Memo> Memos { get; set; }
    }

    public class MemoTypeDTO
    {
        public int? idmemotype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            MemoTypeDTO memoTypeDTO = (MemoTypeDTO)obj;
            if (memoTypeDTO.idmemotype == null || idmemotype == null)
            {
                return false;
            }
            return Object.Equals(idmemotype, memoTypeDTO.idmemotype);
        }

        public override int GetHashCode()
        {
            return idmemotype.GetHashCode();
        }

        public override string ToString()
        {
            return "MemoTypeDTO{" +
            "id=" + idmemotype +
            ", description='" + description + "'" +
            "}";
        }
    }
}
