namespace DMS.Model.Main
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Models : DbContext
    {
        public Models()
#if (DEBUG == true)
            : base("name=DefaultConnection")
#else
            
            : base("name=TestConnection")
#endif
        {
        }

        public virtual DbSet<Agreement> agreements { get; set; }
        public virtual DbSet<AgreementItem> agreement_item { get; set; }
        public virtual DbSet<AgreementMotorItem> agreement_motor_item { get; set; }
        public virtual DbSet<AgreementRole> agreement_role { get; set; }
        public virtual DbSet<AgreementStatus> agreement_status { get; set; }
        public virtual DbSet<AgreementType> agreement_type { get; set; }
        public virtual DbSet<Approval> approvals { get; set; }
        public virtual DbSet<ApprovalType> approval_type { get; set; }
        public virtual DbSet<AssociationType> association_type { get; set; }
        public virtual DbSet<Attendance> attendances { get; set; }
        public virtual DbSet<BaseCalendar> base_calendar { get; set; }
        public virtual DbSet<BillTo> bill_to { get; set; }
        public virtual DbSet<Billing> billings { get; set; }
        public virtual DbSet<BillingAccount> billing_account { get; set; }
        public virtual DbSet<BillingDisbursement> billing_disbursement { get; set; }
        public virtual DbSet<BillingItem> billing_item { get; set; }
        public virtual DbSet<BillingItemType> billing_item_type { get; set; }
        public virtual DbSet<BillingNjb> billing_njb { get; set; }
        public virtual DbSet<BillingNsc> billing_nsc { get; set; }
        public virtual DbSet<BillingReceipt> billing_receipt { get; set; }
        public virtual DbSet<BillingRole> billing_role { get; set; }
        public virtual DbSet<BillingStatus> billing_status { get; set; }
        public virtual DbSet<BillingType> billing_type { get; set; }
        public virtual DbSet<Booking> bookings { get; set; }
        public virtual DbSet<BookingSlot> booking_slot { get; set; }
        public virtual DbSet<BookingSlotStandard> booking_slot_standard { get; set; }
        public virtual DbSet<BookingStatus> booking_status { get; set; }
        public virtual DbSet<BookingType> booking_type { get; set; }
        public virtual DbSet<Branch> branches { get; set; }
        public virtual DbSet<BrokerType> broker_type { get; set; }
        public virtual DbSet<CalendarType> calendar_type { get; set; }
        public virtual DbSet<CanceledPo> canceled_po { get; set; }
        public virtual DbSet<Carrier> carriers { get; set; }
        public virtual DbSet<Category> categories { get; set; }
        public virtual DbSet<CategoryParty> category_party { get; set; }
        public virtual DbSet<CategoryProduct> category_product { get; set; }
        public virtual DbSet<CategoryType> category_type { get; set; }
        public virtual DbSet<City> cities { get; set; }
        public virtual DbSet<ClaimDetail> claim_detail { get; set; }
        public virtual DbSet<CommunicationEvent> communication_event { get; set; }
        public virtual DbSet<CommunicationEventCdb> communication_event_cdb { get; set; }
        public virtual DbSet<CommunicationEventDelivery> communication_event_delivery { get; set; }
        public virtual DbSet<CommunicationEventProspect> communication_event_prospect { get; set; }
        public virtual DbSet<CommunicationEventRole> communication_event_role { get; set; }
        public virtual DbSet<CommunicationEventStatus> communication_event_status { get; set; }
        public virtual DbSet<ContactMechanism> contact_mechanism { get; set; }
        public virtual DbSet<Container> containers { get; set; }
        public virtual DbSet<ContainerType> container_type { get; set; }
        public virtual DbSet<CostumerType> costumer_type { get; set; }
        public virtual DbSet<Customer> customers { get; set; }
        public virtual DbSet<CustomerBillTo> customer_bill_to { get; set; }
        public virtual DbSet<CustomerOrder> customer_order { get; set; }
        public virtual DbSet<CustomerQuotation> customer_quotation { get; set; }
        public virtual DbSet<CustomerRelationship> customer_relationship { get; set; }
        public virtual DbSet<CustomerShipTo> customer_ship_to { get; set; }
        public virtual DbSet<DataDamage> data_damage { get; set; }
        public virtual DbSet<databasechangeloglock> databasechangeloglocks { get; set; }
        public virtual DbSet<DealerClaimType> dealer_claim_type { get; set; }
        public virtual DbSet<DealerReminderType> dealer_reminder_type { get; set; }
        public virtual DbSet<DeliverableType> deliverable_type { get; set; }
        public virtual DbSet<Disbursement> disbursements { get; set; }
        public virtual DbSet<District> districts { get; set; }
        public virtual DbSet<DoOpl> do_opl { get; set; }
        public virtual DbSet<DocumentType> document_type { get; set; }
        public virtual DbSet<Document> documents { get; set; }
        public virtual DbSet<Driver> drivers { get; set; }
        public virtual DbSet<ElectronicAddress> electronic_address { get; set; }
        public virtual DbSet<Employee> employees { get; set; }
        public virtual DbSet<Estimation> estimations { get; set; }
        public virtual DbSet<EventType> event_type { get; set; }
        public virtual DbSet<Facility> facilities { get; set; }
        public virtual DbSet<FacilityContactMechanism> facility_contact_mechanism { get; set; }
        public virtual DbSet<FacilityStatus> facility_status { get; set; }
        public virtual DbSet<FacilityType> facility_type { get; set; }
        public virtual DbSet<Feature> features { get; set; }
        public virtual DbSet<FeatureType> feature_type { get; set; }
        public virtual DbSet<FixedAsset> fixed_asset { get; set; }
        public virtual DbSet<FixedAssetType> fixed_asset_type { get; set; }
        public virtual DbSet<GeoBoundary> geo_boundary { get; set; }
        public virtual DbSet<GeoBoundaryType> geo_boundary_type { get; set; }
        public virtual DbSet<Good> goods { get; set; }
        public virtual DbSet<GoodContainer> good_container { get; set; }
        public virtual DbSet<Intern> interns { get; set; }
        public virtual DbSet<_internal> internals { get; set; }
        public virtual DbSet<InternalBillTo> internal_bill_to { get; set; }
        public virtual DbSet<InternalOrder> internal_order { get; set; }
        public virtual DbSet<InternalShipTo> internal_ship_to { get; set; }
        public virtual DbSet<InventoryAdjustment> inventory_adjustment { get; set; }
        public virtual DbSet<InventoryItem> inventory_item { get; set; }
        public virtual DbSet<InventoryItemStatus> inventory_item_status { get; set; }
        public virtual DbSet<InventoryMovement> inventory_movement { get; set; }
        public virtual DbSet<InventoryMovementStatus> inventory_movement_status { get; set; }
        public virtual DbSet<ItemIssuance> item_issuance { get; set; }
        public virtual DbSet<JhiAuthority> jhi_authority { get; set; }
        public virtual DbSet<JhiPersistentAuditEvent> jhi_persistent_audit_event { get; set; }
        public virtual DbSet<JhiPersistentAuditEvtData> jhi_persistent_audit_evt_data { get; set; }
        public virtual DbSet<JhiUser> jhi_user { get; set; }
        public virtual DbSet<Job> jobs { get; set; }
        public virtual DbSet<JobHistory> job_history { get; set; }
        public virtual DbSet<JobService> job_service { get; set; }
        public virtual DbSet<JobStatus> job_status { get; set; }
        public virtual DbSet<LeasingCompany> leasing_company { get; set; }
        public virtual DbSet<LeasingTenorProvide> leasing_tenor_provide { get; set; }
        public virtual DbSet<MasterNumbering> master_numbering { get; set; }
        public virtual DbSet<Mechanic> mechanics { get; set; }
        public virtual DbSet<Memo> memos { get; set; }
        public virtual DbSet<MemoStatus> memo_status { get; set; }
        public virtual DbSet<MemoType> memo_type { get; set; }
        public virtual DbSet<Motor> motors { get; set; }
        public virtual DbSet<MotorDueReminder> motor_due_reminder { get; set; }
        public virtual DbSet<MovingSlip> moving_slip { get; set; }
        public virtual DbSet<OauthAccessToken> oauth_access_token { get; set; }
        public virtual DbSet<OauthClientDetails> oauth_client_details { get; set; }
        public virtual DbSet<OrderItem> order_item { get; set; }
        public virtual DbSet<OrderType> order_type { get; set; }
        public virtual DbSet<Order> orders { get; set; }
        public virtual DbSet<OrdersRole> orders_role { get; set; }
        public virtual DbSet<OrdersStatus> orders_status { get; set; }
        public virtual DbSet<Organization> organizations { get; set; }
        public virtual DbSet<OrganizationCustomer> organization_customer { get; set; }
        public virtual DbSet<OrganizationProspect> organization_prospect { get; set; }
        public virtual DbSet<OrganizationSuspect> organization_suspect { get; set; }
        public virtual DbSet<PackageReceipt> package_receipt { get; set; }
        public virtual DbSet<PackagingContent> packaging_content { get; set; }
        public virtual DbSet<ParentOrganization> parent_organization { get; set; }
        public virtual DbSet<PartHistory> part_history { get; set; }
        public virtual DbSet<PartSalesOrder> part_sales_order { get; set; }
        public virtual DbSet<Party> parties { get; set; }
        public virtual DbSet<PartyContactMechanism> party_contact_mechanism { get; set; }
        public virtual DbSet<PartyDocument> party_document { get; set; }
        public virtual DbSet<PartyFacilityPurpose> party_facility_purpose { get; set; }
        public virtual DbSet<PartyRelationship> party_relationship { get; set; }
        public virtual DbSet<PartyRole> party_role { get; set; }
        public virtual DbSet<PartyRoleStatus> party_role_status { get; set; }
        public virtual DbSet<PartyRoleType> party_role_type { get; set; }
        public virtual DbSet<Payment> payments { get; set; }
        public virtual DbSet<PaymentApplication> payment_application { get; set; }
        public virtual DbSet<PaymentMethodType> payment_method_type { get; set; }
        public virtual DbSet<PaymentRole> payment_role { get; set; }
        public virtual DbSet<PaymentStatus> payment_status { get; set; }
        public virtual DbSet<PaymentType> payment_type { get; set; }
        public virtual DbSet<PendingReason> PendingReasons { get; set; }
        public virtual DbSet<Person> people { get; set; }
        public virtual DbSet<PersonProspect> person_prospect { get; set; }
        public virtual DbSet<PersonSuspect> person_suspect { get; set; }
        public virtual DbSet<PersonalCustomer> personal_customer { get; set; }
        public virtual DbSet<PersonSosmed> PersonSosmeds { get; set; }
        public virtual DbSet<PickingSlip> picking_slip { get; set; }
        public virtual DbSet<Pkb> pkbs { get; set; }
        public virtual DbSet<PkbEstimation> pkb_estimation { get; set; }
        public virtual DbSet<PkbPart> pkb_part { get; set; }
        public virtual DbSet<PkbPartBillingItem> pkb_part_billing_item { get; set; }
        public virtual DbSet<PkbService> pkb_service { get; set; }
        public virtual DbSet<PkbServiceBillingItem> pkb_service_billing_item { get; set; }
        public virtual DbSet<PO> POes { get; set; }
        public virtual DbSet<PoDetailPart> po_detail_part { get; set; }
        public virtual DbSet<PoDetailService> po_detail_service { get; set; }
        public virtual DbSet<PoStatus> po_status { get; set; }
        public virtual DbSet<PositionFullfillment> position_fullfillment { get; set; }
        public virtual DbSet<PositionReportingStructure> position_reporting_structure { get; set; }
        public virtual DbSet<PositionType> position_type { get; set; }
        public virtual DbSet<Position> positions { get; set; }
        public virtual DbSet<PositionsStatus> positions_status { get; set; }
        public virtual DbSet<PostalAddress> postal_address { get; set; }
        public virtual DbSet<PriceAgreementItem> price_agreement_item { get; set; }
        public virtual DbSet<PriceComponent> price_component { get; set; }
        public virtual DbSet<PriceType> price_type { get; set; }
        public virtual DbSet<Product> products { get; set; }
        public virtual DbSet<ProductAssociation> product_association { get; set; }
        public virtual DbSet<ProductDocument> product_document { get; set; }
        public virtual DbSet<ProductPurchaseOrder> product_purchase_order { get; set; }
        public virtual DbSet<ProductType> product_type { get; set; }
        public virtual DbSet<Prospect> prospects { get; set; }
        public virtual DbSet<ProspectRole> prospect_role { get; set; }
        public virtual DbSet<ProspectSources> prospect_source { get; set; }
        public virtual DbSet<ProspectStatus> prospect_status { get; set; }
        public virtual DbSet<Province> provinces { get; set; }
        public virtual DbSet<PurchaseOrder> purchase_order { get; set; }
        public virtual DbSet<PurchaseRequest> purchase_request { get; set; }
        public virtual DbSet<PurposeType> purpose_type { get; set; }
        public virtual DbSet<Queue> queues { get; set; }
        public virtual DbSet<QueueStatus> queue_status { get; set; }
        public virtual DbSet<QueueType> queue_type { get; set; }
        public virtual DbSet<Quote> quotes { get; set; }
        public virtual DbSet<QuoteItem> quote_item { get; set; }
        public virtual DbSet<QuoteRole> quote_role { get; set; }
        public virtual DbSet<QuoteStatus> quote_status { get; set; }
        public virtual DbSet<ReasonType> reason_type { get; set; }
        public virtual DbSet<Receipt> receipts { get; set; }
        public virtual DbSet<RegularSalesOder> regular_sales_order { get; set; }
        public virtual DbSet<RelationType> relation_type { get; set; }
        public virtual DbSet<ReligionType> religion_type { get; set; }
        public virtual DbSet<RemPart> rem_part { get; set; }
        public virtual DbSet<Requirement> requirements { get; set; }
        public virtual DbSet<RequirementRole> requirement_role { get; set; }
        public virtual DbSet<RequirementStatus> requirement_status { get; set; }
        public virtual DbSet<RequirementType> requirement_type { get; set; }
        public virtual DbSet<ReturnPurchaseOrder> return_purchase_order { get; set; }
        public virtual DbSet<ReturnSalesOrder> return_sales_order { get; set; }
        public virtual DbSet<RoleType> role_type { get; set; }
        public virtual DbSet<RuleHotItem> rule_hot_item { get; set; }
        public virtual DbSet<RuleIndent> rule_indent { get; set; }
        public virtual DbSet<RuleSalesDiscount> rule_sales_discount { get; set; }
        public virtual DbSet<RuleType> rule_type { get; set; }
        public virtual DbSet<Rule> rules { get; set; }
        public virtual DbSet<SaleType> sale_type { get; set; }
        public virtual DbSet<SalesAgreement> sales_agreement { get; set; }
        public virtual DbSet<SalesBroker> sales_broker { get; set; }
        public virtual DbSet<SalesOrder> sales_order { get; set; }
        public virtual DbSet<SalesPoint> sales_point { get; set; }
        public virtual DbSet<SalesUnitLeasing> sales_unit_leasing { get; set; }
        public virtual DbSet<SalesUnitRequirement> sales_unit_requirement { get; set; }
        public virtual DbSet<Salesman> salesmen { get; set; }
        public virtual DbSet<Service> services { get; set; }
        public virtual DbSet<ServiceAgreement> service_agreement { get; set; }
        public virtual DbSet<ServiceHistory> service_history { get; set; }
        public virtual DbSet<ServicePerMotor> service_per_motor { get; set; }
        public virtual DbSet<ServiceReminder> service_reminder { get; set; }
        public virtual DbSet<ShipTo> ship_to { get; set; }
        public virtual DbSet<Shipment> shipments { get; set; }
        public virtual DbSet<ShipmentIncoming> shipment_incoming { get; set; }
        public virtual DbSet<ShipmentItem> shipment_item { get; set; }
        public virtual DbSet<ShipmentOutgoing> shipment_outgoing { get; set; }
        public virtual DbSet<ShipmentPackage> shipment_package { get; set; }
        public virtual DbSet<ShipmentPackageRole> shipment_package_role { get; set; }
        public virtual DbSet<ShipmentPackageStatus> shipment_package_status { get; set; }
        public virtual DbSet<ShipmentPackageType> shipment_package_type { get; set; }
        public virtual DbSet<ShipmentReceipt> shipment_receipt { get; set; }
        public virtual DbSet<ShipmentReceiptRole> shipment_receipt_role { get; set; }
        public virtual DbSet<ShipmentReceiptStatus> shipment_receipt_status { get; set; }
        public virtual DbSet<ShipmentStatus> shipment_status { get; set; }
        public virtual DbSet<ShipmentType> shipment_type { get; set; }
        public virtual DbSet<SosmedType> SosmedTypes { get; set; }
        public virtual DbSet<StandardCalendar> standard_calendar { get; set; }
        public virtual DbSet<StatusPkb> status_pkb { get; set; }
        public virtual DbSet<StatusType> status_type { get; set; }
        public virtual DbSet<Summary> summaries { get; set; }
        public virtual DbSet<Suspect> suspects { get; set; }
        public virtual DbSet<SuspectRole> suspect_role { get; set; }
        public virtual DbSet<SuspectStatus> suspect_status { get; set; }
        public virtual DbSet<SuspectType> suspect_type { get; set; }
        public virtual DbSet<SympthomDataM> sympthom_data_m { get; set; }
        public virtual DbSet<Sysdiagram> sysdiagrams { get; set; }
        public virtual DbSet<TelecomunicationNumber> telecomunication_number { get; set; }
        public virtual DbSet<TypePkb> type_pkb { get; set; }
        public virtual DbSet<UnitAccesoriesMapper> unit_accesories_mapper { get; set; }
        public virtual DbSet<UnitDeliverable> unit_deliverable { get; set; }
        public virtual DbSet<UnitRequirement> unit_requirement { get; set; }
        public virtual DbSet<Uom> uoms { get; set; }
        public virtual DbSet<UomConversion> uom_conversion { get; set; }
        public virtual DbSet<UomType> uom_type { get; set; }
        public virtual DbSet<UserExtra> user_extra { get; set; }
        public virtual DbSet<UserMediator> user_mediator { get; set; }
        public virtual DbSet<UserMediatorRole> user_mediator_role { get; set; }
        public virtual DbSet<UserMediatorStatus> user_mediator_status { get; set; }
        public virtual DbSet<Vehicle> vehicles { get; set; }
        public virtual DbSet<VehicleDocumentRequirement> vehicle_document_requirement { get; set; }
        public virtual DbSet<VehicleIdentification> vehicle_identification { get; set; }
        public virtual DbSet<VehiclePurchaseOrder> vehicle_purchase_order { get; set; }
        public virtual DbSet<VehicleRegistrationType> vehicle_registration_type { get; set; }
        public virtual DbSet<VehicleSalesBilling> vehicle_sales_billing { get; set; }
        public virtual DbSet<VehicleSalesOrder> vehicle_sales_order { get; set; }
        public virtual DbSet<VehicleServiceHistory> vehicle_service_history { get; set; }
        public virtual DbSet<VehicleType> vehicle_type { get; set; }
        public virtual DbSet<VehicleWorkRequirement> vehicle_work_requirement { get; set; }
        public virtual DbSet<Vendor> vendors { get; set; }
        public virtual DbSet<VendorBillTo> vendor_bill_to { get; set; }
        public virtual DbSet<VendorOrder> vendor_order { get; set; }
        public virtual DbSet<VendorProduct> vendor_product { get; set; }
        public virtual DbSet<VendorRelationship> vendor_relationship { get; set; }
        public virtual DbSet<VendorShipTo> vendor_ship_to { get; set; }
        public virtual DbSet<VendorType> vendor_type { get; set; }
        public virtual DbSet<Village> villages { get; set; }
        public virtual DbSet<WeServiceType> we_service_type { get; set; }
        public virtual DbSet<WeType> we_type { get; set; }
        public virtual DbSet<WeTypeGoodStandard> we_type_good_standard { get; set; }
        public virtual DbSet<WorkEffort> work_effort { get; set; }
        public virtual DbSet<WorkEffortRole> work_effort_role { get; set; }
        public virtual DbSet<WorkEffortStatus> work_effort_status { get; set; }
        public virtual DbSet<WorkOrder> work_order { get; set; }
        public virtual DbSet<WorkOrderBooking> work_order_booking { get; set; }
        public virtual DbSet<WorkOrderBookingRole> work_order_booking_role { get; set; }
        public virtual DbSet<WorkOrderBookingStatus> work_order_booking_status { get; set; }
        public virtual DbSet<WorkProductReq> work_product_req { get; set; }
        public virtual DbSet<WorkRequirement> work_requirement { get; set; }
        public virtual DbSet<WorkServiceRequirement> work_service_requirement { get; set; }
        public virtual DbSet<WorkType> work_type { get; set; }
        public virtual DbSet<databasechangelog> databasechangelogs { get; set; }

        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<agreement>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<agreement>()
        //        .HasOptional(e => e.sales_agreement)
        //        .WithRequired(e => e.agreement);

        //    modelBuilder.Entity<agreement>()
        //        .HasOptional(e => e.service_agreement)
        //        .WithRequired(e => e.agreement);

        //    modelBuilder.Entity<agreement_item>()
        //        .Property(e => e.idagrite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_item>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_item>()
        //        .HasOptional(e => e.agreement_motor_item)
        //        .WithRequired(e => e.agreement_item);

        //    modelBuilder.Entity<agreement_item>()
        //        .HasOptional(e => e.price_agreement_item)
        //        .WithRequired(e => e.agreement_item);

        //    modelBuilder.Entity<agreement_motor_item>()
        //        .Property(e => e.idagrite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_motor_item>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_role>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<agreement_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_status>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<agreement_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<agreement_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<approval>()
        //    //    .Property(e => e.idapproval)
        //    //    .IsFixedLength();

        //    //modelBuilder.Entity<approval>()
        //    //    .Property(e => e.idreq)
        //    //    .IsFixedLength();

        //    //modelBuilder.Entity<approval>()
        //    //    .Property(e => e.idordite)
        //    //    .IsFixedLength();

        //    modelBuilder.Entity<ApprovalType>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<association_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<attendance>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<attendance>()
        //        .Property(e => e.AttendInfo)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<attendance>()
        //        .Property(e => e.AvailInfo)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<base_calendar>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<base_calendar>()
        //        .Property(e => e.workday)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<base_calendar>()
        //        .HasMany(e => e.base_calendar1)
        //        .WithOptional(e => e.base_calendar2)
        //        .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<base_calendar>()
        //        .HasOptional(e => e.standard_calendar)
        //        .WithRequired(e => e.base_calendar);

        //    modelBuilder.Entity<BillTo>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillTo>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    //modelBuilder.Entity<bill_to>()
        //    //    .HasMany(e => e.billing_receipt)
        //    //    .WithOptional(e => e.bill_to)
        //    //    .HasForeignKey(e => e.idbilto);

        //    //modelBuilder.Entity<BillTo>()
        //    //    .HasOptional(e => e.customer_bill_to)
        //    //    .WithRequired(e => e.bill_to);

        //    //modelBuilder.Entity<BillTo>()
        //    //    .HasOptional(e => e.internal_bill_to)
        //    //    .WithRequired(e => e.bill_to);

        //    //modelBuilder.Entity<BillTo>()
        //    //    .HasOptional(e => e.vendor_bill_to)
        //    //    .WithRequired(e => e.bill_to);

        //    modelBuilder.Entity<Billing>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<Billing>()
        //        .Property(e => e.billingnumber)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<Billing>()
        //    //    .HasOptional(e => e.billing_njb)
        //    //    .WithRequired(e => e.billing);

        //    //modelBuilder.Entity<Billing>()
        //    //    .HasOptional(e => e.billing_disbursement)
        //    //    .WithRequired(e => e.billing);

        //    //modelBuilder.Entity<Billing>()
        //    //    .HasOptional(e => e.billing_receipt)
        //    //    .WithRequired(e => e.billing);

        //    //modelBuilder.Entity<Billing>()
        //    //    .HasOptional(e => e.billing_nsc)
        //    //    .WithRequired(e => e.billing);

        //    //modelBuilder.Entity<Billing>()
        //    //    .HasMany(e => e.payments)
        //    //    .WithMany(e => e.billings)
        //    //    .Map(m => m.ToTable("billing_payment").MapLeftKey("billings_id").MapRightKey("payments_id"));

        //    modelBuilder.Entity<BillingAccount>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingDisbursement>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingDisbursement>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingDisbursement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingDisbursement>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingItem>()
        //        .Property(e => e.idbilite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingItem>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingItem>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingItem>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingItem>()
        //        .Property(e => e.itemdescription)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.qty)
        //    //    .HasPrecision(14, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.baseprice)
        //    //    .HasPrecision(18, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.unitprice)
        //    //    .HasPrecision(18, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.discount)
        //    //    .HasPrecision(18, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.taxamount)
        //    //    .HasPrecision(18, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .Property(e => e.totalamount)
        //    //    .HasPrecision(18, 4);

        //    //modelBuilder.Entity<BillingItem>()
        //    //    .HasMany(e => e.order_item)
        //    //    .WithMany(e => e.billing_item)
        //    //    .Map(m => m.ToTable("order_billing_item").MapLeftKey("idbilite").MapRightKey("idordite"));

        //    modelBuilder.Entity<billing_item_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.NoNjb)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.totalbaseprice)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.totaltaxamount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.mischarge)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.totalunitprice)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.totaldiscount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_njb>()
        //        .Property(e => e.grandtotalamount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.NoNsc)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.totalbaseprice)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.totaltaxamount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.mischarge)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.totalunitprice)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.totaldiscount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<billing_nsc>()
        //        .Property(e => e.grandtotalamount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<BillingReceipt>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingReceipt>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingReceipt>()
        //        .Property(e => e.idbilto)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<BillingReceipt>()
        //    //    .HasOptional(e => e.vehicle_sales_billing)
        //    //    .WithRequired(e => e.billing_receipt);

        //    modelBuilder.Entity<BillingRole>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingRole>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingRole>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingRole>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingStatus>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingStatus>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<BillingStatus>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<BillingType>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking>()
        //        .Property(e => e.NoBooking)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking>()
        //        .Property(e => e.CustomerName)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking>()
        //        .Property(e => e.VehicleNumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking_slot>()
        //        .Property(e => e.idbooslo)
        //        .IsFixedLength();

        //    modelBuilder.Entity<booking_slot>()
        //        .Property(e => e.idbooslostd)
        //        .IsFixedLength();

        //    modelBuilder.Entity<booking_slot>()
        //        .Property(e => e.slotnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking_slot_standard>()
        //        .Property(e => e.idbooslostd)
        //        .IsFixedLength();

        //    modelBuilder.Entity<booking_slot_standard>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking_slot_standard>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking_status>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<booking_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<branch>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<broker_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<calendar_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<canceled_po>()
        //        .Property(e => e.REASON)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<carrier>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<carrier>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<category>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_party>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_party>()
        //        .Property(e => e.refkey)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_party>()
        //        .HasMany(e => e.branches)
        //        .WithOptional(e => e.category_party)
        //        .HasForeignKey(e => e.idbranchcategory);

        //    //modelBuilder.Entity<category_party>()
        //    //    .HasMany(e => e.customers)
        //    //    .WithOptional(e => e.category_party)
        //    //    .HasForeignKey(e => e.idmarketcategory);

        //    modelBuilder.Entity<category_party>()
        //        .HasMany(e => e.price_component)
        //        .WithOptional(e => e.category_party)
        //        .HasForeignKey(e => e.idparcat);

        //    modelBuilder.Entity<category_party>()
        //        .HasMany(e => e.parties)
        //        .WithMany(e => e.category_party)
        //        .Map(m => m.ToTable("party_category").MapLeftKey("categories_id").MapRightKey("parties_id"));

        //    modelBuilder.Entity<category_product>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_product>()
        //        .Property(e => e.refkey)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_product>()
        //        .HasMany(e => e.price_component)
        //        .WithOptional(e => e.category_product)
        //        .HasForeignKey(e => e.idprocat);

        //    modelBuilder.Entity<category_product>()
        //        .HasMany(e => e.products)
        //        .WithMany(e => e.category_product)
        //        .Map(m => m.ToTable("product_category").MapLeftKey("categories_id").MapRightKey("products_id"));

        //    modelBuilder.Entity<category_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<category_type>()
        //        .HasMany(e => e.category_type1)
        //        .WithOptional(e => e.category_type2)
        //        .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<city>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.ClaimType)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.StatusClaim)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NoTicket)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.SubmissionGroup_)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NoLkh)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NoType)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.MarketName)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NoProduction)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.Rank)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.AnalysisResult)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.Amount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.DSubtotalJob)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NominalTransfer)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.NoDocs)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<claim_detail>()
        //        .Property(e => e.Replace)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event>()
        //        .Property(e => e.idparrel)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event>()
        //        .Property(e => e.note)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event>()
        //        .HasOptional(e => e.communication_event_cdb)
        //        .WithRequired(e => e.communication_event);

        //    modelBuilder.Entity<communication_event>()
        //        .HasOptional(e => e.communication_event_prospect)
        //        .WithRequired(e => e.communication_event);

        //    modelBuilder.Entity<communication_event>()
        //        .HasMany(e => e.purpose_type)
        //        .WithMany(e => e.communication_event)
        //        .Map(m => m.ToTable("communication_event_purpose").MapLeftKey("idcomevt").MapRightKey("idpurposetype"));

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.hobby)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.homestatus)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.exponemonth)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.job)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.lasteducation)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.owncellphone)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.hondarefference)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.ownvehiclebrand)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.ownvehicletype)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.buyfor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.vehicleuser)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.facebook)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.instagram)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.twitter)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.youtube)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.email)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_cdb>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.bussinesscode)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.b1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.b2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.b3)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.b4)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c11reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c11hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c12reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c13hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c14reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c14hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c15reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c15hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c16reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c16hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c17reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c17hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c18reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c18hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c19reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c19hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c110reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c110hope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.c3option)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.d1name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.d2gender)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.d4phone)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.d5vehicle)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.d6education)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_delivery>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.interest)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.purchaseplan)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_prospect>()
        //        .Property(e => e.connect)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_role>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<communication_event_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_status>()
        //        .Property(e => e.idcomevt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<communication_event_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<contact_mechanism>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<contact_mechanism>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasOptional(e => e.electronic_address)
        //        .WithRequired(e => e.contact_mechanism);

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasOptional(e => e.postal_address)
        //        .WithRequired(e => e.contact_mechanism);

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasOptional(e => e.telecomunication_number)
        //        .WithRequired(e => e.contact_mechanism);

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasMany(e => e.purpose_type)
        //        .WithMany(e => e.contact_mechanism)
        //        .Map(m => m.ToTable("contact_purpose").MapLeftKey("idcontact").MapRightKey("idpurposetype"));

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasMany(e => e.facilities)
        //        .WithMany(e => e.contact_mechanism)
        //        .Map(m => m.ToTable("facility_contact").MapLeftKey("idcontact").MapRightKey("idfacility"));

        //    modelBuilder.Entity<contact_mechanism>()
        //        .HasMany(e => e.parties)
        //        .WithMany(e => e.contact_mechanism)
        //        .Map(m => m.ToTable("party_contact").MapLeftKey("idcontact").MapRightKey("idparty"));

        //    modelBuilder.Entity<container>()
        //        .Property(e => e.idcontainer)
        //        .IsFixedLength();

        //    modelBuilder.Entity<container>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<container>()
        //        .Property(e => e.code)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<container>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<container>()
        //        .HasMany(e => e.moving_slip)
        //        .WithOptional(e => e.container)
        //        .HasForeignKey(e => e.idcontainerto);

        //    modelBuilder.Entity<container>()
        //        .HasMany(e => e.moving_slip1)
        //        .WithOptional(e => e.container1)
        //        .HasForeignKey(e => e.idcontainerfrom);

        //    modelBuilder.Entity<container_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<costumer_type>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Customer>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Customer>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    //modelBuilder.Entity<customer>()
        //    //    .HasOptional(e => e.organization_customer)
        //    //    .WithRequired(e => e.customer);

        //    //modelBuilder.Entity<customer>()
        //    //    .HasOptional(e => e.personal_customer)
        //    //    .WithRequired(e => e.customer);

        //    modelBuilder.Entity<customer_bill_to>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<customer_order>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_order>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_order>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_order>()
        //        .HasOptional(e => e.return_sales_order)
        //        .WithRequired(e => e.customer_order);

        //    modelBuilder.Entity<customer_order>()
        //        .HasOptional(e => e.sales_order)
        //        .WithRequired(e => e.customer_order);

        //    modelBuilder.Entity<customer_quotation>()
        //        .Property(e => e.idquote)
        //        .IsFixedLength();

        //    modelBuilder.Entity<customer_quotation>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_quotation>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_relationship>()
        //        .Property(e => e.idparrel)
        //        .IsFixedLength();

        //    modelBuilder.Entity<customer_relationship>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_relationship>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<customer_ship_to>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<data_damage>()
        //        .Property(e => e.DescDamage)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangeloglock>()
        //        .Property(e => e.LOCKED)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangeloglock>()
        //        .Property(e => e.LOCKEDBY)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<dealer_claim_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<dealer_reminder_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<dealer_reminder_type>()
        //        .Property(e => e.messages)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<deliverable_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<disbursement>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<disbursement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<disbursement>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<district>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.DONUMBER)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.NUMBERINVOICE)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.STATUSDO)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.PRICE)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.DiscountAmount)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.TotalPrice)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<do_opl>()
        //        .Property(e => e.Total)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<DocumentType>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<DocumentType>()
        //        .HasMany(e => e.document_type1)
        //        .WithOptional(e => e.document_type2)
        //        .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<document>()
        //        .Property(e => e.iddocument)
        //        .IsFixedLength();

        //    modelBuilder.Entity<document>()
        //        .Property(e => e.note)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<document>()
        //        .HasOptional(e => e.party_document)
        //        .WithRequired(e => e.document);

        //    modelBuilder.Entity<document>()
        //        .HasOptional(e => e.product_document)
        //        .WithRequired(e => e.document);

        //    modelBuilder.Entity<driver>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<driver>()
        //        .Property(e => e.iddriver)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<driver>()
        //        .Property(e => e.external)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<driver>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<driver>()
        //        .HasMany(e => e.shipment_outgoing)
        //        .WithOptional(e => e.driver)
        //        .HasForeignKey(e => e.iddriver);

        //    modelBuilder.Entity<electronic_address>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<electronic_address>()
        //        .Property(e => e.address)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<employee>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<employee>()
        //        .Property(e => e.employeeNumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<employee>()
        //        .HasOptional(e => e.mechanic)
        //        .WithRequired(e => e.employee);

        //    modelBuilder.Entity<estimation>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<event_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<event_type>()
        //        .HasMany(e => e.event_type1)
        //        .WithOptional(e => e.event_type2)
        //        .HasForeignKey(e => e.idprneve);

        //    modelBuilder.Entity<facility>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility>()
        //        .Property(e => e.idpartof)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility>()
        //        .Property(e => e.code)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<facility>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<facility>()
        //        .HasMany(e => e.facility1)
        //        .WithOptional(e => e.facility2)
        //        .HasForeignKey(e => e.idpartof);

        //    modelBuilder.Entity<facility>()
        //        .HasMany(e => e.moving_slip)
        //        .WithOptional(e => e.facility)
        //        .HasForeignKey(e => e.idfacilityfrom);

        //    modelBuilder.Entity<facility>()
        //        .HasMany(e => e.moving_slip1)
        //        .WithOptional(e => e.facility1)
        //        .HasForeignKey(e => e.idfacilityto);

        //    modelBuilder.Entity<facility>()
        //        .HasMany(e => e.parties)
        //        .WithMany(e => e.facilities)
        //        .Map(m => m.ToTable("party_facility").MapLeftKey("facilities_id").MapRightKey("parties_id"));

        //    modelBuilder.Entity<facility_contact_mechanism>()
        //        .Property(e => e.idconmecpur)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility_contact_mechanism>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility_contact_mechanism>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility_status>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<facility_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<facility_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Feature>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Feature>()
        //        .Property(e => e.refkey)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<Feature>()
        //    //    .HasMany(e => e.communication_event_prospect)
        //    //    .WithOptional(e => e.feature)
        //    //    .HasForeignKey(e => e.idcolor);

        //    //modelBuilder.Entity<Feature>()
        //    //    .HasMany(e => e.sales_unit_requirement)
        //    //    .WithOptional(e => e.feature)
        //    //    .HasForeignKey(e => e.idcolor);

        //    //modelBuilder.Entity<Feature>()
        //    //    .HasMany(e => e.vehicles)
        //    //    .WithOptional(e => e.feature)
        //    //    .HasForeignKey(e => e.idcolor);

        //    //modelBuilder.Entity<Feature>()
        //    //    .HasMany(e => e.products)
        //    //    .WithMany(e => e.features)
        //    //    .Map(m => m.ToTable("product_feature").MapLeftKey("features_id").MapRightKey("products_id"));

        //    modelBuilder.Entity<feature_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<fixed_asset>()
        //        .Property(e => e.iduom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<fixed_asset>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<fixed_asset>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<fixed_asset_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<fixed_asset_type>()
        //        .HasMany(e => e.fixed_asset_type1)
        //        .WithOptional(e => e.fixed_asset_type2)
        //        .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<geo_boundary>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<geo_boundary>()
        //        .Property(e => e.idparent)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<geo_boundary>()
        //        .Property(e => e.geocode)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<geo_boundary>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<geo_boundary>()
        //        .HasOptional(e => e.city)
        //        .WithRequired(e => e.geo_boundary);

        //    modelBuilder.Entity<geo_boundary>()
        //        .HasOptional(e => e.district)
        //        .WithRequired(e => e.geo_boundary);

        //    modelBuilder.Entity<geo_boundary>()
        //        .HasMany(e => e.geo_boundary1)
        //        .WithOptional(e => e.geo_boundary2)
        //        .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<geo_boundary>()
        //        .HasOptional(e => e.province)
        //        .WithRequired(e => e.geo_boundary);

        //    modelBuilder.Entity<geo_boundary>()
        //        .HasOptional(e => e.village)
        //        .WithRequired(e => e.geo_boundary);

        //    modelBuilder.Entity<geo_boundary_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<good>()
        //        .Property(e => e.iduom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<good>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<good>()
        //        .HasOptional(e => e.motor)
        //        .WithRequired(e => e.good);

        //    modelBuilder.Entity<good>()
        //        .HasOptional(e => e.rem_part)
        //        .WithRequired(e => e.good);

        //    modelBuilder.Entity<good_container>()
        //        .Property(e => e.idgoocon)
        //        .IsFixedLength();

        //    modelBuilder.Entity<good_container>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<good_container>()
        //        .Property(e => e.idcontainer)
        //        .IsFixedLength();

        //    modelBuilder.Entity<good_container>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<intern>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<_internal>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<_internal>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<_internal>()
        //        .Property(e => e.selfsender)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<_internal>()
        //    //    .HasOptional(e => e.branch)
        //    //    .WithRequired(e => e._internal);

        //    //modelBuilder.Entity<_internal>()
        //    //    .HasMany(e => e.internal_order)
        //    //    .WithOptional(e => e._internal)
        //    //    .HasForeignKey(e => e.idintto);

        //    //modelBuilder.Entity<_internal>()
        //    //    .HasMany(e => e.internal_order1)
        //    //    .WithOptional(e => e.internal1)
        //    //    .HasForeignKey(e => e.idintfro);

        //    //modelBuilder.Entity<_internal>()
        //    //    .HasOptional(e => e.parent_organization)
        //    //    .WithRequired(e => e._internal);

        //    //modelBuilder.Entity<_internal>()
        //    //    .HasOptional(e => e.sales_point)
        //    //    .WithRequired(e => e._internal);

        //    modelBuilder.Entity<internal_bill_to>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<internal_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<internal_order>()
        //        .Property(e => e.idintto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<internal_order>()
        //        .Property(e => e.idintfro)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<internal_ship_to>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<inventory_adjustment>()
        //        .Property(e => e.idinvadj)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_adjustment>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_adjustment>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idowner)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idcontainer)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idreceipt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.qtybooking)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idframe)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<inventory_item>()
        //        .Property(e => e.idmachine)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<inventory_item>()
        //        .HasMany(e => e.memos)
        //        .WithOptional(e => e.inventory_item)
        //        .HasForeignKey(e => e.idoldinvite);

        //    modelBuilder.Entity<inventory_item>()
        //        .HasMany(e => e.memos1)
        //        .WithOptional(e => e.inventory_item1)
        //        .HasForeignKey(e => e.idinvite);

        //    modelBuilder.Entity<inventory_item>()
        //        .HasMany(e => e.moving_slip)
        //        .WithOptional(e => e.inventory_item)
        //        .HasForeignKey(e => e.idinviteto);

        //    modelBuilder.Entity<inventory_item>()
        //        .HasMany(e => e.moving_slip1)
        //        .WithOptional(e => e.inventory_item1)
        //        .HasForeignKey(e => e.idinviteto);

        //    modelBuilder.Entity<inventory_item_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item_status>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_item_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<inventory_movement>()
        //        .Property(e => e.idslip)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_movement>()
        //        .HasOptional(e => e.moving_slip)
        //        .WithRequired(e => e.inventory_movement);

        //    modelBuilder.Entity<inventory_movement>()
        //        .HasOptional(e => e.picking_slip)
        //        .WithRequired(e => e.inventory_movement);

        //    modelBuilder.Entity<inventory_movement_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_movement_status>()
        //        .Property(e => e.idslip)
        //        .IsFixedLength();

        //    modelBuilder.Entity<inventory_movement_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<item_issuance>()
        //        .Property(e => e.iditeiss)
        //        .IsFixedLength();

        //    modelBuilder.Entity<item_issuance>()
        //        .Property(e => e.idshiite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<item_issuance>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<item_issuance>()
        //        .Property(e => e.idslip)
        //        .IsFixedLength();

        //    modelBuilder.Entity<item_issuance>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<jhi_authority>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_authority>()
        //        .HasMany(e => e.jhi_user)
        //        .WithMany(e => e.jhi_authority)
        //        .Map(m => m.ToTable("jhi_user_authority").MapLeftKey("authority_name").MapRightKey("user_id"));

        //    modelBuilder.Entity<jhi_authority>()
        //        .HasMany(e => e.position_type)
        //        .WithMany(e => e.jhi_authority)
        //        .Map(m => m.ToTable("position_authority").MapLeftKey("name").MapRightKey("idpostyp"));

        //    modelBuilder.Entity<jhi_persistent_audit_event>()
        //        .Property(e => e.principal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_persistent_audit_event>()
        //        .Property(e => e.event_type)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_persistent_audit_event>()
        //        .HasMany(e => e.jhi_persistent_audit_evt_data)
        //        .WithRequired(e => e.jhi_persistent_audit_event)
        //        .WillCascadeOnDelete(false);

        //    modelBuilder.Entity<jhi_persistent_audit_evt_data>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_persistent_audit_evt_data>()
        //        .Property(e => e.value)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.login)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.password_hash)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.first_name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.last_name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.email)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.image_url)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.activated)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.lang_key)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.activation_key)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.reset_key)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.created_by)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<jhi_user>()
        //        .Property(e => e.last_modified_by)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<job>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<job>()
        //        .Property(e => e.Complaint)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<job>()
        //        .Property(e => e.JobSuggest)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<job_history>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<job_service>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<job_status>()
        //        .Property(e => e.Desc)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<leasing_company>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<leasing_company>()
        //        .Property(e => e.idleacom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<leasing_company>()
        //        .HasMany(e => e.leasing_tenor_provide)
        //        .WithOptional(e => e.leasing_company)
        //        .HasForeignKey(e => e.idleacom);

        //    modelBuilder.Entity<leasing_company>()
        //        .HasMany(e => e.sales_unit_leasing)
        //        .WithOptional(e => e.leasing_company)
        //        .HasForeignKey(e => e.idleacom);

        //    modelBuilder.Entity<leasing_company>()
        //        .HasMany(e => e.vehicle_sales_order)
        //        .WithOptional(e => e.leasing_company)
        //        .HasForeignKey(e => e.idleacom);

        //    modelBuilder.Entity<leasing_tenor_provide>()
        //        .Property(e => e.idlsgpro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<leasing_tenor_provide>()
        //        .Property(e => e.idleacom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<leasing_tenor_provide>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<leasing_tenor_provide>()
        //        .Property(e => e.installment)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<leasing_tenor_provide>()
        //        .Property(e => e.downpayment)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<master_numbering>()
        //        .Property(e => e.idnumbering)
        //        .IsFixedLength();

        //    modelBuilder.Entity<master_numbering>()
        //        .Property(e => e.idtag)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<master_numbering>()
        //        .Property(e => e.idvalue)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<mechanic>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<mechanic>()
        //        .Property(e => e.idmechanic)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<mechanic>()
        //        .Property(e => e.external)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<mechanic>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<mechanic>()
        //        .Property(e => e.password)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<mechanic>()
        //        .HasMany(e => e.vehicle_work_requirement)
        //        .WithOptional(e => e.mechanic)
        //        .HasForeignKey(e => e.idmechanic);

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.idmemo)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.idoldinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.memonumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.bbn)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.discount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.unitprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<memo>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<memo_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo_status>()
        //        .Property(e => e.idmemo)
        //        .IsFixedLength();

        //    modelBuilder.Entity<memo_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<memo_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<motor>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<motor>()
        //        .HasMany(e => e.motor_due_reminder)
        //        .WithOptional(e => e.motor)
        //        .HasForeignKey(e => e.idmotor);

        //    modelBuilder.Entity<motor>()
        //        .HasMany(e => e.unit_accesories_mapper)
        //        .WithOptional(e => e.motor)
        //        .HasForeignKey(e => e.idmotor);

        //    modelBuilder.Entity<motor_due_reminder>()
        //        .Property(e => e.idmotor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idslip)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idinviteto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idcontainerfrom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idcontainerto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idfacilityto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.idfacilityfrom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<moving_slip>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<oauth_access_token>()
        //        .Property(e => e.token_id)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_access_token>()
        //        .Property(e => e.authentication_id)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_access_token>()
        //        .Property(e => e.user_name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_access_token>()
        //        .Property(e => e.client_id)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_access_token>()
        //        .Property(e => e.refresh_token)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.client_id)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.resource_ids)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.client_secret)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.scope)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.authorized_grant_types)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.web_server_redirect_uri)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<oauth_client_details>()
        //        .Property(e => e.authorities)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.idordite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.idparordite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.itemdescription)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.unitprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.discount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.taxamount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.totalamount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<OrderItem>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<OrderItem>()
        //    //    .HasMany(e => e.order_item1)
        //    //    .WithOptional(e => e.order_item2)
        //    //    .HasForeignKey(e => e.idparordite);

        //    //modelBuilder.Entity<OrderItem>()
        //    //    .HasMany(e => e.requirements)
        //    //    .WithMany(e => e.order_item)
        //    //    .Map(m => m.ToTable("order_item_requirement").MapLeftKey("order_items_id").MapRightKey("requirements_id"));

        //    //modelBuilder.Entity<OrderItem>()
        //    //    .HasMany(e => e.shipment_item)
        //    //    .WithMany(e => e.order_item)
        //    //    .Map(m => m.ToTable("shipment_item_order_item").MapLeftKey("order_items_id").MapRightKey("shipment_items_id"));

        //    modelBuilder.Entity<order_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<order>()
        //        .Property(e => e.ordernumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<order>()
        //        .HasOptional(e => e.customer_order)
        //        .WithRequired(e => e.order);

        //    modelBuilder.Entity<order>()
        //        .HasOptional(e => e.internal_order)
        //        .WithRequired(e => e.order);

        //    modelBuilder.Entity<order>()
        //        .HasOptional(e => e.vendor_order)
        //        .WithRequired(e => e.order);

        //    modelBuilder.Entity<order>()
        //        .HasMany(e => e.payment_application)
        //        .WithMany(e => e.orders)
        //        .Map(m => m.ToTable("orders_payment").MapLeftKey("orders_id").MapRightKey("payments_id"));

        //    modelBuilder.Entity<orders_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<orders_role>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<orders_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<orders_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<orders_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<orders_status>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<orders_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<organization>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization>()
        //        .Property(e => e.idpic)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization>()
        //        .Property(e => e.idposaddtdp)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<organization>()
        //        .Property(e => e.numbertdp)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<organization>()
        //        .HasMany(e => e.positions)
        //        .WithOptional(e => e.organization)
        //        .HasForeignKey(e => e.idorganization);

        //    modelBuilder.Entity<organization_customer>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<organization_prospect>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization_prospect>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization_prospect>()
        //        .Property(e => e.idpic)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization_prospect>()
        //        .Property(e => e.idposaddtdp)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization_suspect>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<organization_suspect>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<package_receipt>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<package_receipt>()
        //        .Property(e => e.idshifro)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<package_receipt>()
        //        .Property(e => e.documentnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<packaging_content>()
        //        .Property(e => e.idpaccon)
        //        .IsFixedLength();

        //    modelBuilder.Entity<packaging_content>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<packaging_content>()
        //        .Property(e => e.idshiite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<packaging_content>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<parent_organization>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<part_history>()
        //        .Property(e => e.NoPart)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<part_history>()
        //        .Property(e => e.DescPart)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<part_sales_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party>()
        //        .HasMany(e => e.inventory_item)
        //        .WithOptional(e => e.party)
        //        .HasForeignKey(e => e.idowner);

        //    modelBuilder.Entity<party>()
        //        .HasOptional(e => e.organization)
        //        .WithRequired(e => e.party);

        //    modelBuilder.Entity<party>()
        //        .HasMany(e => e.party_role_type)
        //        .WithRequired(e => e.party)
        //        .WillCascadeOnDelete(false);

        //    modelBuilder.Entity<party>()
        //        .HasOptional(e => e.person)
        //        .WithRequired(e => e.party);

        //    modelBuilder.Entity<party>()
        //        .HasMany(e => e.requirement_role)
        //        .WithRequired(e => e.party)
        //        .WillCascadeOnDelete(false);

        //    modelBuilder.Entity<party>()
        //        .HasMany(e => e.sales_unit_requirement)
        //        .WithOptional(e => e.party)
        //        .HasForeignKey(e => e.idowner);

        //    modelBuilder.Entity<party_contact_mechanism>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_contact_mechanism>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_document>()
        //        .Property(e => e.iddocument)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_document>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_document>()
        //        .Property(e => e.contenttype)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<party_facility_purpose>()
        //        .Property(e => e.idparfacpur)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_facility_purpose>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_facility_purpose>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_relationship>()
        //        .Property(e => e.idparrel)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_relationship>()
        //        .Property(e => e.idparrolfro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_relationship>()
        //        .Property(e => e.idparrolto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_relationship>()
        //        .HasOptional(e => e.customer_relationship)
        //        .WithRequired(e => e.party_relationship);

        //    modelBuilder.Entity<party_relationship>()
        //        .HasOptional(e => e.vendor_relationship)
        //        .WithRequired(e => e.party_relationship);

        //    modelBuilder.Entity<party_role>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_role>()
        //        .HasOptional(e => e.driver)
        //        .WithRequired(e => e.party_role);

        //    modelBuilder.Entity<party_role>()
        //        .HasOptional(e => e.employee)
        //        .WithRequired(e => e.party_role);

        //    modelBuilder.Entity<party_role>()
        //        .HasOptional(e => e.leasing_company)
        //        .WithRequired(e => e.party_role);

        //    modelBuilder.Entity<party_role>()
        //        .HasMany(e => e.party_relationship)
        //        .WithOptional(e => e.party_role)
        //        .HasForeignKey(e => e.idparrolto);

        //    modelBuilder.Entity<party_role>()
        //        .HasMany(e => e.party_relationship1)
        //        .WithOptional(e => e.party_role1)
        //        .HasForeignKey(e => e.idparrolfro);

        //    modelBuilder.Entity<party_role>()
        //        .HasOptional(e => e.sales_broker)
        //        .WithRequired(e => e.party_role);

        //    modelBuilder.Entity<party_role>()
        //        .HasOptional(e => e.salesman)
        //        .WithRequired(e => e.party_role);

        //    modelBuilder.Entity<party_role_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_role_status>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<party_role_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<party_role_type>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    //modelBuilder.Entity<party_role_type>()
        //    //    .HasMany(e => e.bill_to)
        //    //    .WithOptional(e => e.party_role_type)
        //    //    .HasForeignKey(e => new { e.idparty, e.idroletype });

        //    modelBuilder.Entity<party_role_type>()
        //        .HasMany(e => e.ship_to)
        //        .WithOptional(e => e.party_role_type)
        //        .HasForeignKey(e => new { e.idparty, e.idroletype });

        //    modelBuilder.Entity<payment>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment>()
        //        .Property(e => e.paymentnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<payment>()
        //        .Property(e => e.amount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<payment>()
        //        .Property(e => e.refno)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<payment>()
        //        .HasOptional(e => e.disbursement)
        //        .WithRequired(e => e.payment);

        //    modelBuilder.Entity<payment>()
        //        .HasOptional(e => e.receipt)
        //        .WithRequired(e => e.payment);

        //    modelBuilder.Entity<payment_application>()
        //        .Property(e => e.idpayapp)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_application>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_application>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_application>()
        //        .Property(e => e.amountapplied)
        //        .HasPrecision(18, 4);

        //    //modelBuilder.Entity<payment_application>()
        //    //    .HasMany(e => e.requirements)
        //    //    .WithMany(e => e.payment_application)
        //    //    .Map(m => m.ToTable("requirement_payment").MapLeftKey("payments_id").MapRightKey("requirements_id"));

        //    modelBuilder.Entity<payment_application>()
        //        .HasMany(e => e.work_effort)
        //        .WithMany(e => e.payment_application)
        //        .Map(m => m.ToTable("work_effort_payment").MapLeftKey("payments_id").MapRightKey("work_efforts_id"));

        //    modelBuilder.Entity<payment_method_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<payment_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_role>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<payment_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_status>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<payment_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<payment_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<PendingReason>()
        //        .Property(e => e.DescPendingReason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.fname)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.lname)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.pob)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.bloodtype)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.gender)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.personalidnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.familyidnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.taxidnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.cellphone1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.cellphone2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.privatemail)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.phone)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<person>()
        //        .HasMany(e => e.organizations)
        //        .WithOptional(e => e.person)
        //        .HasForeignKey(e => e.idpic);

        //    modelBuilder.Entity<person>()
        //        .HasMany(e => e.organization_prospect)
        //        .WithOptional(e => e.person)
        //        .HasForeignKey(e => e.idpic);

        //    modelBuilder.Entity<person>()
        //        .HasMany(e => e.position_fullfillment)
        //        .WithOptional(e => e.person)
        //        .HasForeignKey(e => e.idperson);

        //    modelBuilder.Entity<person>()
        //        .HasMany(e => e.user_mediator)
        //        .WithOptional(e => e.person)
        //        .HasForeignKey(e => e.idperson);

        //    modelBuilder.Entity<person>()
        //        .HasMany(e => e.vehicle_document_requirement)
        //        .WithOptional(e => e.person)
        //        .HasForeignKey(e => e.idpersonowner);

        //    modelBuilder.Entity<person_prospect>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<person_prospect>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<person_suspect>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<person_suspect>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<personal_customer>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<PersonSosmed>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<PersonSosmed>()
        //        .Property(e => e.Username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idslip)
        //        .IsFixedLength();

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idinvite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idordite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc3)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc4)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc5)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc6)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.acc7)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.promat1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.promat2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.promatdirectgift)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idinternalmecha)
        //        .IsFixedLength();

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idexternalmecha)
        //        .IsFixedLength();

        //    modelBuilder.Entity<picking_slip>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.NoPkb)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.Lamentation)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.SubTotalPart)
        //        .HasPrecision(10, 2);

        //    modelBuilder.Entity<pkb>()
        //        .Property(e => e.SubTotalService)
        //        .HasPrecision(10, 2);

        //    modelBuilder.Entity<pkb>()
        //        .HasOptional(e => e.pkb_estimation)
        //        .WithRequired(e => e.pkb);

        //    modelBuilder.Entity<pkb>()
        //        .HasMany(e => e.pkb_service)
        //        .WithRequired(e => e.pkb)
        //        .WillCascadeOnDelete(false);

        //    modelBuilder.Entity<pkb_estimation>()
        //        .Property(e => e.EstimatedPrice)
        //        .HasPrecision(18, 0);

        //    modelBuilder.Entity<pkb_estimation>()
        //        .Property(e => e.DepositCust)
        //        .HasPrecision(18, 0);

        //    modelBuilder.Entity<pkb_estimation>()
        //        .Property(e => e.Dp)
        //        .HasPrecision(18, 0);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.NoPart)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.DiscPart)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.PricePart)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.DescPart)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_part>()
        //        .Property(e => e.SubTotal)
        //        .HasPrecision(10, 2);

        //    modelBuilder.Entity<pkb_part>()
        //        .HasOptional(e => e.pkb_part_billing_item)
        //        .WithRequired(e => e.pkb_part);

        //    modelBuilder.Entity<pkb_part_billing_item>()
        //        .Property(e => e.idbilite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.CodeService)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.DescService)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.PriceService)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.DiscService)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.FlatRate)
        //        .HasPrecision(5, 2);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.ChargeTo)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<pkb_service>()
        //        .Property(e => e.SubTotal)
        //        .HasPrecision(10, 2);

        //    modelBuilder.Entity<pkb_service>()
        //        .HasOptional(e => e.pkb_service_billing_item)
        //        .WithRequired(e => e.pkb_service);

        //    modelBuilder.Entity<pkb_service_billing_item>()
        //        .Property(e => e.idbilite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<PO>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<PO>()
        //        .Property(e => e.NoPo)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<PO>()
        //        .HasOptional(e => e.canceled_po)
        //        .WithRequired(e => e.PO);

        //    modelBuilder.Entity<po_status>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position_fullfillment>()
        //        .Property(e => e.idposition)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position_fullfillment>()
        //        .Property(e => e.idperson)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position_fullfillment>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position_reporting_structure>()
        //        .Property(e => e.idposfro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position_reporting_structure>()
        //        .Property(e => e.idposto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position_type>()
        //        .Property(e => e.title)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.idposition)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.idorganization)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.idusrmed)
        //        .IsFixedLength();

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<position>()
        //        .HasMany(e => e.position_reporting_structure)
        //        .WithOptional(e => e.position)
        //        .HasForeignKey(e => e.idposfro);

        //    modelBuilder.Entity<position>()
        //        .HasMany(e => e.position_reporting_structure1)
        //        .WithOptional(e => e.position1)
        //        .HasForeignKey(e => e.idposto);

        //    modelBuilder.Entity<positions_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<positions_status>()
        //        .Property(e => e.idposition)
        //        .IsFixedLength();

        //    modelBuilder.Entity<positions_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.address1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.address2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.district)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.village)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.city)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .Property(e => e.province)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<postal_address>()
        //        .HasMany(e => e.organizations)
        //        .WithOptional(e => e.postal_address)
        //        .HasForeignKey(e => e.idposaddtdp);

        //    modelBuilder.Entity<postal_address>()
        //        .HasMany(e => e.organization_prospect)
        //        .WithOptional(e => e.postal_address)
        //        .HasForeignKey(e => e.idposaddtdp);

        //    modelBuilder.Entity<postal_address>()
        //        .HasMany(e => e.shipments)
        //        .WithOptional(e => e.postal_address)
        //        .HasForeignKey(e => e.idposaddto);

        //    modelBuilder.Entity<postal_address>()
        //        .HasMany(e => e.shipments1)
        //        .WithOptional(e => e.postal_address1)
        //        .HasForeignKey(e => e.idposaddfro);

        //    modelBuilder.Entity<postal_address>()
        //        .HasMany(e => e.suspects)
        //        .WithOptional(e => e.postal_address)
        //        .HasForeignKey(e => e.idaddress);

        //    modelBuilder.Entity<price_agreement_item>()
        //        .Property(e => e.idagrite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<price_agreement_item>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.idpricom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.idagrite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.price)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<price_component>()
        //        .Property(e => e.manfucterprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<price_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product>()
        //        .HasOptional(e => e.good)
        //        .WithRequired(e => e.product);

        //    modelBuilder.Entity<product>()
        //        .HasMany(e => e.product_association)
        //        .WithOptional(e => e.product)
        //        .HasForeignKey(e => e.idproductfrom);

        //    modelBuilder.Entity<product>()
        //        .HasMany(e => e.product_association1)
        //        .WithOptional(e => e.product1)
        //        .HasForeignKey(e => e.idproductto);

        //    modelBuilder.Entity<product>()
        //        .HasOptional(e => e.service)
        //        .WithRequired(e => e.product);

        //    modelBuilder.Entity<product_association>()
        //        .Property(e => e.idproass)
        //        .IsFixedLength();

        //    modelBuilder.Entity<product_association>()
        //        .Property(e => e.idproductto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product_association>()
        //        .Property(e => e.idproductfrom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product_association>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<product_document>()
        //        .Property(e => e.iddocument)
        //        .IsFixedLength();

        //    modelBuilder.Entity<product_document>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product_document>()
        //        .Property(e => e.contenttype)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<product_purchase_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<product_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idbroker)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idsalesman)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idsalescoordinator)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.prospectnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.eveloc)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect>()
        //        .HasOptional(e => e.organization_prospect)
        //        .WithRequired(e => e.prospect);

        //    modelBuilder.Entity<prospect>()
        //        .HasOptional(e => e.person_prospect)
        //        .WithRequired(e => e.prospect);

        //    modelBuilder.Entity<prospect_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect_role>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect_source>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<prospect_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect_status>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<prospect_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<province>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<purchase_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<purchase_order>()
        //        .HasOptional(e => e.product_purchase_order)
        //        .WithRequired(e => e.purchase_order);

        //    modelBuilder.Entity<purchase_order>()
        //        .HasOptional(e => e.vehicle_purchase_order)
        //        .WithRequired(e => e.purchase_order);

        //    modelBuilder.Entity<purchase_request>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<purchase_request>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<purchase_request>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<purpose_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<queue>()
        //        .Property(e => e.NoQueue)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<queue>()
        //        .Property(e => e.CustomerName)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<queue>()
        //        .Property(e => e.VehicleNumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<queue_status>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<queue_type>()
        //        .Property(e => e.Type)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<quote>()
        //        .Property(e => e.idquote)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<quote>()
        //        .HasOptional(e => e.customer_quotation)
        //        .WithRequired(e => e.quote);

        //    modelBuilder.Entity<quote_item>()
        //        .Property(e => e.idquoteitem)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_item>()
        //        .Property(e => e.idquote)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_item>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<quote_item>()
        //        .Property(e => e.unitprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<quote_item>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<quote_role>()
        //        .Property(e => e.idrole)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<quote_role>()
        //        .Property(e => e.idquote)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<quote_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_status>()
        //        .Property(e => e.idquote)
        //        .IsFixedLength();

        //    modelBuilder.Entity<quote_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<reason_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<receipt>()
        //        .Property(e => e.idpayment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<receipt>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<receipt>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<receipt>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<regular_sales_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<relation_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<religion_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rem_part>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.idparentreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.requirementnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.budget)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<Requirement>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.purchase_request)
        //    //    .WithRequired(e => e.requirement);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasMany(e => e.requirement1)
        //    //    .WithOptional(e => e.requirement2)
        //    //    .HasForeignKey(e => e.idparentreq);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.sales_unit_requirement)
        //    //    .WithRequired(e => e.requirement);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.unit_requirement)
        //    //    .WithRequired(e => e.requirement);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.vehicle_document_requirement)
        //    //    .WithRequired(e => e.requirement);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.work_product_req)
        //    //    .WithRequired(e => e.requirement);

        //    //modelBuilder.Entity<Requirement>()
        //    //    .HasOptional(e => e.work_requirement)
        //    //    .WithRequired(e => e.requirement);

        //    modelBuilder.Entity<requirement_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<requirement_role>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<requirement_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<requirement_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<requirement_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<requirement_status>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<requirement_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<requirement_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<return_purchase_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<return_sales_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<role_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<role_type>()
        //        .HasMany(e => e.party_role_type)
        //        .WithRequired(e => e.role_type)
        //        .WillCascadeOnDelete(false);

        //    modelBuilder.Entity<rule_hot_item>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule_hot_item>()
        //        .Property(e => e.mindownpayment)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<rule_indent>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule_indent>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule_sales_discount>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule_sales_discount>()
        //        .Property(e => e.maxamount)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<rule_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<rule>()
        //        .HasOptional(e => e.rule_hot_item)
        //        .WithRequired(e => e.rule);

        //    modelBuilder.Entity<rule>()
        //        .HasOptional(e => e.rule_indent)
        //        .WithRequired(e => e.rule);

        //    modelBuilder.Entity<rule>()
        //        .HasOptional(e => e.rule_sales_discount)
        //        .WithRequired(e => e.rule);

        //    modelBuilder.Entity<SaleType>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<sale_type>()
        //    //    .HasMany(e => e.sale_type1)
        //    //    .WithOptional(e => e.sale_type2)
        //    //    .HasForeignKey(e => e.idparent);

        //    modelBuilder.Entity<sales_agreement>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_agreement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_agreement>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_broker>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_broker>()
        //        .Property(e => e.idbroker)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_broker>()
        //        .HasMany(e => e.prospects)
        //        .WithOptional(e => e.sales_broker)
        //        .HasForeignKey(e => e.idbroker);

        //    modelBuilder.Entity<sales_broker>()
        //        .HasMany(e => e.sales_unit_requirement)
        //        .WithOptional(e => e.sales_broker)
        //        .HasForeignKey(e => e.idsalesbroker);

        //    modelBuilder.Entity<sales_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_order>()
        //        .HasOptional(e => e.part_sales_order)
        //        .WithRequired(e => e.sales_order);

        //    modelBuilder.Entity<sales_order>()
        //        .HasOptional(e => e.regular_sales_order)
        //        .WithRequired(e => e.sales_order);

        //    modelBuilder.Entity<sales_order>()
        //        .HasOptional(e => e.vehicle_sales_order)
        //        .WithRequired(e => e.sales_order);

        //    modelBuilder.Entity<sales_point>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.idsallea)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.idleacom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.idlsgpro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_leasing>()
        //        .Property(e => e.ponumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idprospect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idsalesman)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idsalesbroker)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idowner)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idlsgpro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.downpayment)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idframe)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idmachine)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.subsfincomp)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.subsmd)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.subsown)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.subsahm)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.bbnprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.hetprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.note)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.unitprice)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.notepartner)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.shipmentnote)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.requestpoliceid)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.leasingpo)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.brokerfee)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .HasMany(e => e.vehicle_sales_order)
        //        .WithOptional(e => e.sales_unit_requirement)
        //        .HasForeignKey(e => e.idunitreq);

        //    modelBuilder.Entity<sales_unit_requirement>()
        //        .HasMany(e => e.vehicle_document_requirement)
        //        .WithOptional(e => e.sales_unit_requirement)
        //        .HasForeignKey(e => e.idslsreq);

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.idparrol)
        //        .IsFixedLength();

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.idcoordinator)
        //        .IsFixedLength();

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.idsalesman)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.coordinator)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.idteamleader)
        //        .IsFixedLength();

        //    modelBuilder.Entity<salesman>()
        //        .Property(e => e.teamleader)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.prospects)
        //        .WithOptional(e => e.salesman)
        //        .HasForeignKey(e => e.idsalescoordinator);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.prospects1)
        //        .WithOptional(e => e.salesman1)
        //        .HasForeignKey(e => e.idsalesman);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.sales_unit_requirement)
        //        .WithOptional(e => e.salesman)
        //        .HasForeignKey(e => e.idsalesman);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.salesman1)
        //        .WithOptional(e => e.salesman2)
        //        .HasForeignKey(e => e.idcoordinator);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.suspects)
        //        .WithOptional(e => e.salesman)
        //        .HasForeignKey(e => e.idsalesman);

        //    modelBuilder.Entity<salesman>()
        //        .HasMany(e => e.suspects1)
        //        .WithOptional(e => e.salesman1)
        //        .HasForeignKey(e => e.idsalescoordinator);

        //    modelBuilder.Entity<service>()
        //        .Property(e => e.iduom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service>()
        //        .Property(e => e.frt)
        //        .HasPrecision(12, 2);

        //    modelBuilder.Entity<service>()
        //        .Property(e => e.servicecode)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service>()
        //        .HasOptional(e => e.service_per_motor)
        //        .WithRequired(e => e.service);

        //    modelBuilder.Entity<service_agreement>()
        //        .Property(e => e.idagreement)
        //        .IsFixedLength();

        //    modelBuilder.Entity<service_agreement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service_agreement>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service_history>()
        //        .Property(e => e.CodeService)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service_history>()
        //        .Property(e => e.DescService)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<service_per_motor>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<ship_to>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<ship_to>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<ship_to>()
        //        .HasOptional(e => e.customer_ship_to)
        //        .WithRequired(e => e.ship_to);

        //    modelBuilder.Entity<ship_to>()
        //        .HasOptional(e => e.internal_ship_to)
        //        .WithRequired(e => e.ship_to);

        //    modelBuilder.Entity<ship_to>()
        //        .HasMany(e => e.package_receipt)
        //        .WithOptional(e => e.ship_to)
        //        .HasForeignKey(e => e.idshifro);

        //    modelBuilder.Entity<ship_to>()
        //        .HasMany(e => e.shipments)
        //        .WithOptional(e => e.ship_to)
        //        .HasForeignKey(e => e.idshito);

        //    modelBuilder.Entity<ship_to>()
        //        .HasMany(e => e.shipments1)
        //        .WithOptional(e => e.ship_to1)
        //        .HasForeignKey(e => e.idshifro);

        //    modelBuilder.Entity<ship_to>()
        //        .HasOptional(e => e.vendor_ship_to)
        //        .WithRequired(e => e.ship_to);

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idshipment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idposaddfro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idposaddto)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idshito)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.idshifro)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.shipmentnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment>()
        //        .HasOptional(e => e.shipment_incoming)
        //        .WithRequired(e => e.shipment);

        //    modelBuilder.Entity<shipment>()
        //        .HasOptional(e => e.shipment_outgoing)
        //        .WithRequired(e => e.shipment);

        //    modelBuilder.Entity<shipment_incoming>()
        //        .Property(e => e.idshipment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.idshiite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.idshipment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.contentdescription)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.idframe)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_item>()
        //        .Property(e => e.idmachine)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_item>()
        //        .HasMany(e => e.shipment_receipt)
        //        .WithMany(e => e.shipment_item)
        //        .Map(m => m.ToTable("shipment_receipt_shipment_item").MapLeftKey("shipment_items_id").MapRightKey("shipment_receipts_id"));

        //    modelBuilder.Entity<shipment_outgoing>()
        //        .Property(e => e.idshipment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_outgoing>()
        //        .Property(e => e.iddriver)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_outgoing>()
        //        .Property(e => e.dtbast)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_outgoing>()
        //        .Property(e => e.note)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_outgoing>()
        //        .Property(e => e.othername)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_package>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_package>()
        //        .HasOptional(e => e.package_receipt)
        //        .WithRequired(e => e.shipment_package);

        //    modelBuilder.Entity<shipment_package_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package_role>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_package_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package_status>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_package_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_package_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idreceipt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idpackage)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idordite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.code)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.qtyaccept)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.qtyreject)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.itemdescription)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idframe)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.idmachine)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc3)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc4)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc5)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc6)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt>()
        //        .Property(e => e.acc7)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt_role>()
        //        .Property(e => e.idreceipt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_receipt_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt_status>()
        //        .Property(e => e.idreceipt)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_receipt_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_status>()
        //        .Property(e => e.idshipment)
        //        .IsFixedLength();

        //    modelBuilder.Entity<shipment_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<shipment_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<SosmedType>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<standard_calendar>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<status_pkb>()
        //        .Property(e => e.DescStatusPkb)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<status_pkb>()
        //        .HasMany(e => e.pkbs)
        //        .WithOptional(e => e.status_pkb)
        //        .HasForeignKey(e => e.IdStatusPkbCust);

        //    modelBuilder.Entity<status_pkb>()
        //        .HasMany(e => e.pkbs1)
        //        .WithOptional(e => e.status_pkb1)
        //        .HasForeignKey(e => e.IdStatusPkbInternal);

        //    modelBuilder.Entity<StatusType>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    //modelBuilder.Entity<StatusType>()
        //    //    .HasMany(e => e.unit_deliverable)
        //    //    .WithOptional(e => e.status_type)
        //    //    .HasForeignKey(e => e.idconstatyp);

        //    //modelBuilder.Entity<StatusType>()
        //    //    .HasMany(e => e.unit_deliverable1)
        //    //    .WithOptional(e => e.status_type1)
        //    //    .HasForeignKey(e => e.idvndstatyp);

        //    modelBuilder.Entity<summary>()
        //        .Property(e => e.NjbMechanic)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<summary>()
        //        .Property(e => e.NscMechanic)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<summary>()
        //        .Property(e => e.TotalNjbMec)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<summary>()
        //        .Property(e => e.TotalNscMec)
        //        .HasPrecision(19, 4);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.suspectnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idsalescoordinator)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idsalesman)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idaddress)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.salesdt)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.marketname)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.repurchaseprob)
        //        .HasPrecision(4, 2);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.priority)
        //        .HasPrecision(4, 2);

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idlsgpro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect>()
        //        .HasOptional(e => e.organization_suspect)
        //        .WithRequired(e => e.suspect);

        //    modelBuilder.Entity<suspect>()
        //        .HasOptional(e => e.person_suspect)
        //        .WithRequired(e => e.suspect);

        //    modelBuilder.Entity<suspect_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect_role>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect_status>()
        //        .Property(e => e.idsuspect)
        //        .IsFixedLength();

        //    modelBuilder.Entity<suspect_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<suspect_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<sympthom_data_m>()
        //        .Property(e => e.DescSymptom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<telecomunication_number>()
        //        .Property(e => e.idcontact)
        //        .IsFixedLength();

        //    modelBuilder.Entity<telecomunication_number>()
        //        .Property(e => e.number)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<type_pkb>()
        //        .Property(e => e.DescType)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.iduntaccmap)
        //        .IsFixedLength();

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.idmotor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc1)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc2)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc3)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc3)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc4)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc4)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc5)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc5)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc6)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc6)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.acc7)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtyacc7)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.promat1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtypromat1)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.promat2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_accesories_mapper>()
        //        .Property(e => e.qtypromat2)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.iddeliverable)
        //        .IsFixedLength();

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.dtreceipt)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.dtdelivery)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.bastnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.identitynumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.cellphone)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.refnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_deliverable>()
        //        .Property(e => e.receiptnominal)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<unit_requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<unit_requirement>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<unit_requirement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<uom>()
        //        .Property(e => e.iduom)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<uom>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<uom>()
        //        .HasMany(e => e.uom_conversion)
        //        .WithOptional(e => e.uom)
        //        .HasForeignKey(e => e.iduomfro);

        //    modelBuilder.Entity<uom>()
        //        .HasMany(e => e.uom_conversion1)
        //        .WithOptional(e => e.uom1)
        //        .HasForeignKey(e => e.iduomto);

        //    modelBuilder.Entity<uom_conversion>()
        //        .Property(e => e.iduomto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<uom_conversion>()
        //        .Property(e => e.iduomfro)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<uom_conversion>()
        //        .Property(e => e.factor)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<uom_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_extra>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.idusrmed)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.idperson)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.email)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.firstname)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.lastname)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator_role>()
        //        .Property(e => e.idusrmed)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<user_mediator_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator_status>()
        //        .Property(e => e.idusrmed)
        //        .IsFixedLength();

        //    modelBuilder.Entity<user_mediator_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.idmachine)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.idframe)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.fuel)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.merkoil)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle>()
        //        .Property(e => e.ServiceBookNumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idslsreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idordite)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idpersonowner)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.note)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.atpmfaktur)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.bbn)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.othercost)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.policenumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.submissionno)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_document_requirement>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_identification>()
        //        .Property(e => e.idvehide)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_identification>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_identification>()
        //        .Property(e => e.vehiclenumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_identification>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_purchase_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_registration_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_billing>()
        //        .Property(e => e.idbilling)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_sales_billing>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.idunitreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.idleacom)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.shiptoowner)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.admslsnotapprovnote)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.afcnotapprovnote)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrnama1)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrnama2)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrnamamarket)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrwarna)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrtahunproduksi)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrangsuran)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrleasing)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrtglpengiriman)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrjampengiriman)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrtipepenjualan)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrdpmurni)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrtandajadi)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrtglpembayaran)
        //        .IsFixedLength()
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrsisa)
        //        .HasPrecision(18, 4);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrcatatantambahan)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_sales_order>()
        //        .Property(e => e.vrcatatan)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_service_history>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_service_history>()
        //        .Property(e => e.Location)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_service_history>()
        //        .Property(e => e.Km)
        //        .HasPrecision(10, 2);

        //    modelBuilder.Entity<vehicle_service_history>()
        //        .Property(e => e.JobSuggest)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_service_history>()
        //        .Property(e => e.MechanicName)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_type>()
        //        .Property(e => e.Description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.idmechanic)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.idvehide)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.vehiclenumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .HasOptional(e => e.estimation)
        //        .WithRequired(e => e.vehicle_work_requirement);

        //    modelBuilder.Entity<vehicle_work_requirement>()
        //        .HasOptional(e => e.work_order)
        //        .WithRequired(e => e.vehicle_work_requirement);

        //    modelBuilder.Entity<Vendor>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<Vendor>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vendor_bill_to>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_order>()
        //        .Property(e => e.idorder)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vendor_order>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_order>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_order>()
        //        .Property(e => e.idbillto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_order>()
        //        .HasOptional(e => e.purchase_order)
        //        .WithRequired(e => e.vendor_order);

        //    modelBuilder.Entity<vendor_order>()
        //        .HasOptional(e => e.return_purchase_order)
        //        .WithRequired(e => e.vendor_order);

        //    modelBuilder.Entity<vendor_product>()
        //        .Property(e => e.idvenpro)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vendor_product>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_product>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_product>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_relationship>()
        //        .Property(e => e.idparrel)
        //        .IsFixedLength();

        //    modelBuilder.Entity<vendor_relationship>()
        //        .Property(e => e.idvendor)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_relationship>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_ship_to>()
        //        .Property(e => e.idshipto)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<vendor_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<village>()
        //        .Property(e => e.idgeobou)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<we_service_type>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<we_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<we_type>()
        //        .HasOptional(e => e.we_service_type)
        //        .WithRequired(e => e.we_type);

        //    modelBuilder.Entity<we_type_good_standard>()
        //        .Property(e => e.idwegoostd)
        //        .IsFixedLength();

        //    modelBuilder.Entity<we_type_good_standard>()
        //        .Property(e => e.idproduct)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<we_type_good_standard>()
        //        .Property(e => e.qty)
        //        .HasPrecision(14, 4);

        //    modelBuilder.Entity<work_effort>()
        //        .Property(e => e.idwe)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort>()
        //        .Property(e => e.idfacility)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort>()
        //        .Property(e => e.name)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_effort>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_effort>()
        //        .HasOptional(e => e.work_service_requirement)
        //        .WithRequired(e => e.work_effort);

        //    modelBuilder.Entity<work_effort_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort_role>()
        //        .Property(e => e.idwe)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_effort_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort_status>()
        //        .Property(e => e.idwe)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_effort_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.idbooking)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.idvehicle)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.idbooslo)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.bookingnumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.vehiclenumber)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.idinternal)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order_booking>()
        //        .Property(e => e.idcustomer)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order_booking_role>()
        //        .Property(e => e.idrole)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking_role>()
        //        .Property(e => e.idbooking)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking_role>()
        //        .Property(e => e.idparty)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking_role>()
        //        .Property(e => e.username)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_order_booking_status>()
        //        .Property(e => e.idstatus)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking_status>()
        //        .Property(e => e.idbooking)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_order_booking_status>()
        //        .Property(e => e.reason)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<work_product_req>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_requirement>()
        //        .Property(e => e.idreq)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_requirement>()
        //        .HasOptional(e => e.vehicle_work_requirement)
        //        .WithRequired(e => e.work_requirement);

        //    modelBuilder.Entity<work_requirement>()
        //        .HasMany(e => e.work_service_requirement)
        //        .WithMany(e => e.work_requirement)
        //        .Map(m => m.ToTable("work_requirement_services").MapLeftKey("idreq").MapRightKey("idwe"));

        //    modelBuilder.Entity<work_service_requirement>()
        //        .Property(e => e.idwe)
        //        .IsFixedLength();

        //    modelBuilder.Entity<work_type>()
        //        .Property(e => e.description)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.ID)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.AUTHOR)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.FILENAME)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.EXECTYPE)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.MD5SUM)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.DESCRIPTION)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.COMMENTS)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.TAG)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.LIQUIBASE)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.CONTEXTS)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.LABELS)
        //        .IsUnicode(false);

        //    modelBuilder.Entity<databasechangelog>()
        //        .Property(e => e.DEPLOYMENT_ID)
        //        .IsUnicode(false);
        //}
    }
}
