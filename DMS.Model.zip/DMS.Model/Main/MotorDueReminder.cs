namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("motor_due_reminder")]
    public partial class MotorDueReminder
    {
        [Key]
        public int idreminder { get; set; }

        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idmotor { get; set; }
        public virtual Motor Motor { get; set; }

        public int? nservice1 { get; set; }

        public int? nservice2 { get; set; }

        public int? nservice3 { get; set; }

        public int? nservice4 { get; set; }

        public int? nservice5 { get; set; }

        public int? km { get; set; }

        public int? ndays { get; set; }

        
    }
}
