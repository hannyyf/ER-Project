namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("moving_slip")]
    public partial class MovingSlip
    {
        [Key]
        [MaxLength(16)]
        public byte[] idslip { get; set; }

        [ForeignKey("InventoryItemTo")]
        [MaxLength(16)]
        public byte[] idinviteto { get; set; }
        public InventoryItem InventoryItemTo { get; set; }

        [ForeignKey("ContainerFrom")]
        [MaxLength(16)]
        public byte[] idcontainerfrom { get; set; }
        public Container ContainerFrom { get; set; }

        [ForeignKey("ContainerTo")]
        [MaxLength(16)]
        public byte[] idcontainerto { get; set; }
        public Container ContainerTo { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        [ForeignKey("FacilityTo")]
        [MaxLength(16)]
        public byte[] idfacilityto { get; set; }
        public Facility FacilityTo { get; set; }

        [ForeignKey("FacilityFrom")]
        [MaxLength(16)]
        public byte[] idfacilityfrom { get; set; }
        public Facility FacilityFrom { get; set; }

        public decimal? qty { get; set; }

        
        //public virtual InventoryItem inventory_item1 { get; set; }

        //public virtual InventoryMovement inventory_movement { get; set; }
    }
}
