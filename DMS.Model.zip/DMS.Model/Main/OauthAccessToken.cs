namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("oauth_access_token")]
    public partial class OauthAccessToken
    {
        [StringLength(765)]
        public string token_id { get; set; }

        [Column(TypeName = "image")]
        public byte[] token { get; set; }

        [Key]
        [StringLength(765)]
        public string authentication_id { get; set; }

        [StringLength(150)]
        public string user_name { get; set; }

        [StringLength(765)]
        public string client_id { get; set; }

        [Column(TypeName = "image")]
        public byte[] authentication { get; set; }

        [StringLength(765)]
        public string refresh_token { get; set; }
    }
}
