namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("oauth_client_details")]
    public partial class OauthClientDetails
    {
        [Key]
        [StringLength(765)]
        public string client_id { get; set; }

        [StringLength(765)]
        public string resource_ids { get; set; }

        [StringLength(765)]
        public string client_secret { get; set; }

        [StringLength(765)]
        public string scope { get; set; }

        [StringLength(765)]
        public string authorized_grant_types { get; set; }

        [StringLength(765)]
        public string web_server_redirect_uri { get; set; }

        [StringLength(765)]
        public string authorities { get; set; }

        public int? access_token_validity { get; set; }

        public int? refresh_token_validity { get; set; }

        [Column(TypeName = "image")]
        public byte[] additional_information { get; set; }

        [Column(TypeName = "image")]
        public byte[] autoapprove { get; set; }
    }
}
