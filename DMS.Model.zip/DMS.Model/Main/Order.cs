namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("order")]
    public partial class Order
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public order()
        //{
        //    order_item = new HashSet<OrderItem>();
        //    orders_role = new HashSet<orders_role>();
        //    orders_status = new HashSet<orders_status>();
        //    payment_application = new HashSet<payment_application>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idorder { get; set; }

        [ForeignKey("OrderType")]
        public int? idordtyp { get; set; }
        public OrderType OrderType { get; set; }

        [StringLength(765)]
        public string ordernumber { get; set; }

        public DateTime? dtentry { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtorder { get; set; }
        public int? currenstatus { get; set; }

        public ICollection<OrderItem> OrderItem { get; set; }

        public ICollection<OrdersRole> OrdersRole { get; set; }

        public ICollection<OrdersStatus> OrderStatus { get; set; }

        public ICollection<PaymentApplication> PaymentApplication { get; set; }

        //public virtual CustomerOrder customer_order { get; set; }
        //public virtual vendor_order vendor_order { get; set; }
        //public virtual InternalOrder internal_order { get; set; }
    }

    public class OrdersDTO
    {
        [MaxLength(16)]
        public byte[] idorder { get; set; }
        [StringLength(765)]
        public string ordernumber { get; set; }
        public DateTime? dtentry { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtorder { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            OrdersDTO ordersDTO = (OrdersDTO)obj;
            if (ordersDTO.idorder == null || idorder == null)
            {
                return false;
            }
            return Object.Equals(idorder, ordersDTO.idorder);
        }

        public override int GetHashCode()
        {
            return idorder.GetHashCode();
        }
        public override string ToString()
        {
            return "OrdersDTO{" + "idorder='" + idorder + "', ordernumber='" + ordernumber + "',dtentry='" + dtentry + "',dtorder='" + dtorder + "'}";
        }

    }
}
