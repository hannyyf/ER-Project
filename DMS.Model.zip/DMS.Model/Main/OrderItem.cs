namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("order_item")]
    public partial class OrderItem
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public OrderItem()
        //{
        //    approvals = new HashSet<Approval>();
        //    order_item1 = new HashSet<OrderItem>();
        //    picking_slip = new HashSet<picking_slip>();
        //    shipment_receipt = new HashSet<shipment_receipt>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    billing_item = new HashSet<BillingItem>();
        //    requirements = new HashSet<requirement>();
        //    shipment_item = new HashSet<shipment_item>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idordite { get; set; }

        [ForeignKey("OrderItemParrent")]
        [MaxLength(16)]
        public byte[] idparordite { get; set; }
        public OrderItem OrderItemParrent { get; set; }

        [ForeignKey("Order")]
        [MaxLength(16)]
        public byte[] idorder { get; set; }
        public Order Order { get; set; }

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        [ForeignKey("Feature")]
        public int? idfeature { get; set; }
        public Feature Feature { get; set; }

        [StringLength(50)]
        public string itemdescription { get; set; }

        public decimal? qty { get; set; }

        public decimal? unitprice { get; set; }

        public decimal? discount { get; set; }

        public decimal? taxamount { get; set; }

        public decimal? totalamount { get; set; }

        [ForeignKey("ShipTo")]
        [StringLength(30)]
        public string idshipto { get; set; }
        public ShipTo ShipTo { get; set; }

        public ICollection<Approval> Approvals { get; set; }

        public ICollection<OrderItem> OrderItem1 { get; set; }

        public ICollection<PickingSlip> PickingSlip { get; set; }

        public ICollection<ShipmentReceipt> ShipmentReceipt { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }

        public ICollection<BillingItem> BillingItem { get; set; }

        public ICollection<Requirement> Requirements { get; set; }

        public ICollection<ShipmentItem> ShipmentItem { get; set; }
    }

    public class OrderItemDTO
    {
        [MaxLength(16)]
        public byte[] idordite { get; set; }
        [StringLength(30)]
        public string idproduct { get; set; }
        [StringLength(50)]
        public string itemdescription { get; set; }
        public int? idfeature { get; set; }
        [StringLength(30)]
        public string idshipto { get; set; }
        public decimal? qty { get; set; }

        public decimal? unitprice { get; set; }

        public decimal? discount { get; set; }

        public decimal? taxamount { get; set; }

        public decimal? totalamount { get; set; }

        public double? qtyreceipt;

        public double? qtyfilled;

        [MaxLength(16)]
        public byte[] idorder { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            OrderItemDTO orderItemDTO = (OrderItemDTO)obj;
            if (orderItemDTO.idordite == null || idordite == null)
            {
                return false;
            }
            return Object.Equals(idordite, orderItemDTO.idordite);
        }

        public override int GetHashCode()
        {
            return idordite.GetHashCode();
        }

        public override string ToString()
        {
            return "OrderItemDTO{" +
            "id=" + idordite +
            ", idProduct='" + idproduct + "'" +
            ", itemDescription='" + itemdescription + "'" +
            ", idFeature='" + idfeature + "'" +
            ", idShipTo='" + idshipto + "'" +
            ", qty='" + qty + "'" +
            ", unitPrice='" + unitprice + "'" +
            ", discount='" + discount + "'" +
            ", taxAmount='" + taxamount + "'" +
            ", totalAmount='" + totalamount + "'" +
            "}";
        }
    }
}
