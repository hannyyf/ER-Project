namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("order_type")]
    public partial class OrderType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public order_type()
        //{
        //    orders = new HashSet<Order>();
        //}
        [Key]
        public int idordtyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Order> Order { get; set; }
    }

    public class OrderTypeDTO
    {
        public int? idordtyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            OrderTypeDTO orderTypeDTO = (OrderTypeDTO)obj;
            if (orderTypeDTO.idordtyp == null || idordtyp == null)
            {
                return false;
            }
            return Object.Equals(idordtyp, orderTypeDTO.idordtyp);
        }

        public override int GetHashCode()
        {
            return idordtyp.GetHashCode();
        }

        public override string ToString()
        {
            return "OrderTypeDTO{" +
            "id=" + idordtyp +
            ", description='" + description + "'" +
            "}";
        }
    }
}
