namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("organization")]
    public partial class Organization :Party
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public organization()
        //{
        //    internals = new HashSet<_internal>();
        //    organization_suspect = new HashSet<organization_suspect>();
        //    organization_prospect = new HashSet<organization_prospect>();
        //    positions = new HashSet<position>();
        //    vendors = new HashSet<Vendor>();
        //}

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idpic { get; set; }
        public Person Person { get; set; }

        [ForeignKey("PostalAddress")]
        [MaxLength(16)]
        public byte[] idposaddtdp { get; set; }
        public PostalAddress PostalAddress { get; set; }

        [StringLength(30)]
        public string name { get; set; }

        [StringLength(30)]
        public string numbertdp { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtestablised { get; set; }

        public ICollection<_internal> Internals { get; set; }

        public ICollection<OrganizationSuspect> OrganizationSuspect { get; set; }

        public ICollection<OrganizationProspect> OrganizationProspect { get; set; }

        public ICollection<Position> Positions { get; set; }

        public ICollection<Vendor> Vendors { get; set; }
    }

    public class OrganizationDTO:PartyDTO
    {

        [StringLength(30)]
        public string numbertdp { get; set; }
        [Column(TypeName = "date")]
        public DateTime? dtestablised { get; set; }
        public string officemail { get; set; }
        public string officephone { get; set; }
        public string officefax { get; set; }
        //private PostalAddressDTO postalAddress = new PostalAddressDTO();

        public override string ToString()
        {
            return "OrganizationDTO{" +
            "id=" + idparty +
            ", name='" + name + "'" +
            ", numberTDP='" + numbertdp + "'" +
            ", dateOrganizationEstablish='" + dtestablised + "'" +
            "}";
        }

    }
}
