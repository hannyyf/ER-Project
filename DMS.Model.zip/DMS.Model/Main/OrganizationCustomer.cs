namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("organization_customer")]
    public partial class OrganizationCustomer :Customer
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public organization_customer()
        //{
        //    sales_agreement = new HashSet<SalesAgreement>();
        //    service_agreement = new HashSet<ServiceAgreement>();
        //}

        public ICollection<SalesAgreement> SalesAgreement { get; set; }
        public ICollection<ServiceAgreement> ServiceAgreement { get; set; }
    }
}
