namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("organization_prospect")]
    public partial class OrganizationProspect :Prospect
    {
        [ForeignKey("Organization")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Organization Organization { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idpic { get; set; }
        public Person Person { get; set; }

        [ForeignKey("PostalAddress")]
        [MaxLength(16)]
        public byte[] idposaddtdp { get; set; }
        public PostalAddress PostalAddress { get; set; }


    }
}
