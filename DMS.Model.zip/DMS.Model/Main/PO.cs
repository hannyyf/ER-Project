namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PO")]
    public partial class PO
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public PO()
        //{
        //    do_opl = new HashSet<DoOpl>();
        //    po_detail_service = new HashSet<PoDetailService>();
        //    po_detail_part = new HashSet<PoDetailPart>();
        //}

        [Key]
        public int IdPo { get; set; }

        [ForeignKey("PoStatus")]
        public int? IdPoStatus { get; set; }
        public PoStatus PoStatus { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [StringLength(30)]
        public string NoPo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DatePo { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        //public virtual CanceledPo canceled_po { get; set; }

        public ICollection<DoOpl> DoOpl { get; set; }

        public ICollection<PoDetailService> PoDetailService { get; set; }

        public ICollection<PoDetailPart> PoDetailPart { get; set; }

        

        
    }
}
