namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("package_receipt")]
    public partial class PackageReceipt :ShipmentPackage
    {

        [ForeignKey("ShipTo")]
        [StringLength(30)]
        public string idshifro { get; set; }
        public ShipTo ShipTo { get; set; }

        [StringLength(50)]
        public string documentnumber { get; set; }

        

    }
}
