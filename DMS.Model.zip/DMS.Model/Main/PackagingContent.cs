namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("packaging_content")]
    public partial class PackagingContent
    {
        [Key]
        [MaxLength(16)]
        public byte[] idpaccon { get; set; }

        [ForeignKey("ShipmentPackage")]
        [MaxLength(16)]
        public byte[] idpackage { get; set; }
        public ShipmentPackage ShipmentPackage { get; set; }

        [ForeignKey("ShipmentItem")]
        [MaxLength(16)]
        public byte[] idshiite { get; set; }
        public ShipmentItem ShipmentItem { get; set; }

        public decimal? qty { get; set; }

        

        
    }
}
