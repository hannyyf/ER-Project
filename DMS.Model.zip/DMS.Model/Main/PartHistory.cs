namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("part_history")]
    public partial class PartHistory
    {
        [Key]
        public int IdPartHistory { get; set; }

        [ForeignKey("ServiceHistory")]
        public int? IdServiceHistory { get; set; }
        public ServiceHistory ServiceHistory { get; set; }

        [StringLength(10)]
        public string NoPart { get; set; }

        [StringLength(30)]
        public string DescPart { get; set; }

        public int? Qty { get; set; }

        
    }
}
