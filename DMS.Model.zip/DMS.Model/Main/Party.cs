namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party")]
    public partial class Party
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Party()
        //{
        //    agreement_role = new HashSet<agreement_role>();
        //    billing_role = new HashSet<BillingRole>();
        //    communication_event_role = new HashSet<communication_event_role>();
        //    customers = new HashSet<Customer>();
        //    inventory_item = new HashSet<inventory_item>();
        //    orders_role = new HashSet<orders_role>();
        //    party_contact_mechanism = new HashSet<party_contact_mechanism>();
        //    party_document = new HashSet<PartyDocument>();
        //    party_facility_purpose = new HashSet<party_facility_purpose>();
        //    party_role_type = new HashSet<party_role_type>();
        //    party_role = new HashSet<party_role>();
        //    payment_role = new HashSet<payment_role>();
        //    price_component = new HashSet<price_component>();
        //    prospect_role = new HashSet<prospect_role>();
        //    quote_role = new HashSet<quote_role>();
        //    requirement_role = new HashSet<requirement_role>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    shipment_receipt_role = new HashSet<shipment_receipt_role>();
        //    shipment_package_role = new HashSet<shipment_package_role>();
        //    suspect_role = new HashSet<suspect_role>();
        //    user_mediator_role = new HashSet<user_mediator_role>();
        //    work_effort_role = new HashSet<work_effort_role>();
        //    work_order_booking_role = new HashSet<work_order_booking_role>();
        //    category_party = new HashSet<category_party>();
        //    contact_mechanism = new HashSet<contact_mechanism>();
        //    facilities = new HashSet<facility>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idparty { get; set; }

        public int? idtype { get; set; }

        //public virtual organization organization { get; set; }
        //public virtual person person { get; set; }

        public ICollection<AgreementRole> AgreementRole { get; set; }

        public ICollection<BillingRole> BillingRole { get; set; }

        public ICollection<CommunicationEventRole> CommunicationEventRole { get; set; }

        public ICollection<Customer> Customer { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }

        public ICollection<OrdersRole> OrdersRole { get; set; }

        public ICollection<PartyContactMechanism> PartyContactMechanism { get; set; }

        public ICollection<PartyDocument> PartyDocument { get; set; }

        public ICollection<PartyFacilityPurpose> PartyFacilityPurpose { get; set; }

        public ICollection<PartyRoleType> PartyRoleType { get; set; }

        public ICollection<PartyRole> PartyRole { get; set; }

        public ICollection<PaymentRole> PaymentRole { get; set; }

        public ICollection<PriceComponent> PriceComponent { get; set; }

        public ICollection<ProspectRole> ProspectRole { get; set; }

        public ICollection<QuoteRole> QuoteRole { get; set; }

        public ICollection<RequirementRole> RequirementRole { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public ICollection<ShipmentReceiptRole> ShipmentReceiptRole { get; set; }

        public ICollection<ShipmentPackageRole> ShipmentPackageRole { get; set; }

        public ICollection<SuspectRole> SuspectRole { get; set; }

        public ICollection<UserMediatorRole> UserMediatorRole { get; set; }

        public ICollection<WorkEffortRole> WorkEffortRole { get; set; }

        public ICollection<WorkOrderBookingRole> WorkOrderBookingRole { get; set; }

        public ICollection<CategoryParty> CategoryParty { get; set; }

        public ICollection<ContactMechanism> ContactMechanism { get; set; }

        public ICollection<Facility> Facilities { get; set; }
    }

    public class PartyDTO
    {
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public string name { get; set; }

        public override int GetHashCode()
        {
            return idparty.GetHashCode();
        }

        public override string ToString()
        {
            return "PartyDTO{" + "id=" + idparty + ", name='" + name + "}";
        }
    }
}
