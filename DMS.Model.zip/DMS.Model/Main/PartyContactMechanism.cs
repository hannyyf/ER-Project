namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_contact_mechanism")]
    public partial class PartyContactMechanism
    {
        [Key]
        public int idparcon { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("ContactMechanism")]
        [MaxLength(16)]
        public byte[] idcontact { get; set; }
        public ContactMechanism ContactMechanism { get; set; }

        [ForeignKey("PurposeType")]
        public int? idpurposetype { get; set; }
        public PurposeType PurposeType { get; set; }
        
        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
       
    }
}
