namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_document")]
    public partial class PartyDocument :Document
    {
        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [StringLength(30)]
        public string contenttype { get; set; }

        [Column(TypeName = "image")]
        public byte[] content { get; set; }

    }
}
