namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_facility_purpose")]
    public partial class PartyFacilityPurpose
    {
        [Key]
        [MaxLength(16)]
        public byte[] idparfacpur { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("PurposeType")]
        public int? idpurposetype { get; set; }
        public PurposeType PurposeType { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        

        

        
    }
}
