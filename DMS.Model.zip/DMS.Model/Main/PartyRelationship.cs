namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_relationship")]
    public partial class PartyRelationship
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public party_relationship()
        //{
        //    communication_event = new HashSet<CommunicationEvent>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idparrel { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [ForeignKey("RelationType")]
        public int? idreltyp { get; set; }
        public RelationType RelationType { get; set; }

        [ForeignKey("PartyRoleFro")]
        [MaxLength(16)]
        public byte[] idparrolfro { get; set; }
        public PartyRole PartyRoleFro { get; set; }

        [ForeignKey("PartyRoleTo")]
        [MaxLength(16)]
        public byte[] idparrolto { get; set; }
        public PartyRole PartyRoleTo { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        public ICollection<CommunicationEvent> CommunicationEvent { get; set; }

        //public virtual CustomerRelationship customer_relationship { get; set; }

        //public virtual vendor_relationship vendor_relationship { get; set; }
    }
}
