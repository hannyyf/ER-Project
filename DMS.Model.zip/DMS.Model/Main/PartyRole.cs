namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_role")]
    public partial class PartyRole
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public party_role()
        //{
        //    party_relationship = new HashSet<PartyRelationship>();
        //    party_relationship1 = new HashSet<PartyRelationship>();
        //    party_role_status = new HashSet<party_role_status>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idparrol { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        public DateTime? dtregister { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        //public virtual Driver driver { get; set; }

        //public virtual Employee employee { get; set; }

        //public virtual LeasingCompany leasing_company { get; set; }

        public ICollection<PartyRelationship> PartyRelationship { get; set; }

        public ICollection<PartyRelationship> PartyRelationship1 { get; set; }

        public ICollection<PartyRoleStatus> PartyRoleStatus { get; set; }

        //public virtual sales_broker sales_broker { get; set; }

        //public virtual salesman salesman { get; set; }
    }

    public class PartyRoleDTO
    {
        [MaxLength(16)]
        public byte[] idparrol { get; set; }
        public DateTime? dtregister { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public string partyname { get; set; }
        public int currentstatus { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            PartyRoleDTO partyRoleDTO = (PartyRoleDTO)obj;
            if (partyRoleDTO.idparrol == null || idparrol == null)
            {
                return false;
            }
            return Object.Equals(idparrol, partyRoleDTO.idparrol);
        }

        public override int GetHashCode()
        {
            return idparrol.GetHashCode();
        }

        public override string ToString()
        {
            return "PartyRoleDTO{" +
            "id=" + idparrol +
            ", dateRegister='" + dtregister + "'" +
            ", dateFrom='" + dtfrom + "'" +
            ", dateThru='" + dtthru + "'" +
            "}";
        }

    }
}
