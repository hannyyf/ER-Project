namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("party_role_type")]
    public partial class PartyRoleType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public party_role_type()
        //{
        //    bill_to = new HashSet<BillTo>();
        //    ship_to = new HashSet<ship_to>();
        //}

        [Key]
        [Column(Order = 0)]
        [MaxLength(16)]
        public byte[] idparty { get; set; }

        [Key]
        [Column(Order = 1)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idroletype { get; set; }

        public ICollection<BillTo> BillTo { get; set; }

        //public virtual Party party { get; set; }

        //public virtual role_type role_type { get; set; }

        public ICollection<ShipTo> ShipTo { get; set; }
    }
}
