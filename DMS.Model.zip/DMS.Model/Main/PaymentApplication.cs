namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("payment_application")]
    public partial class PaymentApplication
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public payment_application()
        //{
        //    orders = new HashSet<Order>();
        //    requirements = new HashSet<Requirement>();
        //    work_effort = new HashSet<work_effort>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idpayapp { get; set; }

        [ForeignKey("Payment")]
        [MaxLength(16)]
        public byte[] idpayment { get; set; }
        public Payment Payment { get; set; }

        [ForeignKey("BillingAccount")]
        public int? idbilacc { get; set; }
        public virtual BillingAccount BillingAccount { get; set; }

        [ForeignKey("Billing")]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        public virtual Billing Billing { get; set; }

        public decimal? amountapplied { get; set; }

        public ICollection<Order> Order { get; set; }

        public ICollection<Requirement> Requirement { get; set; }

        public ICollection<WorkEffort> WorkEffort { get; set; }
    }
}
