namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("payment_method_type")]
    public partial class PaymentMethodType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public payment_method_type()
        //{
        //    payments = new HashSet<Payment>();
        //    pkbs = new HashSet<pkb>();
        //}

        [Key]
        public int idpaymettyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Payment> Payment { get; set; }

        public ICollection<Pkb> Pkbs { get; set; }
    }
}
