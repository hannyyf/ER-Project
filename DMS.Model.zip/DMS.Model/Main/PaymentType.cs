namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("payment_type")]
    public partial class PaymentType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public payment_type()
        //{
        //    payments = new HashSet<Payment>();
        //}

        [Key]
        public int idpaytyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }
        public ICollection<Payment> Payment { get; set; }
    }
}
