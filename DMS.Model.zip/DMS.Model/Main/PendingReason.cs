namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PendingReason")]
    public partial class PendingReason
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public PendingReason()
        //{
        //    job_history = new HashSet<JobHistory>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdPendingReason { get; set; }

        [StringLength(250)]
        public string DescPendingReason { get; set; }

        public DateTime? LastModifiedDate { get; set; }

        public int? StatusCode { get; set; }

        public ICollection<JobHistory> JobHistory { get; set; }
    }
}
