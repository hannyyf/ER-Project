namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("person_prospect")]
    public partial class PersonProspect :Prospect
    {

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Person Person { get; set; }
        
    }
}
