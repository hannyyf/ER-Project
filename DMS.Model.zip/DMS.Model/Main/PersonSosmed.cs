namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PersonSosmed")]
    public partial class PersonSosmed
    {
        [Key]
        public int IdSosmed { get; set; }

        [ForeignKey("SosmedType")]
        public int? IdSosmedType { get; set; }
        public SosmedType SosmedType { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Person Person { get; set; }

        [StringLength(30)]
        public string Username { get; set; }
    }
}
