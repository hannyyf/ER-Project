namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("picking_slip")]
    public partial class PickingSlip: InventoryMovement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public picking_slip()
        //{
        //    item_issuance = new HashSet<ItemIssuance>();
        //}

        [ForeignKey("InventoryItem")]
        [MaxLength(16)]
        public byte[] idinvite { get; set; }
        public InventoryItem InventoryItem { get; set; }

        [ForeignKey("OrderItem")]
        [MaxLength(16)]
        public byte[] idordite { get; set; }
        public OrderItem OrderItem { get; set; }

        [StringLength(5)]
        public string acc1 { get; set; }

        [StringLength(5)]
        public string acc2 { get; set; }

        [StringLength(5)]
        public string acc3 { get; set; }

        [StringLength(5)]
        public string acc4 { get; set; }

        [StringLength(5)]
        public string acc5 { get; set; }

        [StringLength(5)]
        public string acc6 { get; set; }

        [StringLength(5)]
        public string acc7 { get; set; }

        [StringLength(5)]
        public string promat1 { get; set; }

        [StringLength(5)]
        public string promat2 { get; set; }

        [StringLength(5)]
        public string promatdirectgift { get; set; }

        [MaxLength(16)]
        public byte[] idinternalmecha { get; set; }

        [MaxLength(16)]
        public byte[] idexternalmecha { get; set; }

        [ForeignKey("ShipTo")]
        [StringLength(30)]
        public string idshipto { get; set; }
        public ShipTo ShipTo { get; set; }

        public ICollection<ItemIssuance> ItemIssuance { get; set; }

    }
}
