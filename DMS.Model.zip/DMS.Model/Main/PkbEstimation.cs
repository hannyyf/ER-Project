namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PkbEstimation")]
    public partial class PkbEstimation :Pkb
    {
        public decimal? EstimatedPrice { get; set; }

        public decimal? DepositCust { get; set; }

        public decimal? Dp { get; set; }

        public bool? BeAwaited { get; set; }

        public int? EstimatedDuration { get; set; }

        public int? HoursRegist { get; set; }

        public int? EstimatedStart { get; set; }

        public int? EstimatedFinish { get; set; }

    }
}
