namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("pkb_part")]
    public partial class PkbPart
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public pkb_part()
        //{
        //    po_detail_part = new HashSet<po_detail_part>();
        //}

        [Key]
        public int IdPkbPart { get; set; }

        [ForeignKey("PkbService")]
        public int? IdPkbService { get; set; }
        public PkbService PkbService { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        [StringLength(100)]
        public string NoPart { get; set; }

        public int? qty { get; set; }

        public int? Het { get; set; }

        [Column(TypeName = "money")]
        public decimal? DiscPart { get; set; }

        [Column(TypeName = "money")]
        public decimal? PricePart { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public bool? IsClaimHotLine { get; set; }

        [StringLength(50)]
        public string DescPart { get; set; }

        public decimal? SubTotal { get; set; }

        //public virtual pkb_part_billing_item pkb_part_billing_item { get; set; }

        public ICollection<PoDetailPart> PoDetailPart { get; set; }
    }
}
