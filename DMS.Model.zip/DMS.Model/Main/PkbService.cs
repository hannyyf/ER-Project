namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("pkb_service")]
    public partial class PkbService
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public pkb_service()
        //{
        //    pkb_part = new HashSet<pkb_part>();
        //    po_detail_service = new HashSet<po_detail_service>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdPkbService { get; set; }

        [ForeignKey("Pkb")]
        public int IdPkb { get; set; }
        public Pkb Pkb { get; set; }

        [ForeignKey("Service")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Service Service { get; set; }

        [Required]
        [StringLength(3)]
        public string CodeService { get; set; }

        [StringLength(30)]
        public string DescService { get; set; }

        [Column(TypeName = "money")]
        public decimal? PriceService { get; set; }

        [Column(TypeName = "money")]
        public decimal? DiscService { get; set; }

        public decimal? FlatRate { get; set; }

        [StringLength(20)]
        public string ChargeTo { get; set; }

        public bool? IsSuggestedByMechanic { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public decimal? SubTotal { get; set; }

        public ICollection<PkbPart> PkbPart { get; set; }

        //public virtual pkb_service_billing_item pkb_service_billing_item { get; set; }
        public ICollection<PoDetailService> PoDetailService { get; set; }
    }
}
