namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("pkb_service_billing_item")]
    public partial class PkbServiceBillingItem :PkbService
    {
        [ForeignKey("BillingItem")]
        [MaxLength(16)]
        public byte[] idbilite { get; set; }
        public BillingItem BillingItem { get; set; }
    }
}
