namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("po_detail_part")]
    public partial class PoDetailPart
    {
        [Key]
        public int IdPoPart { get; set; }

        [ForeignKey("PkbPart")]
        public int? IdPkbPart { get; set; }
        public PkbPart PkbPart { get; set; }

        [ForeignKey("PO")]
        public int? IdPo { get; set; }
        public PO PO { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModefiedUserId { get; set; }

        public int? StatusCode { get; set; }

    }
}
