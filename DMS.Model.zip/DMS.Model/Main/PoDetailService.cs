namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("po_detail_service")]
    public partial class PoDetailService
    {
        [Key]
        public int IdPoService { get; set; }

        [ForeignKey("PkbService")]
        public int? IdPkbService { get; set; }
        public PkbService PkbService { get; set; }

        [ForeignKey("PO")]
        public int? IdPo { get; set; }
        public virtual PO PO { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }
        
    }
}
