namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("po_status")]
    public partial class PoStatus
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public po_status()
        //{
        //    POes = new HashSet<PO>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdPoStatus { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [StringLength(30)]
        public string Description { get; set; }

        public ICollection<PO> POes { get; set; }

        
    }
}
