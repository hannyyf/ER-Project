namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("position_fullfillment")]
    public partial class PositionFullfillment
    {
        [Key]
        public int idposfulfil { get; set; }

        [ForeignKey("Position")]
        [MaxLength(16)]
        public byte[] idposition { get; set; }
        public Position Position { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idperson { get; set; }
        public Person Person { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        
    }
}
