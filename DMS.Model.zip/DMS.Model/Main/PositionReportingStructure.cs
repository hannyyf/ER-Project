namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("position_reporting_structure")]
    public partial class PositionReportingStructure
    {
        [Key]
        public int idposrepstru { get; set; }
        
        [ForeignKey("PositionFro")]
        [MaxLength(16)]
        public byte[] idposfro { get; set; }
        public Position PositionFro { get; set; }

        [ForeignKey("PositionTo")]
        [MaxLength(16)]
        public byte[] idposto { get; set; }
        public Position PositionTo { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
        
    }
}
