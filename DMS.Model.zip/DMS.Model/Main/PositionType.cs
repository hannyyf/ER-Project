namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("position_type")]
    public partial class PositionType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public position_type()
        //{
        //    positions = new HashSet<Position>();
        //    jhi_authority = new HashSet<JhiAuthority>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idpostyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [StringLength(30)]
        public string title { get; set; }

        public ICollection<Position> Position { get; set; }
        public ICollection<JhiAuthority> JhiAuthority { get; set; }
    }
}
