namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("postal_address")]
    public partial class PostalAddress :ContactMechanism
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public postal_address()
        //{
        //    organizations = new HashSet<organization>();
        //    organization_prospect = new HashSet<organization_prospect>();
        //    shipments = new HashSet<shipment>();
        //    shipments1 = new HashSet<shipment>();
        //    suspects = new HashSet<suspect>();
        //}

        //public ContactMechanism ContactMechanism { get; set; }

        [StringLength(60)]
        public string address1 { get; set; }

        [StringLength(60)]
        public string address2 { get; set; }

        [StringLength(60)]
        public string district { get; set; }

        [StringLength(60)]
        public string village { get; set; }

        [StringLength(60)]
        public string city { get; set; }

        [StringLength(60)]
        public string province { get; set; }

        public virtual ICollection<Organization> Organizations { get; set; }

        public virtual ICollection<OrganizationProspect> OrganizationProspect { get; set; }

        public virtual ICollection<Shipment> Shipments { get; set; }

        public virtual ICollection<Shipment> Shipments1 { get; set; }

        public virtual ICollection<Suspect> Suspects { get; set; }
    }

    public class PostalAddressDTO : ContactMechanismDTO
    {
        [StringLength(60)]
        public string address1 { get; set; }

        [StringLength(60)]
        public string address2 { get; set; }

        [StringLength(60)]
        public string districtname { get; set; }

        [StringLength(60)]
        public string villagename { get; set; }

        [StringLength(60)]
        public string cityname { get; set; }

        [StringLength(60)]
        public string provincename { get; set; }
    }
}
