namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("price_agreement_item")]
    public partial class PriceAgreementItem :AgreementItem
    {

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

    }
}
