namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("price_component")]
    public partial class PriceComponent
    {
        [Key]
        [MaxLength(16)]
        public byte[] idpricom { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        [ForeignKey("PriceType")]
        public int? idpricetype { get; set; }
        public PriceType PriceType { get; set; }

        [ForeignKey("CategoryParty")]
        public int? idparcat { get; set; }
        public CategoryParty CategoryParty { get; set; }

        [ForeignKey("CategoryProduct")]
        public int? idprocat { get; set; }
        public CategoryProduct CategoryProduct { get; set; }

        [ForeignKey("GeoBoundary")]
        [StringLength(36)]
        public string idgeobou { get; set; }
        public GeoBoundary GeoBoundary { get; set; }

        [ForeignKey("AgreementItem")]
        [MaxLength(16)]
        public byte[] idagrite { get; set; }
        public AgreementItem AgreementItem { get; set; }

        public decimal? price { get; set; }

        public decimal? manfucterprice { get; set; }

        public double? percent { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        
    }
}
