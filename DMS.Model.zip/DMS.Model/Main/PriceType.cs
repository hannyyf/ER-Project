namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("price_type")]
    public partial class PriceType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public PriceType()
        //{
        //    price_component = new HashSet<PriceComponent>();
        //}

        [Key]
        public int idpricetype { get; set; }

        [ForeignKey("RuleType")]
        public int? idrultyp { get; set; }
        public RuleType RuleType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<PriceComponent> PriceComponent { get; set; }

        
    }
}
