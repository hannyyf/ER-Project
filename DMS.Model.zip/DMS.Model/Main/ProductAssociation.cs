namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("product_association")]
    public partial class ProductAssociation
    {
        [Key]
        [MaxLength(16)]
        public byte[] idproass { get; set; }

        [ForeignKey("AssociationType")]
        public int? idasstyp { get; set; }
        public AssociationType AssociationType { get; set; }

        [ForeignKey("ProductTo")]
        [StringLength(30)]
        public string idproductto { get; set; }
        public Product ProductTo { get; set; }

        [ForeignKey("ProductFrom")]
        [StringLength(30)]
        public string idproductfrom { get; set; }
        public Product ProductFrom { get; set; }

        public decimal? qty { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        
    }
}
