namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("product_document")]
    public partial class ProductDocument :Document
    {

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        [StringLength(30)]
        public string contenttype { get; set; }

        [Column(TypeName = "image")]
        public byte[] content { get; set; }

        
    }
}
