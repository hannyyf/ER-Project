namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("product_type")]
    public partial class ProductType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public product_type()
        //{
        //    products = new HashSet<Product>();
        //}

        [Key]
        public int idprotyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Product> Product { get; set; }
    }
}
