namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("prospect_source")]
    public partial class ProspectSources
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public prospect_source()
        //{
        //    prospects = new HashSet<Prospect>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idprosou { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Prospect> Prospect { get; set; }
    }
}
