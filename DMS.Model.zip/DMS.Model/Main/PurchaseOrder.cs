namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("purchase_order")]
    public partial class PurchaseOrder : VendorOrder
    {
        //[Key]
        //[MaxLength(16)]
        //public byte[] idorder { get; set; }
        //public virtual vendor_order vendor_order { get; set; }

        public ProductPurchaseOrder ProductPurchaseOrder { get; set; }
        
        public VehiclePurchaseOrder VehiclePurchaseOrder { get; set; }
    }
}
