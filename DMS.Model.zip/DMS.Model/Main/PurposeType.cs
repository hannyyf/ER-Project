namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("purpose_type")]
    public partial class PurposeType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public PurposeType()
        //{
        //    facility_contact_mechanism = new HashSet<facility_contact_mechanism>();
        //    party_contact_mechanism = new HashSet<party_contact_mechanism>();
        //    party_facility_purpose = new HashSet<party_facility_purpose>();
        //    communication_event = new HashSet<communication_event>();
        //    contact_mechanism = new HashSet<contact_mechanism>();
        //}

        [Key]
        public int idpurposetype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<FacilityContactMechanism> FacilityContactMechanism { get; set; }

        public ICollection<PartyContactMechanism> PartyContactMechanism { get; set; }

        public ICollection<PartyFacilityPurpose> PartyFacilityPurpose { get; set; }

        public ICollection<CommunicationEvent> CommunicationEvent { get; set; }

        public ICollection<ContactMechanism> ContactMechanism { get; set; }
    }
}
