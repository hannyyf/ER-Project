namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("queue_status")]
    public partial class QueueStatus
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public queue_status()
        //{
        //    queues = new HashSet<Queue>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdQueueStatus { get; set; }

        [StringLength(30)]
        public string Description { get; set; }

        public ICollection<Queue> Queue { get; set; }
    }
}
