namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("quote_item")]
    public partial class QuoteItem
    {
        [Key]
        [MaxLength(16)]
        public byte[] idquoteitem { get; set; }

        [ForeignKey("Quote")]
        [MaxLength(16)]
        public byte[] idquote { get; set; }
        public Quote Quote { get; set; }

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        public decimal? unitprice { get; set; }

        public decimal? qty { get; set; }
        
    }
}
