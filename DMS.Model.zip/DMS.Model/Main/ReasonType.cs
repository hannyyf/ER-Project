namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("reason_type")]
    public partial class ReasonType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public reason_type()
        //{
        //    agreement_status = new HashSet<AgreementStatus>();
        //    billing_status = new HashSet<BillingStatus>();
        //    carriers = new HashSet<carrier>();
        //    communication_event_status = new HashSet<communication_event_status>();
        //    facility_status = new HashSet<facility_status>();
        //    inventory_item_status = new HashSet<inventory_item_status>();
        //    inventory_movement_status = new HashSet<inventory_movement_status>();
        //    memo_status = new HashSet<memo_status>();
        //    orders_status = new HashSet<orders_status>();
        //    party_role_status = new HashSet<party_role_status>();
        //    payment_status = new HashSet<payment_status>();
        //    positions_status = new HashSet<positions_status>();
        //    prospect_status = new HashSet<prospect_status>();
        //    quote_status = new HashSet<quote_status>();
        //    requirement_status = new HashSet<requirement_status>();
        //    shipment_status = new HashSet<shipment_status>();
        //    shipment_package_status = new HashSet<shipment_package_status>();
        //    shipment_receipt_status = new HashSet<shipment_receipt_status>();
        //    suspect_status = new HashSet<suspect_status>();
        //    user_mediator_status = new HashSet<user_mediator_status>();
        //    work_effort_status = new HashSet<work_effort_status>();
        //    work_order_booking_status = new HashSet<work_order_booking_status>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idreason { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<AgreementStatus> AgreementStatus { get; set; }

        public ICollection<BillingStatus> BillingStatus { get; set; }

        public ICollection<Carrier> Carriers { get; set; }

        public ICollection<CommunicationEventStatus> CommunicationEventStatus { get; set; }

        public ICollection<FacilityStatus> FacilityStatus { get; set; }

        public ICollection<InventoryItemStatus> InventoryItemStatus { get; set; }

        public ICollection<InventoryMovementStatus> InventoryMovementStatus { get; set; }

        public ICollection<MemoStatus> MemoStatus { get; set; }

        public ICollection<OrdersStatus> OrdersStatus { get; set; }

        public ICollection<PartyRoleStatus> PartyRoleStatus { get; set; }

        public ICollection<PaymentStatus> PaymentStatus { get; set; }

        public ICollection<PositionsStatus> PositionsStatus { get; set; }

        public ICollection<ProspectStatus> ProspectStatus { get; set; }

        public ICollection<QuoteStatus> QuoteStatus { get; set; }

        public ICollection<RequirementStatus> RequirementStatus { get; set; }

        public ICollection<ShipmentStatus> ShipmentStatus { get; set; }

        public ICollection<ShipmentPackageStatus> ShipmentPackageStatus { get; set; }

        public ICollection<ShipmentReceiptStatus> ShipmentReceiptStatus { get; set; }

        public ICollection<SuspectStatus> SuspectStatus { get; set; }

        public ICollection<UserMediatorStatus> UserMediatorStatus { get; set; }

        public ICollection<WorkEffortStatus> WorkEffortStatus { get; set; }

        public ICollection<WorkOrderBookingStatus> WorkOrderBookingStatus { get; set; }
    }
}
