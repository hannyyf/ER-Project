namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("relation_type")]
    public partial class RelationType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public relation_type()
        //{
        //    carriers = new HashSet<Carrier>();
        //    party_relationship = new HashSet<PartyRelationship>();
        //}

        [Key]
        public int idreltyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Carrier> Carrier { get; set; }

        public ICollection<PartyRelationship> PartyRelationship { get; set; }
    }
}
