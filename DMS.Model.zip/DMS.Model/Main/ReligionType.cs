namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("religion_type")]
    public partial class ReligionType
    {
        [Key]
        public int idreligiontype { get; set; }

        [StringLength(50)]
        public string description { get; set; }
    }
}
