namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("requirement")]
    public partial class Requirement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Requirement()
        //{
        //    approvals = new HashSet<Approval>();
        //    receipts = new HashSet<receipt>();
        //    requirement_status = new HashSet<requirement_status>();
        //    requirement1 = new HashSet<Requirement>();
        //    requirement_role = new HashSet<requirement_role>();
        //    order_item = new HashSet<OrderItem>();
        //    payment_application = new HashSet<payment_application>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idreq { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("RequirementParrent")]
        [MaxLength(16)]
        public byte[] idparentreq { get; set; }
        public Requirement RequirementParrent { get; set; }

        [ForeignKey("RequirementType")]
        public int? idreqtyp { get; set; }
        public RequirementType RequirementType { get; set; }

        [StringLength(30)]
        public string requirementnumber { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtcreate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtrequired { get; set; }

        public decimal? budget { get; set; }

        public int? qty { get; set; }

        public ICollection<Approval> approvals { get; set; }

        //public virtual purchase_request purchase_request { get; set; }

        public ICollection<Receipt> Receipts { get; set; }

        public ICollection<RequirementStatus> RequirementStatus { get; set; }

        public ICollection<Requirement> Requirement1 { get; set; }

        public ICollection<RequirementRole> RequirementRole { get; set; }

        //public virtual sales_unit_requirement sales_unit_requirement { get; set; }

        //public virtual unit_requirement unit_requirement { get; set; }

        //public virtual vehicle_document_requirement vehicle_document_requirement { get; set; }

        //public virtual work_product_req work_product_req { get; set; }

        //public virtual work_requirement work_requirement { get; set; }

        public ICollection<OrderItem> OrderItem { get; set; }

        public ICollection<PaymentApplication> PaymentApplication { get; set; }
    }

    public class RequirementDTO
    {
        [MaxLength(16)]
        public byte[] idreq { get; set; }
        [StringLength(30)]
        public string requirementnumber { get; set; }
        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtcreate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtrequired { get; set; }

        public decimal? budget { get; set; }

        public int? qty { get; set; }
        public int? idreqtyp { get; set; }
        public int? qtyfilled { get; set; }
        public int? currentstatus { get; set; }
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public string facilitydescription { get; set; }
        [MaxLength(16)]
        public byte[] idparentreq { get; set; }
        public string parentreqdescription { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            RequirementDTO requirementDTO = (RequirementDTO)obj;
            if (requirementDTO.idreq == null || idreq == null)
            {
                return false;
            }
            return Object.Equals(idreq, requirementDTO.idreq);
        }

        public override int GetHashCode()
        {
            return idreq.GetHashCode();
        }

        public override string ToString()
        {
            return "RequirementDTO{" +
            "id=" + idreq +
            ", requirementNumber='" + requirementnumber + "'" +
            ", description='" + description + "'" +
            ", dateCreate='" + dtcreate + "'" +
            ", dateRequired='" + dtrequired + "'" +
            ", budget='" + budget + "'" +
            ", qty='" + qty + "'" +
            "}";
        }

    }
}
