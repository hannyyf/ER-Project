namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("requirement_type")]
    public partial class RequirementType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public requirement_type()
        //{
        //    requirements = new HashSet<Requirement>();
        //}

        [Key]
        public int idreqtyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Requirement> Requirement { get; set; }
    }
}
