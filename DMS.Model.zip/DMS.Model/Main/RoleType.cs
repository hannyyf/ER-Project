namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("role_type")]
    public partial class RoleType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public role_type()
        //{
        //    agreement_role = new HashSet<AgreementRole>();
        //    billing_role = new HashSet<BillingRole>();
        //    communication_event_role = new HashSet<CommunicationEventRole>();
        //    customers = new HashSet<Customer>();
        //    internals = new HashSet<_internal>();
        //    orders_role = new HashSet<OrdersRole>();
        //    party_role = new HashSet<PartyRole>();
        //    party_role_type = new HashSet<PartyRoleType>();
        //    payment_role = new HashSet<PaymentRole>();
        //    prospect_role = new HashSet<ProspectRole>();
        //    quote_role = new HashSet<QuoteRole>();
        //    requirement_role = new HashSet<RequirementRole>();
        //    shipment_receipt_role = new HashSet<shipment_receipt_role>();
        //    shipment_package_role = new HashSet<shipment_package_role>();
        //    suspect_role = new HashSet<suspect_role>();
        //    user_mediator_role = new HashSet<user_mediator_role>();
        //    vendors = new HashSet<Vendor>();
        //    work_effort_role = new HashSet<work_effort_role>();
        //    work_order_booking_role = new HashSet<work_order_booking_role>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idroletype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<AgreementRole> AgreementRole { get; set; }

        public ICollection<BillingRole> BillingRole { get; set; }

        public ICollection<CommunicationEventRole> CommunicationEventRole { get; set; }

        public ICollection<Customer> Customer { get; set; }

        public ICollection<_internal> Internals { get; set; }

        public ICollection<OrdersRole> OrdersRole { get; set; }

       public ICollection<PartyRole> PartyRole { get; set; }

        public ICollection<PartyRoleType> PartyRoleType { get; set; }

        public ICollection<PaymentRole> PaymentRole { get; set; }

       public ICollection<ProspectRole> ProspectRole { get; set; }

        public ICollection<QuoteRole> QuoteRole { get; set; }

        public ICollection<RequirementRole> RequirementRole { get; set; }

        public ICollection<ShipmentReceiptRole> ShipmentReceiptRole { get; set; }

        public ICollection<ShipmentPackageRole> ShipmentPackageRole { get; set; }

        public ICollection<SuspectRole> SuspectRole { get; set; }

        public ICollection<UserMediatorRole> UserMediatorRole { get; set; }

        public ICollection<Vendor> Vendor { get; set; }

        public ICollection<WorkEffortRole> WorkEffortRole { get; set; }

        public ICollection<WorkOrderBookingRole> WorkOrderBookingRole { get; set; }
    }
}
