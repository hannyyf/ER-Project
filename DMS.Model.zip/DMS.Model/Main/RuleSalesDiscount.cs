namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("rule_sales_discount")]
    public partial class RuleSalesDiscount :Rule
    {
        [ForeignKey("JhiAuthority")]
        [StringLength(30)]
        public string name { get; set; }
        public JhiAuthority JhiAuthority { get; set; }

        public decimal? maxamount { get; set; }

    }
}
