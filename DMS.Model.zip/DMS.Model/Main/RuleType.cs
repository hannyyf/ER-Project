namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("rule_type")]
    public partial class RuleType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public RuleType()
        //{
        //    category_type = new HashSet<category_type>();
        //    feature_type = new HashSet<feature_type>();
        //    price_type = new HashSet<price_type>();
        //    rules = new HashSet<rule>();
        //}

        [Key]
        public int idrultyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<CategoryType> CategoryType { get; set; }
        public ICollection <FeatureType> FeatureType { get; set; }
        public ICollection<PriceType> PriceType { get; set; }
        public ICollection<Rule> Rule { get; set; }

    }
}
