namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sale_type")]
    public partial class SaleType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public sale_type()
        //{
        //    communication_event_prospect = new HashSet<communication_event_prospect>();
        //    sale_type1 = new HashSet<sale_type>();
        //    sales_order = new HashSet<sales_order>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    vehicle_sales_order = new HashSet<vehicle_sales_order>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    vehicle_sales_billing = new HashSet<vehicle_sales_billing>();
        //}

        [Key]
        public int idsaletype { get; set; }

        [ForeignKey("SaleTypeParrent")]
        public int? idparent { get; set; } 
        public SaleType SaleTypeParrent { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<CommunicationEventProspect> ComunicationEventProspect { get; set; }
        public ICollection<SaleType> SaleType1 { get; set; }
        public ICollection<SalesOrder> SalesOrder { get; set; }
        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }
        public ICollection<VehicleSalesOrder> VehicleSalesOrder { get; set; }
        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }
        public ICollection<VehicleSalesBilling>VehicleSalesBilling { get; set; }


    }
}
