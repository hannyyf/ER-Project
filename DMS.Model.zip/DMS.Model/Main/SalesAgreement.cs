namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sales_agreement")]
    public partial class SalesAgreement :Agreement
    {

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("OrganisationCustomer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public OrganizationCustomer OrganisationCustomer { get; set; }
    }
}
