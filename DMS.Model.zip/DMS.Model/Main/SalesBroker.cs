namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sales_broker")]
    public partial class SalesBroker :PartyRole
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public sales_broker()
        //{
        //    prospects = new HashSet<Prospect>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //}

        [ForeignKey("BrokerType")]
        public int? idbrotyp { get; set; }
        public BrokerType BrokerType { get; set; }

        [StringLength(30)]
        public string idbroker { get; set; }

        public ICollection<Prospect> Prospect { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }
    }
}
