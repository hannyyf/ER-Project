namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sales_unit_leasing")]
    public partial class SalesUnitLeasing
    {
        [Key]
        [MaxLength(16)]
        public byte[] idsallea { get; set; }

        [ForeignKey("SalesUnitRequirement")]
        [MaxLength(16)]
        public byte[] idreq { get; set; }
        public SalesUnitRequirement SalesUnitRequirement { get; set; }

        [ForeignKey("LeasingCompany")]
        [MaxLength(16)]
        public byte[] idleacom { get; set; }
        public LeasingCompany LeasingCompany { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [ForeignKey("VehicleSalesOrder")]
        [MaxLength(16)]
        public byte[] idorder { get; set; }
        public VehicleSalesOrder VehicleSalesOrder { get; set; }

        [ForeignKey("LeasingTenorProvide")]
        [MaxLength(16)]
        public byte[] idlsgpro { get; set; }
        public LeasingTenorProvide LeasingTenorProvide { get; set; }

        [StringLength(30)]
        public string ponumber { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtpo { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        
    }
}
