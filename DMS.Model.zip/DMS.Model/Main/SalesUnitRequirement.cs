namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sales_unit_requirement")]
    public partial class SalesUnitRequirement :Requirement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public sales_unit_requirement()
        //{
        //    sales_unit_leasing = new HashSet<SalesUnitLeasing>();
        //    vehicle_sales_order = new HashSet<vehicle_sales_order>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //}
        [ForeignKey("Prospect")]
        [MaxLength(16)]
        public byte[] idprospect { get; set; }
        public Prospect Prospect { get; set; }

        [ForeignKey("SaleType")]
        public int? idsaletype { get; set; }
        public SaleType SaleType { get; set; }
        
        [ForeignKey("Salesman")]
        [MaxLength(16)]
        public byte[] idsalesman { get; set; }
        public Salesman Salesman { get; set; }
        
        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Motor Motor { get; set; }

        [ForeignKey("Feature")]
        public int? idcolor { get; set; }
        public Feature Feature { get; set; }

        [ForeignKey("SalesBroker")]
        [MaxLength(16)]
        public byte[] idsalesbroker { get; set; }
        public SalesBroker SalesBroker { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idowner { get; set; }
        public Party Party { get; set; }

        [ForeignKey("LeasingTenorProvide")]
        [MaxLength(16)]
        public byte[] idlsgpro { get; set; }
        public LeasingTenorProvide LeasingTenorProvide { get; set; }

        public decimal? downpayment { get; set; }

        [StringLength(90)]
        public string idframe { get; set; }

        [StringLength(90)]
        public string idmachine { get; set; }

        public decimal? subsfincomp { get; set; }

        public decimal? subsmd { get; set; }

        public decimal? subsown { get; set; }

        public decimal? subsahm { get; set; }

        public decimal? bbnprice { get; set; }

        public decimal? hetprice { get; set; }

        [StringLength(900)]
        public string note { get; set; }

        public decimal? unitprice { get; set; }

        [StringLength(900)]
        public string notepartner { get; set; }

        [StringLength(900)]
        public string shipmentnote { get; set; }

        [StringLength(90)]
        public string requestpoliceid { get; set; }

        [StringLength(90)]
        public string leasingpo { get; set; }

        public DateTime? dtpoleasing { get; set; }

        public decimal? brokerfee { get; set; }

        public int? idprosou { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
        public BillTo BillTo { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }

        public ICollection<SalesUnitLeasing> SalesUnitLeasing { get; set; }

        public ICollection<VehicleSalesOrder> VehicleSalesOrder { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }


        //public virtual Requirement requirement { get; set; }

    }
}
