namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("service_agreement")]
    public partial class ServiceAgreement :Agreement
    {
        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("OrganizationCustomer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public OrganizationCustomer OrganizationCustomer { get; set; }
    }
}
