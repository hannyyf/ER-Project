namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("service_history")]
    public partial class ServiceHistory
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public service_history()
        //{
        //    part_history = new HashSet<PartHistory>();
        //}

        [Key]
        public int IdServiceHistory { get; set; }

        [ForeignKey("VehicleServiceHistory")]
        public int? IdVehicleServiceHistory { get; set; }
        public VehicleServiceHistory VehicleServiceHistory { get; set; }

        [StringLength(10)]
        public string CodeService { get; set; }

        [StringLength(30)]
        public string DescService { get; set; }

        public ICollection<PartHistory> PartHistory { get; set; }

        
    }
}
