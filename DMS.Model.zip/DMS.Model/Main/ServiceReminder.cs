namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("service_reminder")]
    public partial class ServiceReminder
    {
        [Key]
        public int idreminder { get; set; }

        [ForeignKey("DealerClaimType")]
        public int? idclaimtype { get; set; }
        public DealerClaimType DealerClaimType { get; set; }

        [ForeignKey("DealerReminderType")]
        public int? idremindertype { get; set; }
        public DealerReminderType DealerReminderType { get; set; }

        public int? days { get; set; }
        
    }
}
