namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ship_to")]
    public partial class ShipTo
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public ship_to()
        //{
        //    order_item = new HashSet<OrderItem>();
        //    package_receipt = new HashSet<PackageReceipt>();
        //    picking_slip = new HashSet<PickingSlip>();
        //    shipments = new HashSet<shipment>();
        //    shipments1 = new HashSet<shipment>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //}

        [Key]
        [StringLength(30)]
        public string idshipto { get; set; }

        [ForeignKey("PartyRoleType"),Column(Order =0)]
        [MaxLength(16)]
        public byte[] idparty { get; set; }

        [ForeignKey("PartyRoleType"), Column(Order = 1)]
        public int? idroletype { get; set; }
        public PartyRoleType PartyRoleType { get; set; }

        //public virtual CustomerShipTo customer_ship_to { get; set; }

        //public virtual InternalShipTo internal_ship_to { get; set; }
        //public virtual VendorShipTo vendor_ship_to { get; set; }

        public ICollection<OrderItem> OrderItem { get; set; }

        public ICollection<PackageReceipt> PackageReceipt { get; set; }

        public ICollection<PickingSlip> PickingSlip { get; set; }

        public ICollection<Shipment> Shipment { get; set; }

        public ICollection<Shipment> Shipments1 { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }

        
    }
}
