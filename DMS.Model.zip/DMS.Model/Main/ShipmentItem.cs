namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_item")]
    public partial class ShipmentItem
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public shipment_item()
        //{
        //    item_issuance = new HashSet<ItemIssuance>();
        //    packaging_content = new HashSet<PackagingContent>();
        //    order_item = new HashSet<OrderItem>();
        //    shipment_receipt = new HashSet<shipment_receipt>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idshiite { get; set; }

        [ForeignKey("Shipment")]
        [MaxLength(16)]
        public byte[] idshipment { get; set; }
        public Shipment Shipment { get; set; }

        [ForeignKey("Feature")]
        public int? idfeature { get; set; }
        public Feature Feature { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        public decimal? qty { get; set; }

        [StringLength(50)]
        public string contentdescription { get; set; }

        [StringLength(50)]
        public string idframe { get; set; }

        [StringLength(50)]
        public string idmachine { get; set; }

        public ICollection<ItemIssuance> ItemIssuance { get; set; }

        public ICollection<PackagingContent> PackagingContent { get; set; }

        public ICollection<OrderItem> OrderItem { get; set; }

        public ICollection<ShipmentReceipt> ShipmentReceipt { get; set; }
    }
}
