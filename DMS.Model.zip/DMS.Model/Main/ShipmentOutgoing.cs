namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_outgoing")]
    public partial class ShipmentOutgoing :Shipment
    {
        [ForeignKey("Driver")]
        [MaxLength(16)]
        public byte[] iddriver { get; set; }
        public Driver Driver { get; set; }

        [StringLength(6)]
        public string dtbast { get; set; }

        [StringLength(1800)]
        public string note { get; set; }

        [StringLength(30)]
        public string othername { get; set; }

    }
}
