namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_package")]
    public partial class ShipmentPackage
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public shipment_package()
        //{
        //    packaging_content = new HashSet<PackagingContent>();
        //    shipment_package_status = new HashSet<shipment_package_status>();
        //    shipment_receipt = new HashSet<shipment_receipt>();
        //    shipment_package_role = new HashSet<shipment_package_role>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idpackage { get; set; }

        [ForeignKey("ShipmentPackageType")]
        public int? idshipactyp { get; set; }
        public ShipmentPackageType ShipmentPackageType { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        public DateTime? dtcreated { get; set; }

        //public virtual PackageReceipt package_receipt { get; set; }

        public ICollection<PackagingContent> PackagingContent { get; set; }

        public ICollection<ShipmentPackageStatus> ShipmentPackageStatus { get; set; }

        public ICollection<ShipmentReceipt> ShipmentReceipt { get; set; }

        public ICollection<ShipmentPackageRole> ShipmentPackageRole { get; set; }
    }
}
