namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_package_type")]
    public partial class ShipmentPackageType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public shipment_package_type()
        //{
        //    shipment_package = new HashSet<ShipmentPackage>();
        //}

        [Key]
        public int idshipactyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<ShipmentPackage> ShipmentPackage { get; set; }
    }
}
