namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_receipt")]
    public partial class ShipmentReceipt
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public shipment_receipt()
        //{
        //    inventory_item = new HashSet<InventoryItem>();
        //    shipment_receipt_role = new HashSet<shipment_receipt_role>();
        //    shipment_receipt_status = new HashSet<shipment_receipt_status>();
        //    shipment_item = new HashSet<ShipmentItem>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idreceipt { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        [ForeignKey("ShipmentPackage")]
        [MaxLength(16)]
        public byte[] idpackage { get; set; }
        public ShipmentPackage ShipmentPackage { get; set; }

        [ForeignKey("Feature")]
        public int? idfeature { get; set; }
        public Feature Feature { get; set; }

        [ForeignKey("OrderItem")]
        [MaxLength(16)]
        public byte[] idordite { get; set; }
        public OrderItem OrderItem { get; set; }

        [StringLength(30)]
        public string code { get; set; }

        public decimal? qtyaccept { get; set; }

        public decimal? qtyreject { get; set; }

        [StringLength(50)]
        public string itemdescription { get; set; }

        public DateTime? dtreceipt { get; set; }

        [StringLength(50)]
        public string idframe { get; set; }

        [StringLength(50)]
        public string idmachine { get; set; }

        [StringLength(5)]
        public string acc1 { get; set; }

        [StringLength(5)]
        public string acc2 { get; set; }

        [StringLength(5)]
        public string acc3 { get; set; }

        [StringLength(5)]
        public string acc4 { get; set; }

        [StringLength(5)]
        public string acc5 { get; set; }

        [StringLength(5)]
        public string acc6 { get; set; }

        [StringLength(5)]
        public string acc7 { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }

        public ICollection<ShipmentReceiptRole> ShipmentReceiptRole { get; set; }

        public ICollection<ShipmentReceiptStatus> ShipmentReceiptStatus { get; set; }

        public ICollection<ShipmentItem> ShipmentItem { get; set; }
    }
}
