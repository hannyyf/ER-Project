namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment_receipt_role")]
    public partial class ShipmentReceiptRole
    {
        [Key]
        [MaxLength(16)]
        public byte[] idrole { get; set; }

        [MaxLength(16)]
        public byte[] idreceipt { get; set; }
        public ShipmentReceipt ShipmentReceipt { get; set; }

        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
 
    }
}
