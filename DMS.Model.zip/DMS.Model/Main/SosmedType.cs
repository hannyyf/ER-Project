namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("SosmedType")]
    public partial class SosmedType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public SosmedType()
        //{
        //    PersonSosmeds = new HashSet<PersonSosmed>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdSosmedType { get; set; }

        [StringLength(30)]
        public string Description { get; set; }

        public ICollection<PersonSosmed> PersonSosmeds { get; set; }
    }
}
