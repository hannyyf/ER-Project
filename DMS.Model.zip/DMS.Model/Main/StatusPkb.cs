namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("status_pkb")]
    public partial class StatusPkb
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public status_pkb()
        //{
        //    pkbs = new HashSet<Pkb>();
        //    pkbs1 = new HashSet<Pkb>();
        //}

        [Key]
        public int IdStatusPkb { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }

        [StringLength(10)]
        public string DescStatusPkb { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public ICollection<Pkb> Pkbs { get; set; }

        public ICollection<Pkb> Pkbs1 { get; set; }

        
    }
}
