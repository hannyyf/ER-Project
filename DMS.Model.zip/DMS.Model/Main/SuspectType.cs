namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("suspect_type")]
    public partial class SuspectType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public suspect_type()
        //{
        //    suspects = new HashSet<Suspect>();
        //}

        [Key]
        public int idsuspecttyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Suspect> Suspect { get; set; }
    }
}
