namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("sympthom_data_m")]
    public partial class SympthomDataM
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public sympthom_data_m()
        //{
        //    claim_detail = new HashSet<ClaimDetail>();
        //}

        [Key]
        public int IdSympthomDataM { get; set; }

        [StringLength(150)]
        public string DescSymptom { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public ICollection<ClaimDetail> ClaimDetail { get; set; }
    }
}
