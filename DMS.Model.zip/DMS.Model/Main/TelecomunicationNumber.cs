namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TelecomunicationNumber")]
    public partial class TelecomunicationNumber :ContactMechanism
    {
        //[ForeignKey("ContactMechanism")]
        //[MaxLength(16)]
        //public byte[] idcontact { get; set; }
        //public ContactMechanism ContactMechanism { get; set; }

        [StringLength(30)]
        public string number { get; set; }

        
    }
}
