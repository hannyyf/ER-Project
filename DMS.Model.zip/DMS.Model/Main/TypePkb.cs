namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("type_pkb")]
    public partial class TypePkb
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public type_pkb()
        //{
        //    pkbs = new HashSet<Pkb>();
        //}

        [Key]
        public int IdTypePkb { get; set; }

        [StringLength(10)]
        public string DescType { get; set; }

        public ICollection<Pkb> Pkb { get; set; }
    }
}
