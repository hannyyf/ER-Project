namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("unit_accesories_mapper")]
    public partial class UnitAccesoriesMapper
    {
        [Key]
        [MaxLength(16)]
        public byte[] iduntaccmap { get; set; }

        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idmotor { get; set; }
        public Motor Motor { get; set; }

        [StringLength(30)]
        public string acc1 { get; set; }

        public decimal? qtyacc1 { get; set; }

        [StringLength(30)]
        public string acc2 { get; set; }

        public decimal? qtyacc2 { get; set; }

        [StringLength(30)]
        public string acc3 { get; set; }

        public decimal? qtyacc3 { get; set; }

        [StringLength(30)]
        public string acc4 { get; set; }

        public decimal? qtyacc4 { get; set; }

        [StringLength(30)]
        public string acc5 { get; set; }

        public decimal? qtyacc5 { get; set; }

        [StringLength(30)]
        public string acc6 { get; set; }

        public decimal? qtyacc6 { get; set; }

        [StringLength(30)]
        public string acc7 { get; set; }

        public decimal? qtyacc7 { get; set; }

        [StringLength(30)]
        public string promat1 { get; set; }

        public decimal? qtypromat1 { get; set; }

        [StringLength(30)]
        public string promat2 { get; set; }

        public decimal? qtypromat2 { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        
    }
}
