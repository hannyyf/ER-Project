namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("unit_deliverable")]
    public partial class UnitDeliverable
    {
        [Key]
        [MaxLength(16)]
        public byte[] iddeliverable { get; set; }

        [ForeignKey("VehicleDocumentRequirement")]
        [MaxLength(16)]
        public byte[] idreq { get; set; }
        public VehicleDocumentRequirement VehicleDocumentRequirement { get; set; }


        [ForeignKey("DeliverableType")]
        public int? iddeltype { get; set; }
        public DeliverableType DeliverableType { get; set; }

        [ForeignKey("StatusType")]
        public int? idvndstatyp { get; set; }
        public StatusType StatusType { get; set; }

        [ForeignKey("StatusType1")]
        public int? idconstatyp { get; set; }
        public StatusType StatusType1 { get; set; }

        [StringLength(150)]
        public string description { get; set; }

        [StringLength(6)]
        public string dtreceipt { get; set; }

        [StringLength(6)]
        public string dtdelivery { get; set; }

        [StringLength(90)]
        public string bastnumber { get; set; }

        [StringLength(90)]
        public string name { get; set; }

        [StringLength(90)]
        public string identitynumber { get; set; }

        [StringLength(90)]
        public string cellphone { get; set; }

        [StringLength(50)]
        public string refnumber { get; set; }

        public DateTime? refdt { get; set; }

        public int? receiptqty { get; set; }

        public decimal? receiptnominal { get; set; }

        
    }
}
