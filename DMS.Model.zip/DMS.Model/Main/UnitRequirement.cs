namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("unit_requirement")]
    public partial class UnitRequirement :Requirement
    {
        [ForeignKey("Motor")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Motor Motor { get; set; }

        [ForeignKey("Branch")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public Branch Branch { get; set; }

        //public virtual Requirement requirement { get; set; }
    }
}
