namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("uom_conversion")]
    public partial class UomConversion
    {
        [Key]
        public int iduomconversion { get; set; }

        [ForeignKey("UomTo")]
        [StringLength(30)]
        public string iduomto { get; set; }
        public Uom UomTo { get; set; }

        [ForeignKey("UomFro")]
        [StringLength(30)]
        public string iduomfro { get; set; }
        public Uom UomFro { get; set; }

        public decimal? factor { get; set; }
       
    }
}
