namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("uom_type")]
    public partial class UomType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public uom_type()
        //{
        //    uoms = new HashSet<Uom>();
        //}

        [Key]
        public int iduomtyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Uom> Uom { get; set; }
    }
}
