namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("user_extra")]
    public partial class UserExtra
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public long iduser { get; set; }

        [StringLength(30)]
        public string idinternal { get; set; }
    }
}
