namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("user_mediator")]
    public partial class UserMediator
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public user_mediator()
        //{
        //    positions = new HashSet<Position>();
        //    user_mediator_status = new HashSet<user_mediator_status>();
        //    user_mediator_role = new HashSet<user_mediator_role>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idusrmed { get; set; }

        [ForeignKey("JhiUser")]
        public long? id { get; set; }
        public JhiUser JhiUser { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idperson { get; set; }
        public Person Person { get; set; }

        [StringLength(50)]
        public string email { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        [StringLength(30)]
        public string firstname { get; set; }

        [StringLength(30)]
        public string lastname { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        public ICollection<Position> Position { get; set; }

        public ICollection<UserMediatorStatus> UserMediatorStatus { get; set; }

        public ICollection<UserMediatorRole> UserMediatorRole { get; set; }
    }
}
