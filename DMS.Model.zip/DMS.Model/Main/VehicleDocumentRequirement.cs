namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_document_requirement")]
    public partial class VehicleDocumentRequirement :Requirement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vehicle_document_requirement()
        //{
        //    unit_deliverable = new HashSet<UnitDeliverable>();
        //}

        [ForeignKey("SalesUnitRequirement")]
        [MaxLength(16)]
        public byte[] idslsreq { get; set; }
        public SalesUnitRequirement SalesUnitRequirement { get; set; }

        [ForeignKey("OrderItems")]
        [MaxLength(16)]
        public byte[] idordite { get; set; }
        public OrderItem OrderItems { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idpersonowner { get; set; }
        public Person Person { get; set; }

        [ForeignKey("VehicleRegistrationType")]
        public int? idvehregtyp { get; set; }
        public VehicleRegistrationType VehicleRegistrationType { get; set; }

        [ForeignKey("SaleType")]
        public int? idsaletype { get; set; }
        public SaleType SaleType { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [StringLength(900)]
        public string note { get; set; }

        [StringLength(90)]
        public string atpmfaktur { get; set; }

        public decimal? bbn { get; set; }

        public decimal? othercost { get; set; }

        [StringLength(90)]
        public string policenumber { get; set; }

        public DateTime? atpmfakturdt { get; set; }

        [StringLength(50)]
        public string submissionno { get; set; }

        public DateTime? submissiondt { get; set; }

        public int? crossarea { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
        public BillTo BillTo { get; set; }

        [ForeignKey("ShipTo")]
        [StringLength(30)]
        public string idshipto { get; set; }
        public ShipTo ShipTo { get; set; }

        //public virtual Requirement requirement { get; set; }
        
        public ICollection<UnitDeliverable> UnitDeliverable { get; set; }
        
    }
}
