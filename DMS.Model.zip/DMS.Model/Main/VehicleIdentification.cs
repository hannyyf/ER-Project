namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_identification")]
    public partial class VehicleIdentification
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vehicle_identification()
        //{
        //    vehicle_work_requirement = new HashSet<vehicle_work_requirement>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idvehide { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [StringLength(10)]
        public string vehiclenumber { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }

        public ICollection<VehicleWorkRequirement> VehicleWorkRequirement { get; set; }
    }
}
