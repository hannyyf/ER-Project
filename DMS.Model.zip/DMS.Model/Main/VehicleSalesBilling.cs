namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_sales_billing")]
    public partial class VehicleSalesBilling :BillingReceipt
    {
        [ForeignKey("SaleType")]
        public int? idsaletype { get; set; }
        public SaleType SaleType { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }
    }
}
