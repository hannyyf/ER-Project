namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_sales_order")]
    public partial class VehicleSalesOrder :SalesOrder
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vehicle_sales_order()
        //{
        //    sales_unit_leasing = new HashSet<sales_unit_leasing>();
        //}
        [ForeignKey("SalesUnitRequirement")]
        [MaxLength(16)]
        public byte[] idunitreq { get; set; }
        public SalesUnitRequirement SalesUnitRequirement { get; set; }

        [ForeignKey("LeasingCompany")]
        [MaxLength(16)]
        public byte[] idleacom { get; set; }
        public LeasingCompany LeasingCompany { get; set; }

        [StringLength(5)]
        public string shiptoowner { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtbastunit { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtcustreceipt { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtmachineswipe { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dttakepicture { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtcovernote { get; set; }

        public int? idlsgpaystatus { get; set; }

        public DateTime? dtadmslsverify { get; set; }

        public DateTime? dtafcverify { get; set; }

        public int? admslsverifyval { get; set; }

        public int? afcverifyval { get; set; }

        [StringLength(150)]
        public string admslsnotapprovnote { get; set; }

        [StringLength(150)]
        public string afcnotapprovnote { get; set; }

        [StringLength(150)]
        public string vrnama1 { get; set; }

        [StringLength(150)]
        public string vrnama2 { get; set; }

        [StringLength(150)]
        public string vrnamamarket { get; set; }

        [StringLength(150)]
        public string vrwarna { get; set; }

        [StringLength(150)]
        public string vrtahunproduksi { get; set; }

        public decimal? vrangsuran { get; set; }

        public int? vrtenor { get; set; }

        [StringLength(150)]
        public string vrleasing { get; set; }

        [StringLength(6)]
        public string vrtglpengiriman { get; set; }

        [StringLength(150)]
        public string vrjampengiriman { get; set; }

        [StringLength(150)]
        public string vrtipepenjualan { get; set; }

        public decimal? vrdpmurni { get; set; }

        public decimal? vrtandajadi { get; set; }

        [StringLength(6)]
        public string vrtglpembayaran { get; set; }

        public decimal? vrsisa { get; set; }

        public int? vriscod { get; set; }

        [StringLength(150)]
        public string vrcatatantambahan { get; set; }

        public int? vrisverified { get; set; }

        [StringLength(150)]
        public string vrcatatan { get; set; }

        public ICollection<SalesUnitLeasing> SalesUnitLeasing { get; set; }
 
    }
}
