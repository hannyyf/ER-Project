namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_service_history")]
    public partial class VehicleServiceHistory
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vehicle_service_history()
        //{
        //    service_history = new HashSet<ServiceHistory>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdVehicleServiceHistory { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [StringLength(100)]
        public string Location { get; set; }

        public decimal? Km { get; set; }

        [StringLength(100)]
        public string JobSuggest { get; set; }

        public DateTime? ServiceDate { get; set; }

        [StringLength(30)]
        public string MechanicName { get; set; }

        [Column(TypeName = "date")]
        public DateTime? NextServiceDate { get; set; }

        public ICollection<ServiceHistory> ServiceHistory { get; set; }

        
    }
}
