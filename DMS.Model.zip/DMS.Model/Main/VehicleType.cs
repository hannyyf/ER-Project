namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_type")]
    public partial class VehicleType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vehicle_type()
        //{
        //    vehicles = new HashSet<Vehicle>();
        //}

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdVehicleType { get; set; }

        [StringLength(50)]
        public string Description { get; set; }

        public ICollection<Vehicle> Vehicle { get; set; }
    }
}
