namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle_work_requirement")]
    public partial class VehicleWorkRequirement : WorkRequirement
    {

        [ForeignKey("Mechanic")]
        [MaxLength(16)]
        public byte[] idmechanic { get; set; }
        public Mechanic Mechanic { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [ForeignKey("VehicleIdentification")]
        [MaxLength(16)]
        public byte[] idvehide { get; set; }
        public VehicleIdentification VehicleIdentification { get; set; }

        [StringLength(10)]
        public string vehiclenumber { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }


        //public virtual WorkRequirement work_requirement { get; set; }

        //public virtual WorkOrder work_order { get; set; }
    }

    public class VehicleWorkRequirementDTO : WorkRequirementDTO
    {
        [StringLength(10)]
        public string vehiclenumber { get; set; }
        [StringLength(30)]
        public string idcustomer { get; set; }
        public string customername { get; set; }
        [MaxLength(16)]
        public byte[] idmechanic { get; set; }
        public string mechanicname { get; set; }
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public string idmotor { get; set; }
        public string idcolor { get; set; }
        public string colordescription { get; set; }

        public override string ToString()
        {
            return "VehicleWorkRequirementDTO{" +
            "id=" + idreq +
            ", vehicleNumber='" + vehiclenumber + "'" +
            "}";
        }


    }
}
