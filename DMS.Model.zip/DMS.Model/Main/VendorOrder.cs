namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vendor_order")]
    public partial class VendorOrder :Order
    {
        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
        public BillTo BillTo { get; set; }

       // public virtual PurchaseOrder purchase_order { get; set; }

       // public virtual ReturnPurchaseOrder return_purchase_order { get; set; }

        
    }
}
