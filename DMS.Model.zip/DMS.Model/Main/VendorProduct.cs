namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vendor_product")]
    public partial class VendorProduct
    {
        [Key]
        [MaxLength(16)]
        public byte[] idvenpro { get; set; }

        [ForeignKey("Product")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Product Product { get; set; }

        public int? orderratio { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        

        
    }
}
