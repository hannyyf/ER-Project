namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vendor_type")]
    public partial class VendorType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public vendor_type()
        //{
        //    vendors = new HashSet<Vendor>();
        //}

        [Key]
        public int idvndtyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Vendor> Vendor { get; set; }
    }
}
