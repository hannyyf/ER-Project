namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("we_service_type")]
    public partial class WeServiceType: WeType
    {
        [ForeignKey("Service")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Service Service { get; set; }

        public int? frt { get; set; }
    }
}
