namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("we_type")]
    public partial class WeType
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public we_type()
        //{
        //    billing_item = new HashSet<BillingItem>();
        //    we_type_good_standard = new HashSet<we_type_good_standard>();
        //    work_effort = new HashSet<work_effort>();
        //}

        [Key]
        public int idwetyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }
        public ICollection<BillingItem> BillingItem { get; set; }

        //public virtual WeServiceType we_service_type { get; set; }

        public ICollection<WeTypeGoodStandard> WeTypeGoodStandard { get; set; }

        public ICollection<WorkEffort> WorkEffort { get; set; }
    }

    public class WeTypeDTO
    {
        public int idwetyp { get; set; }

        [StringLength(50)]
        public string description { get; set; }
    }
}
