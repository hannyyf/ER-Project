namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("we_type_good_standard")]
    public partial class WeTypeGoodStandard
    {
        [Key]
        [MaxLength(16)]
        public byte[] idwegoostd { get; set; }

        public int? idwetyp { get; set; }
        public WeType WeType { get; set; }

        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        public decimal? qty { get; set; }
    }
}
