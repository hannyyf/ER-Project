namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_effort")]
    public partial class WorkEffort
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public work_effort()
        //{
        //    work_effort_status = new HashSet<work_effort_status>();
        //    work_effort_role = new HashSet<work_effort_role>();
        //    payment_application = new HashSet<PaymentApplication>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idwe { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("WeType")]
        public int? idwetyp { get; set; }
        public WeType WeType { get; set; }

        [StringLength(30)]
        public string name { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<WorkEffortStatus> WorkEffortStatus { get; set; }

        public ICollection<WorkEffortRole> WorkEffortRole { get; set; }

        //public virtual work_service_requirement work_service_requirement { get; set; }

        public ICollection<PaymentApplication> PaymentApplication { get; set; }
    }

    public class WorkEffortDTO
    {
        [MaxLength(16)]
        public byte[] idwe { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public int currentstatus { get; set; }
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public string facilitydescription { get; set; }
        public int? idwetyp { get; set; }
        public string wetypdescription { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            WorkEffortDTO workEffortDTO = (WorkEffortDTO)obj;
            if (workEffortDTO.idwe == null || idwe == null)
            {
                return false;
            }
            return Object.Equals(idwe, workEffortDTO.idwe);
        }

        public override int GetHashCode()
        {
            return idwe.GetHashCode();
        }

        public override string ToString()
        {
            return "WorkEffortDTO{" +
            "id=" + idwe +
            ", name='" + name + "'" +
            ", description='" + description + "'" +
            "}";
        }

    }
}
