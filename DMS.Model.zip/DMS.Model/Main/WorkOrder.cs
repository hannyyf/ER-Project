namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_order")]
    public partial class WorkOrder :VehicleWorkRequirement
    {

    }

    public class WorkOrderDTO : VehicleWorkRequirementDTO
    {
        public override string ToString()
        {
            return "WorkOrderDTO{" +
            "id=" + idreq +
            ", vehicleNumber='" + vehiclenumber + "'" +
            "}";
        }
    }
}
