namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_order_booking")]
    public partial class WorkOrderBooking
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public work_order_booking()
        //{
        //    work_order_booking_status = new HashSet<work_order_booking_status>();
        //    work_order_booking_role = new HashSet<work_order_booking_role>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idbooking { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [ForeignKey("BookingSlot")]
        [MaxLength(16)]
        public byte[] idbooslo { get; set; }
        public BookingSlot BookingSlot { get; set; }

        [ForeignKey("BookingType")]
        public int? idboktyp { get; set; }
        public BookingType BookingType { get; set; }

        [ForeignKey("EventType")]
        public int? idevetyp { get; set; }
        public EventType EventType { get; set; }

        [StringLength(30)]
        public string bookingnumber { get; set; }

        [StringLength(10)]
        public string vehiclenumber { get; set; }

        public DateTime? dtcreate { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("PersonalCustomer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public PersonalCustomer PersonalCustomer { get; set; }

        public ICollection<WorkOrderBookingStatus> WorkOrderBookingStatus { get; set; }

        public ICollection<WorkOrderBookingRole> WorkOrderBookingRole { get; set; }
    }

    public class WorkOrderBookingDTO
    {
        [MaxLength(16)]
        public byte[] idbooking { get; set; }
        [StringLength(30)]
        public string bookingnumber { get; set; }
        [StringLength(10)]
        public string vehiclenumber { get; set; }
        public DateTime? dtcreate { get; set; }
        public int? currentstatus { get; set; }
        [MaxLength(16)]
        public byte[] idbooslo { get; set; }

        [StringLength(30)]
        public string slotnumber { get; set; }
        public int? idboktyp { get; set; }
        public string bookingtypedescription { get; set; }
        public int? idevetyp { get; set; }
        public string eventtypedescription { get; set; }
        [StringLength(30)]
        public string idinternal { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            WorkOrderBookingDTO workOrderBookingDTO = (WorkOrderBookingDTO)obj;
            if (workOrderBookingDTO.idbooking == null || idbooking == null)
            {
                return false;
            }
            return Object.Equals(idbooking, workOrderBookingDTO.idbooking);
        }

        public override int GetHashCode()
        {
            return idbooking.GetHashCode();
        }

        public override string ToString()
        {
            return "WorkOrderBookingDTO{" +
            "id=" + idbooking +
            ", bookingNumber='" + bookingnumber + "'" +
            ", vehicleNumber='" + vehiclenumber + "'" +
            ", dateCreate='" + dtcreate + "'" +
            "}";
        }
    }
}
