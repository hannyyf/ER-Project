namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_order_booking_role")]
    public partial class WorkOrderBookingRole
    {
        [Key]
        [MaxLength(16)]
        public byte[] idrole { get; set; }

        [ForeignKey("WorkOrderBooking")]
        [MaxLength(16)]
        public byte[] idbooking { get; set; }
        public WorkOrderBooking WorkOrderBooking { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }
        
    }
}
