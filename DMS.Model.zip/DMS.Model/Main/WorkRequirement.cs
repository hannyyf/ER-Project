namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_requirement")]
    public partial class WorkRequirement :Requirement
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public work_requirement()
        //{
        //    work_service_requirement = new HashSet<work_service_requirement>();
        //}

        //public virtual Requirement requirement { get; set; }

        //public virtual vehicle_work_requirement vehicle_work_requirement { get; set; } INI juga berelasi idreq

        public ICollection<WorkServiceRequirement> WorkServiceRequirement { get; set; }
    }

    public class WorkRequirementDTO : RequirementDTO
    {
        public override string ToString()
        {
            return "WorkRequirementDTO{" +
            "id=" + idreq +
            "}";
        }
    }
}
