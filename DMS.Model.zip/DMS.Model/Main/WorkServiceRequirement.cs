namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_service_requirement")]
    public partial class WorkServiceRequirement :WorkEffort
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public work_service_requirement()
        //{
        //    work_requirement = new HashSet<work_requirement>();
        //}


        public ICollection<WorkRequirement> WorkRequirement { get; set; }
    }

    public class WorkServiceRequirementDTO : WorkEffortDTO
    {
        [MaxLength(16)]
        public byte[] idbooking { get; set; }

        public override string ToString()
        {
            return "WorkServiceRequirementDTO{" +
            "id=" + idwe +
            "}";
        }
    }
}
