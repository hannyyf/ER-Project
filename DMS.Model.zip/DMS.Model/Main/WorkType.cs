namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("work_type")]
    public partial class WorkType
    {
        [Key]
        public int? idworktype { get; set; }

        [StringLength(50)]
        public string description { get; set; }
    }

    public class WorkTypeDTO
    {
        public int? idworktype { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;

            if (obj == null || obj.GetType() != GetType())
                return false;

            WorkTypeDTO workTypeDTO = (WorkTypeDTO)obj;
            if (workTypeDTO.idworktype == null || idworktype == null)
            {
                return false;
            }
            return Object.Equals(idworktype, workTypeDTO.idworktype);
        }

        public override int GetHashCode()
        {
            return idworktype.GetHashCode();
        }

        public override string ToString()
        {
            return "WorkTypeDTO{" +
            "id=" + idworktype +
            ", description='" + description + "'" +
            "}";
        }

    }

}
