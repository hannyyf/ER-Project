namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("approval")]
    public partial class Approval
    {
        [Key]
        [MaxLength(16)]
        public byte[] idapproval { get; set; }
        
        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        [ForeignKey("ApprovalType")]
        public int? idapptyp { get; set; }
        public ApprovalType ApprovalType { get; set; }

        [ForeignKey("OrderItem")]
        [MaxLength(16)]
        public byte[] idordite { get; set; }
        public OrderItem OrderItem { get; set; }

        [ForeignKey("Requirement")]
        [MaxLength(16)]
        public byte[] idreq { get; set; }
        public Requirement Requirement { get; set; }

        [ForeignKey("StatusType")]
        public int? idstatustype { get; set; }
        public StatusType StatusType { get; set; }


    }
}
