namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("attendance")]
    public partial class Attendance
    {
        [Key]
        public int IdAttendance { get; set; }

        [ForeignKey("Mechanic")]
        [MaxLength(16)]
        public byte[] idparrol { get; set; }
        public Mechanic Mechanic { get; set; }

        public DateTime? DateAttendance { get; set; }

        [Column("Attendance")]
        public bool? Attendance1 { get; set; }

        [StringLength(20)]
        public string AttendInfo { get; set; }

        public bool? Availability { get; set; }

        [StringLength(20)]
        public string AvailInfo { get; set; }

        public bool? Pdi { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        
    }
}
