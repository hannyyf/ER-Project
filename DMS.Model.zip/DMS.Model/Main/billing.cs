namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("billing")]
    public partial class Billing
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public billing()
        //{
        //    billing_item = new HashSet<billing_item>();
        //    billing_role = new HashSet<billing_role>();
        //    billing_status = new HashSet<billing_status>();
        //    memos = new HashSet<memo>();
        //    payment_application = new HashSet<payment_application>();
        //    payments = new HashSet<payment>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idbilling { get; set; }
        
        [StringLength(30)]
        public string billingnumber { get; set; }

        public DateTime? dtcreate { get; set; }

        public int? printcounter { get; set; }

        [ForeignKey("BillingType")]
        public int? idbiltyp { get; set; }
        public BillingType BillingType { get; set; }

        public ICollection<BillingStatus> BillingStatus { get; set; }
        public ICollection<BillingItem> BillingItem { get; set; }
        public ICollection<BillingRole> BillingRole { get; set; }
        public ICollection<Memo> Memos { get; set; }
        public ICollection<PaymentApplication> PaymentApplication { get; set; }
        public ICollection<Payment> Payments { get; set; }


    }
}
