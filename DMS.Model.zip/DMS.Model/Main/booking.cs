namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("booking")]
    public partial class Booking
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public booking()
        //{
        //    queues = new HashSet<queue>();
        //}

        [Key]
        public int IdBooking { get; set; }

        [ForeignKey("BookingStatus")]
        public int? IdBookingStatus { get; set; }
        public BookingStatus BookingStatus { get; set; }

        [Required]
        [StringLength(4)]
        public string NoBooking { get; set; }

        [StringLength(100)]
        public string CustomerName { get; set; }

        [StringLength(20)]
        public string VehicleNumber { get; set; }

        public DateTime? DateBook { get; set; }

        public DateTime? BookingTime { get; set; }

        public DateTime? WaitingLimit { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public ICollection<Queue> Queues { get; set; }
    }
}
