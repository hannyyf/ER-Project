namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("branch")]
    public partial class Branch :_internal
    {

        //Primary key? atau inherit dari?
        [ForeignKey("CategoryParty")]
        public int? idbranchcategory { get; set; }
        public CategoryParty CategoryParty { get; set; }

        //[ForeignKey("_internal")]
        //[StringLength(30)]
        //public string idinternal { get; set; }
        //public _internal _internal { get; set; }

        public ICollection<UnitRequirement> UnitRequirement { get; set; }
    }
}
