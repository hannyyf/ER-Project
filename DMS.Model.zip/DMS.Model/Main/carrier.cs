namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("carrier")]
    public partial class Carrier
    {
        [Key]
        public int IdCarrier { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Person Person { get; set; }

        [ForeignKey("ReasonType")]
        public int? idreason { get; set; }
        public ReasonType ReasonType { get; set; }

        [ForeignKey("RelationType")]
        public int? idreltyp { get; set; }
        public RelationType RelationType { get; set; }
        
    }
}
