namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("category")]
    public partial class Category
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int idcategory { get; set; }

        [ForeignKey("CategoryType")]
        public int? idcattyp { get; set; }
        public CategoryType CategoryType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

    }
}
