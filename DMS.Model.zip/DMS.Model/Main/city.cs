namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("city")]
    public partial class City :GeoBoundary
    {

    }

    public class CityDTO
    {
        [StringLength(36)]
        public string idgeobou { get; set; }

        City city = new City();

        public override string ToString()
        {
            return "City{" +"idGeobou=" + idgeobou +", idGeobou='" + city.idgeobou + "'" +'}';
        }
    }
}
