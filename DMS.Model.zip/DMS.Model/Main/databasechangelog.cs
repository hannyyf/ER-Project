namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("databasechangelog")]
    public partial class databasechangelog
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(765)]
        public string ID { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(765)]
        public string AUTHOR { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(765)]
        public string FILENAME { get; set; }

        [Key]
        [Column(Order = 3)]
        public DateTime DATEEXECUTED { get; set; }

        [Key]
        [Column(Order = 4)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ORDEREXECUTED { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(30)]
        public string EXECTYPE { get; set; }

        [StringLength(105)]
        public string MD5SUM { get; set; }

        [StringLength(765)]
        public string DESCRIPTION { get; set; }

        [StringLength(765)]
        public string COMMENTS { get; set; }

        [StringLength(765)]
        public string TAG { get; set; }

        [StringLength(60)]
        public string LIQUIBASE { get; set; }

        [StringLength(765)]
        public string CONTEXTS { get; set; }

        [StringLength(765)]
        public string LABELS { get; set; }

        [StringLength(30)]
        public string DEPLOYMENT_ID { get; set; }
    }
}
