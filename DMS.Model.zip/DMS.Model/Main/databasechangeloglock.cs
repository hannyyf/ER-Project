namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("databasechangeloglock")]
    public partial class databasechangeloglock
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [Required]
        [StringLength(1)]
        public string LOCKED { get; set; }

        public DateTime? LOCKGRANTED { get; set; }

        [StringLength(765)]
        public string LOCKEDBY { get; set; }
    }
}
