namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("district")]
    public partial class District :GeoBoundary
    {
    }
    public class DistrictDTO
    {
        [StringLength(36)]
        public string idgeobou { get; set; }

        District district = new District();

        public override string ToString()
        {
            return "District{" + "idGeobou=" + idgeobou + ", idGeobou='" + district.idgeobou + "'" + '}';
        }
    }
}
