namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("documents")]
    public partial class Document
    {
        [Key]
        [MaxLength(16)]
        public byte[] iddocument { get; set; }

        [ForeignKey("DocumentType")]
        public int? iddoctype { get; set; }
        public DocumentType DocumentType { get; set; }

        [StringLength(50)]
        public string note { get; set; }

        public DateTime? dtcreate { get; set; }

       // public virtual ProductDocument product_document { get; set; }
    }
}
