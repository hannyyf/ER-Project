namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("driver")]
    public partial class Driver :PartyRole
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public driver()
        //{
        //    shipment_outgoing = new HashSet<shipment_outgoing>();
        //}


        [StringLength(90)]
        public string iddriver { get; set; }

        [StringLength(15)]
        public string external { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        public ICollection<ShipmentOutgoing> ShipmentOutgoing { get; set; }
    }
}
