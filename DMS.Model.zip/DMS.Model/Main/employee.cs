namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("employee")]
    public partial class Employee :PartyRole
    {
        
        [StringLength(30)]
        public string employeeNumber { get; set; }
        
        //public virtual Mechanic mechanic { get; set; }
    }
}
