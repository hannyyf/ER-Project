namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("facility")]
    public partial class Facility
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public facility()
        //{
        //    containers = new HashSet<container>();
        //    facility_status = new HashSet<facility_status>();
        //    facility1 = new HashSet<facility>();
        //    facility_contact_mechanism = new HashSet<facility_contact_mechanism>();
        //    inventory_item = new HashSet<InventoryItem>();
        //    moving_slip = new HashSet<moving_slip>();
        //    moving_slip1 = new HashSet<moving_slip>();
        //    party_facility_purpose = new HashSet<party_facility_purpose>();
        //    prospects = new HashSet<prospect>();
        //    requirements = new HashSet<Requirement>();
        //    shipments = new HashSet<shipment>();
        //    work_effort = new HashSet<work_effort>();
        //    contact_mechanism = new HashSet<contact_mechanism>();
        //    parties = new HashSet<Party>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }

        [ForeignKey("FacilityType")]
        public int? idfacilitytype { get; set; }
        public FacilityType FacilityType { get; set; }

        [ForeignKey("FacilityParrent")]
        [MaxLength(16)]
        public byte[] idpartof { get; set; }
        public Facility FacilityParrent { get; set; }

        [ForeignKey("FixedAsset")]
        public int? idfa { get; set; }
        public FixedAsset FixedAsset { get; set; }

        [StringLength(30)]
        public string code { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<Container> Containers { get; set; }

        public ICollection<FacilityStatus> FacilityStatus { get; set; }

        public ICollection<Facility> FacilityParrentss { get; set; }

        public ICollection<FacilityContactMechanism> FacilityContactMechanism { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }

        public ICollection<MovingSlip> MovingSlip { get; set; }

        public ICollection<MovingSlip> MovingSlip1 { get; set; }

        public ICollection<PartyFacilityPurpose> PartyFacilityPurpose { get; set; }

        public ICollection<Prospect> Prospects { get; set; }

        public ICollection<Requirement> Requirement { get; set; }

        public ICollection<Shipment> Shipments { get; set; }

        public ICollection<WorkEffort> WorkEffort { get; set; }

        public ICollection<ContactMechanism> ContactMechanism { get; set; }

        public ICollection<Party> Parties { get; set; }
    }
}
