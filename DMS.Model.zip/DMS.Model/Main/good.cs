namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("good")]
    public partial class Good :Product
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public good()
        //{
        //    good_container = new HashSet<good_container>();
        //    inventory_item = new HashSet<InventoryItem>();
        //    moving_slip = new HashSet<moving_slip>();
        //    pkb_part = new HashSet<pkb_part>();
        //    shipment_item = new HashSet<shipment_item>();
        //    shipment_receipt = new HashSet<shipment_receipt>();
        //    vehicles = new HashSet<Vehicle>();
        //    we_type_good_standard = new HashSet<we_type_good_standard>();
        //}

        [ForeignKey("Uom")]
        [StringLength(30)]
        public string iduom { get; set; }
        public virtual Uom Uom { get; set; }

        //public virtual Motor motor { get; set; }
        //public virtual rem_part rem_part { get; set; }

        public ICollection<GoodContainer> GoodContainer { get; set; }

        public ICollection<InventoryItem> InventoryItem { get; set; }

        public ICollection<MovingSlip> MovingSlip { get; set; }

        public ICollection<PkbPart> PkbPart { get; set; }

        public ICollection<ShipmentItem> ShipmentItem { get; set; }

        public ICollection<ShipmentReceipt> ShipmentReceipt { get; set; }

        public ICollection<Vehicle> Vehicle { get; set; }

        public ICollection<WeTypeGoodStandard> WeTypeGoodStandard { get; set; }
    }
}
