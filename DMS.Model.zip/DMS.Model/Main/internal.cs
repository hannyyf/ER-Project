namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("internal")]
    public partial class _internal
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public _internal()
        //{
        //    billing_disbursement = new HashSet<billing_disbursement>();
        //    billing_receipt = new HashSet<BillingReceipt>();
        //    booking_slot_standard = new HashSet<booking_slot_standard>();
        //    communication_event_delivery = new HashSet<communication_event_delivery>();
        //    customer_order = new HashSet<customer_order>();
        //    customer_quotation = new HashSet<customer_quotation>();
        //    customer_relationship = new HashSet<customer_relationship>();
        //    disbursements = new HashSet<disbursement>();
        //    good_container = new HashSet<good_container>();
        //    internal_order = new HashSet<internal_order>();
        //    internal_order1 = new HashSet<internal_order>();
        //    memos = new HashSet<memo>();
        //    positions = new HashSet<position>();
        //    prospects = new HashSet<prospect>();
        //    purchase_request = new HashSet<purchase_request>();
        //    receipts = new HashSet<receipt>();
        //    rule_indent = new HashSet<rule_indent>();
        //    sales_agreement = new HashSet<sales_agreement>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    service_agreement = new HashSet<service_agreement>();
        //    shipment_package = new HashSet<shipment_package>();
        //    standard_calendar = new HashSet<standard_calendar>();
        //    suspects = new HashSet<suspect>();
        //    user_mediator = new HashSet<user_mediator>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    vehicles = new HashSet<vehicle>();
        //    vendor_order = new HashSet<vendor_order>();
        //    vendor_product = new HashSet<vendor_product>();
        //    vendor_relationship = new HashSet<vendor_relationship>();
        //    work_order_booking = new HashSet<work_order_booking>();
        //}

        [Key]
        [StringLength(30)]
        public string idinternal { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [ForeignKey("Organization")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public virtual Organization Organization { get; set; }

        [StringLength(5)]
        public string selfsender { get; set; }

        //public virtual Branch branch { get; set; }
       
        //public virtual SalesPoint SalesPoint { get; set; }


        public ICollection<Vehicle> Vehicles { get; set; }
        public ICollection<SalesAgreement> SalesAgreements { get; set; }
        public ICollection<ServiceAgreement> ServiceAgreements { get; set; }
        public ICollection<BillingDisbursement>BillingDisbursement{ get; set; }
        public ICollection<BillingReceipt>BillingReceipt{ get; set; }
        public ICollection<BookingSlotStandard>BookingSlotStandard{ get; set; }
        public ICollection<CommunicationEventDelivery>CommunicationEventDelivery{ get; set; }
        public ICollection<CustomerOrder>CustomerOrder{ get; set; }
        public ICollection<CustomerQuotation>CustomerQuotation{ get; set; }
        public ICollection<CustomerRelationship>CustomerRelationship{ get; set; }
        public ICollection<Disbursement>Disbursement{ get; set; }
        public ICollection<GoodContainer>GoodContainer{ get; set; }
        public ICollection<InternalOrder>InternalOrder{ get; set; }
        public ICollection<InternalOrder>InternalOrder1{ get; set; }
        public ICollection<Memo>Memos{ get; set; }
        public ICollection<Position>Positions{ get; set; }
        public ICollection<Prospect>Prospects{ get; set; }
        public ICollection<PurchaseRequest>PurchaseRequest{ get; set; }
        public ICollection<Receipt>Reicipt{ get; set; }
        public ICollection<RuleIndent>RuleIndent{ get; set; }
        public ICollection<SalesUnitRequirement>SalesUnitRequirement{ get; set; }
        public ICollection<ShipmentPackage>ShipmentPackage{ get; set; }
        public ICollection<StandardCalendar>StandardCalendar{ get; set; }
        public ICollection<Suspect>Suspects{ get; set; }
        public ICollection<UserMediator>UserMediator{ get; set; }
        public ICollection<VehicleDocumentRequirement>VehicleDocumentRequirement{ get; set; }
        public ICollection<VendorOrder>VendorOrder{ get; set; }
        public ICollection<VendorProduct>VendorProduct{ get; set; }
        public ICollection<VendorRelationship>VendorRelatioship{ get; set; }
        public ICollection<WorkOrderBooking>WorkOrderBooking{ get; set; }
}
}
