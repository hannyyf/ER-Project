namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("job")]
    public partial class Job
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public job()
        //{
        //    job_history = new HashSet<job_history>();
        //    job_service = new HashSet<job_service>();
        //    summaries = new HashSet<summary>();
        //}

        [Key]
        public int IdJob { get; set; }

        [ForeignKey("Pkb")]
        public int? IdPkb { get; set; }
        public Pkb Pkb { get; set; }

        [ForeignKey("JobStatus")]
        public int? IdJobStatus { get; set; }
        public JobStatus JobStatus { get; set; }

        [ForeignKey("Mechanic")]
        [MaxLength(16)]
        public byte[] idparrol { get; set; }
        public Mechanic Mechanic { get; set; }

        public DateTime? StartTime { get; set; }

        [StringLength(255)]
        public string Complaint { get; set; }

        [StringLength(255)]
        public string JobSuggest { get; set; }

        public int? Duration { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }
        
        public ICollection<JobHistory> JobHistory { get; set; }

        public ICollection<JobService> JobService { get; set; }

        public ICollection<Summary> Summaries { get; set; }
    }
}
