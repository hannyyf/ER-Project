namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("mechanic")]
    public partial class Mechanic :Employee
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public mechanic()
        //{
        //    attendances = new HashSet<Attendance>();
        //    jobs = new HashSet<job>();
        //    job_history = new HashSet<job_history>();
        //    vehicle_work_requirement = new HashSet<vehicle_work_requirement>();
        //}
        
        [StringLength(90)]
        public string idmechanic { get; set; }

        [StringLength(5)]
        public string external { get; set; }

        [ForeignKey("Vendor")]
        [StringLength(30)]
        public string idvendor { get; set; }
        public Vendor Vendor { get; set; }

        [Column(TypeName = "image")]
        public byte[] photo { get; set; }

        [StringLength(30)]
        public string password { get; set; }

        public ICollection<Attendance> Attendance { get; set; }

        public ICollection<Job> Job { get; set; }

        public ICollection<JobHistory> JobHistory { get; set; }
        
        public ICollection<VehicleWorkRequirement> VehicleWorkRequirement { get; set; }
    }
}
