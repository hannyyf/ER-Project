namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("motor")]
    public partial class Motor:Good
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public motor()
        //{
        //    communication_event_prospect = new HashSet<CommunicationEventProspect>();
        //    leasing_tenor_provide = new HashSet<leasing_tenor_provide>();
        //    motor_due_reminder = new HashSet<motor_due_reminder>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //    unit_accesories_mapper = new HashSet<unit_accesories_mapper>();
        //    unit_requirement = new HashSet<unit_requirement>();
        //}

        public ICollection<CommunicationEventProspect> CommunicationEventProspect { get; set; }

        public ICollection<LeasingTenorProvide> LeasingTenorProvide { get; set; }

        public ICollection<MotorDueReminder> MotorDueReminder { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public ICollection<UnitAccesoriesMapper> UnitAccesoriesMapper { get; set; }

        public ICollection<UnitRequirement> UnitRequirement { get; set; }
    }
}
