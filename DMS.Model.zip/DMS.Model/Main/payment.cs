namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("payment")]
    public partial class Payment
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public payment()
        //{
        //    payment_status = new HashSet<payment_status>();
        //    payment_application = new HashSet<payment_application>();
        //    payment_role = new HashSet<payment_role>();
        //    billings = new HashSet<Billing>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idpayment { get; set; }

        [ForeignKey("PaymentType")]
        public int? idpaytyp { get; set; }
        public PaymentType PaymentType { get; set; }

        [ForeignKey("PaymentMethodType")]
        public int? idpaymettyp { get; set; }
        public PaymentMethodType PaymentMethodType { get; set; }

        [StringLength(90)]
        public string paymentnumber { get; set; }

        public DateTime? dtcreate { get; set; }

        public decimal? amount { get; set; }

        [StringLength(90)]
        public string refno { get; set; }

        //public virtual Disbursement disbursement { get; set; }
        //public virtual receipt receipt { get; set; }

        public ICollection<PaymentStatus> PaymentStatus { get; set; }

        public ICollection<PaymentApplication> PaymentApplication { get; set; }

        public ICollection<PaymentRole> PaymentRole { get; set; }

        public ICollection<Billing> Billings { get; set; }
    }
}
