namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("person")]
    public partial class Person :Party
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public person()
        //{
        //    carriers = new HashSet<Carrier>();
        //    organizations = new HashSet<Organization>();
        //    organization_prospect = new HashSet<OrganizationProspect>();
        //    person_prospect = new HashSet<person_prospect>();
        //    person_suspect = new HashSet<person_suspect>();
        //    PersonSosmeds = new HashSet<PersonSosmed>();
        //    position_fullfillment = new HashSet<position_fullfillment>();
        //    suspects = new HashSet<suspect>();
        //    user_mediator = new HashSet<user_mediator>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //}

        [StringLength(30)]
        public string fname { get; set; }

        [StringLength(30)]
        public string lname { get; set; }

        [StringLength(30)]
        public string pob { get; set; }

        [Column(TypeName = "date")]
        public DateTime? dtob { get; set; }

        [StringLength(10)]
        public string bloodtype { get; set; }

        [StringLength(1)]
        public string gender { get; set; }

        [StringLength(30)]
        public string personalidnumber { get; set; }

        [StringLength(30)]
        public string familyidnumber { get; set; }

        [StringLength(30)]
        public string taxidnumber { get; set; }

        public int? idreligiontype { get; set; }

        public int? idworktype { get; set; }

        [StringLength(50)]
        public string cellphone1 { get; set; }

        [StringLength(50)]
        public string cellphone2 { get; set; }

        [StringLength(50)]
        public string privatemail { get; set; }

        [StringLength(50)]
        public string phone { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        public ICollection<Carrier> Carrier { get; set; }

        public ICollection<Organization> Organization { get; set; }

        public ICollection<OrganizationProspect> OrganizationProspect { get; set; }

        public ICollection<PersonProspect> PersonProspect { get; set; }

        public ICollection<PersonSuspect> PersonSuspect { get; set; }

        public ICollection<PersonSosmed> PersonSosmed { get; set; }

        public ICollection<PositionFullfillment> PositionFullfillment { get; set; }

        public ICollection<Suspect> Suspects { get; set; }

        public ICollection<UserMediator> UserMediator { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }
    }
}
