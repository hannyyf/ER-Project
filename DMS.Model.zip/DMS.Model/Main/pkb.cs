namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("pkb")]
    public partial class Pkb
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public pkb()
        //{
        //    jobs = new HashSet<job>();
        //    pkb_service = new HashSet<pkb_service>();
        //}

        [Key]
        public int IdPkb { get; set; }

        [ForeignKey("StatusPkbInternal")]
        public int? IdStatusPkbInternal { get; set; }
        public StatusPkb StatusPkbInternal { get; set; }

        [ForeignKey("StatusPkbCust")]
        public int? IdStatusPkbCust { get; set; }
        public StatusPkb StatusPkbCust { get; set; }

        [ForeignKey("Customer")]
        [StringLength(30)]
        public string idcustomer { get; set; }
        public Customer Customer { get; set; }

        [ForeignKey("Queue")]
        public int? IdQueue { get; set; }
        public Queue Queue { get; set; }

        [ForeignKey("Vehicle")]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }
        public Vehicle Vehicle { get; set; }

        [ForeignKey("PaymentMethodType")]
        public int? idpaymettyp { get; set; }
        public PaymentMethodType PaymentMethodType { get; set; }

        [ForeignKey("TypePkb")]
        public int? IdTypePkb { get; set; }
        public TypePkb TypePkb { get; set; }

        [Required]
        [StringLength(15)]
        public string NoPkb { get; set; }

        public DateTime? PkbDate { get; set; }

        [StringLength(50)]
        public string Lamentation { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public decimal? SubTotalPart { get; set; }

        public decimal? SubTotalService { get; set; }

        public ICollection<Job> Job { get; set; }

        

        //public virtual pkb_estimation pkb_estimation { get; set; }
        public ICollection<PkbService> PkbService { get; set; }
    }
}
