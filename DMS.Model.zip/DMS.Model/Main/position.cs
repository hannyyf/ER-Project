namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("position")]  
    public partial class Position
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public position()
        //{
        //    position_fullfillment = new HashSet<position_fullfillment>();
        //    position_reporting_structure = new HashSet<position_reporting_structure>();
        //    position_reporting_structure1 = new HashSet<position_reporting_structure>();
        //    positions_status = new HashSet<positions_status>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idposition { get; set; }

        [ForeignKey("PositionType")]
        public int? idpostyp { get; set; }
        public PositionType PositionType { get; set; }

        [ForeignKey("Organization")]
        [MaxLength(16)]
        public byte[] idorganization { get; set; }
        public Organization Organization { get; set; }

        [ForeignKey("UserMediator")]
        [MaxLength(16)]
        public byte[] idusrmed { get; set; }
        public UserMediator UserMediator { get; set; }

        public int? seqnum { get; set; }

        [StringLength(30)]
        public string username { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        public ICollection<PositionFullfillment> PositionFullfillment { get; set; }

        public ICollection<PositionReportingStructure> PositionReportingStructure { get; set; }

        public ICollection<PositionReportingStructure> PositionReportingStructure1 { get; set; }

        public ICollection<PositionsStatus> PositionsStatus { get; set; }
        
    }
}
