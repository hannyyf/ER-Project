namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("product")]
    public partial class Product
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Product()
        //{
        //    billing_item = new HashSet<BillingItem>();
        //    order_item = new HashSet<OrderItem>();
        //    price_agreement_item = new HashSet<price_agreement_item>();
        //    price_component = new HashSet<PriceComponent>();
        //    product_association = new HashSet<product_association>();
        //    product_association1 = new HashSet<product_association>();
        //    product_document = new HashSet<product_document>();
        //    purchase_request = new HashSet<purchase_request>();
        //    quote_item = new HashSet<quote_item>();
        //    rule_hot_item = new HashSet<rule_hot_item>();
        //    rule_indent = new HashSet<rule_indent>();
        //    vendor_product = new HashSet<vendor_product>();
        //    category_product = new HashSet<category_product>();
        //    features = new HashSet<Feature>();
        //}

        [Key]
        [StringLength(30)]
        public string idproduct { get; set; }

        [ForeignKey("ProductType")]
        public int? idprotyp { get; set; }
        public ProductType ProductType { get; set; }

        [StringLength(90)]
        public string name { get; set; }

        public DateTime? dtintroduction { get; set; }

        [StringLength(600)]
        public string description { get; set; }

        //public virtual good Good { get; set; }
        //public virtual service Service { get; set; }

        public ICollection<PriceComponent> PriceComponents { get; set; }
        public ICollection<PriceAgreementItem> PriceAgreementItem { get; set; }
        public ICollection<OrderItem> OrderItem { get; set; }
        public ICollection<ProductAssociation> ProductAssociation { get; set; }
        public ICollection<ProductAssociation> ProductAssociation1 { get; set; }
        public ICollection<ProductDocument> ProductDocuments { get; set; }
        public ICollection<PurchaseRequest> PurchaseRequest { get; set; }
        public ICollection<QuoteItem> QuoteItems { get; set; }
        public ICollection<RuleHotItem> RuleHotItems { get; set; }
        public ICollection<RuleIndent> RuleIndent { get; set; }
        public ICollection<VendorProduct> VendorProduct { get; set; }
        public ICollection<CategoryProduct> CategoryProduct { get; set; }
        public ICollection<Feature> Feature { get; set; }

}
}
