namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("prospect")]
    public partial class Prospect
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public prospect()
        //{
        //    communication_event_prospect = new HashSet<CommunicationEventProspect>();
        //    prospect_status = new HashSet<prospect_status>();
        //    prospect_role = new HashSet<prospect_role>();
        //    sales_unit_requirement = new HashSet<sales_unit_requirement>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idprospect { get; set; }

        [ForeignKey("SalesBroker")]
        [MaxLength(16)]
        public byte[] idbroker { get; set; }
        public SalesBroker SalesBroker { get; set; }

        [ForeignKey("ProspectSource")]
        public int? idprosou { get; set; }
        public ProspectSources ProspectSource { get; set; }

        [ForeignKey("EventType")]
        public int? idevetyp { get; set; }
        public EventType EventType { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("Salesman")]
        [MaxLength(16)]
        public byte[] idsalesman { get; set; }
        public Salesman Salesman { get; set; }

        [ForeignKey("Suspect")]
        [MaxLength(16)]
        public byte[] idsuspect { get; set; }
        public Suspect Suspect { get; set; }

        [ForeignKey("SalesmanCoordinator")]
        [MaxLength(16)]
        public byte[] idsalescoordinator { get; set; }
        public Salesman SalesmanCoordinator { get; set; }

        [StringLength(30)]
        public string prospectnumber { get; set; }

        public int? prospectcount { get; set; }

        [StringLength(600)]
        public string eveloc { get; set; }

        public DateTime? dtfollowup { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        //public virtual OrganizationProspect organization_prospect { get; set; }

        //public virtual PersonProspect person_prospect { get; set; }

        public ICollection<CommunicationEventProspect> CommunicationEventProspect { get; set; }

        public ICollection<ProspectStatus> ProspectStatus { get; set; }

        public ICollection<ProspectRole> ProspectRole { get; set; }

        public ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }
    }
}
