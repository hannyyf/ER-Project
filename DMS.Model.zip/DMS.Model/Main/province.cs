namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("province")]
    public partial class Province :GeoBoundary
    {
    }
    public class ProvincetDTO
    {
        [StringLength(36)]
        public string idgeobou { get; set; }

        Province province = new Province();

        public override string ToString()
        {
            return "Province{" + "idGeobou=" + idgeobou + ", idGeobou='" + province.idgeobou + "'" + '}';
        }
    }
}
