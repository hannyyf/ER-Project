namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("queue")]
    public partial class Queue
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public queue()
        //{
        //    pkbs = new HashSet<Pkb>();
        //}

        [Key]
        public int IdQueue { get; set; }

        [ForeignKey("QueueStatus")]
        public int? IdQueueStatus { get; set; }
        public QueueStatus QueueStatus { get; set; }

        [ForeignKey("QueueType")]
        public int? IdQueueType { get; set; }
        public QueueType QueueType { get; set; }

        [ForeignKey("Booking")]
        public int? IdBooking { get; set; }
        public Booking Booking { get; set; }

        [Required]
        [StringLength(10)]
        public string NoQueue { get; set; }

        [StringLength(100)]
        public string CustomerName { get; set; }

        [StringLength(20)]
        public string VehicleNumber { get; set; }

        public DateTime? DateQueue { get; set; }

        public int? WaitingDuration { get; set; }

        public bool? IsMissed { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }

        public ICollection<Pkb> Pkbs { get; set; }
        
    }
}
