namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("quote")]
    public partial class Quote
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public quote()
        //{
        //    quote_item = new HashSet<quote_item>();
        //    quote_role = new HashSet<quote_role>();
        //    quote_status = new HashSet<quote_status>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idquote { get; set; }

        public DateTime? dtissued { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        //public virtual CustomerQuotation customer_quotation { get; set; }

        public ICollection<QuoteItem> quote_item { get; set; }

        public ICollection<QuoteRole> quote_role { get; set; }

        public ICollection<QuoteStatus> quote_status { get; set; }
    }
}
