namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("receipt")]
    public partial class Receipt :Payment
    {
        [ForeignKey("Requirement")]
        [MaxLength(16)]
        public byte[] idreq { get; set; }
        public Requirement Requirement { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("BillTo")]
        [StringLength(30)]
        public string idbillto { get; set; }
        public BillTo BillTo { get; set; }

        
    }
}
