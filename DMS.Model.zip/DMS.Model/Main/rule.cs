namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("rule")]
    public partial class Rule
    {
        [Key]
        public int idrule { get; set; }

        [ForeignKey("RuleType")]
        public int? idrultyp { get; set; }
        public RuleType RuleType { get; set; }

        public int? seqnum { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtfrom { get; set; }

        public DateTime? dtthru { get; set; }

        //public virtual RuleHotItem rule_hot_item { get; set; }

        //public virtual RuleIndent rule_indent { get; set; }

        //public virtual RuleSalesDiscount rule_sales_discount { get; set; }

        
    }
}
