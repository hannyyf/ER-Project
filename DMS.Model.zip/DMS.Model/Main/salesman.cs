namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("salesman")]
    public partial class Salesman:PartyRole
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public salesman()
        //{
        //    prospects = new HashSet<Prospect>();
        //    prospects1 = new HashSet<Prospect>();
        //    sales_unit_requirement = new HashSet<SalesUnitRequirement>();
        //    salesman1 = new HashSet<salesman>();
        //    suspects = new HashSet<suspect>();
        //    suspects1 = new HashSet<suspect>();
        //}
        
        [ForeignKey("SalesmanCoordinator")]
        [MaxLength(16)]
        public byte[] idcoordinator { get; set; }
        public Salesman SalesmanCoordinator { get; set; }

        [StringLength(90)]
        public string idsalesman { get; set; }

        [StringLength(15)]
        public string coordinator { get; set; }

        [MaxLength(16)]
        public byte[] idteamleader { get; set; }

        [StringLength(5)]
        public string teamleader { get; set; }

        public virtual ICollection<Prospect> Prospect { get; set; }

        public virtual ICollection<Prospect> Prospect2 { get; set; }

        public virtual ICollection<SalesUnitRequirement> SalesUnitRequirement { get; set; }

        public virtual ICollection<Salesman> Salesman1 { get; set; }

        public virtual ICollection<Suspect> Suspects { get; set; }

        public virtual ICollection<Suspect> Suspects1 { get; set; }
    }
}
