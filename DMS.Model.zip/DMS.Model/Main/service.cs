namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("service")]
    public partial class Service :Product
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public service()
        //{
        //    job_service = new HashSet<JobService>();
        //    pkb_service = new HashSet<PkbService>();
        //    we_service_type = new HashSet<we_service_type>();
        //}

        [ForeignKey("Uom")]
        [StringLength(30)]
        public string iduom { get; set; }
        public Uom Uom { get; set; }

        public decimal? frt { get; set; }

        [StringLength(50)]
        public string servicecode { get; set; }

        public virtual ICollection<JobService> JobService { get; set; }

        public virtual ICollection<PkbService> PkbService { get; set; }

        //public virtual service_per_motor service_per_motor { get; set; }

        public virtual ICollection<WeServiceType> WeServiceType { get; set; }
    }
}
