namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("shipment")]
    public partial class Shipment
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public shipment()
        //{
        //    shipment_status = new HashSet<shipment_status>();
        //    shipment_item = new HashSet<shipment_item>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idshipment { get; set; }

        [ForeignKey("ShipmentType")]
        public int? idshityp { get; set; }
        public ShipmentType ShipmentType { get; set; }

        [ForeignKey("Facility")]
        [MaxLength(16)]
        public byte[] idfacility { get; set; }
        public Facility Facility { get; set; }

        [ForeignKey("PostalAddressFrom")]
        [MaxLength(16)]
        public byte[] idposaddfro { get; set; }
        public PostalAddress PostalAddressFrom { get; set; }

        [ForeignKey("PostalAddressTo")]
        [MaxLength(16)]
        public byte[] idposaddto { get; set; }
        public PostalAddress PostalAddressTo { get; set; }

        [ForeignKey("ShipTo")]
        [StringLength(30)]
        public string idshito { get; set; }
        public ShipTo ShipTo { get; set; }

        [ForeignKey("ShipFro")]
        [StringLength(30)]
        public string idshifro { get; set; }
        public ShipTo ShipFro { get; set; }

        [StringLength(30)]
        public string shipmentnumber { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public DateTime? dtschedulle { get; set; }

        [StringLength(300)]
        public string reason { get; set; }

        public ICollection<ShipmentStatus> ShipmentStatus { get; set; }

        public ICollection<ShipmentItem> ShipmentItem { get; set; }

        //public virtual shipment_outgoing shipment_outgoing { get; set; }
        //public virtual shipment_incoming shipment_incoming { get; set; }
    }
}
