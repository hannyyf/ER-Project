namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("summary")]
    public partial class Summary
    {
        [Key]
        public int IdSummary { get; set; }

        [ForeignKey("Job")]
        public int? IdJob { get; set; }
        public Job Job { get; set; }

        [ForeignKey("CategoryProduct")]
        public int? idcategory { get; set; }
        public CategoryProduct CategoryProduct { get; set; }

        public int? TotalUnit { get; set; }

        public int? ServiceQty { get; set; }

        [Column(TypeName = "money")]
        public decimal? NjbMechanic { get; set; }

        [Column(TypeName = "money")]
        public decimal? NscMechanic { get; set; }

        [Column(TypeName = "money")]
        public decimal? TotalNjbMec { get; set; }

        [Column(TypeName = "money")]
        public decimal? TotalNscMec { get; set; }

        [Column(TypeName = "date")]
        public DateTime? LastModifiedDate { get; set; }

        public int? LastModifiedUserId { get; set; }

        public int? StatusCode { get; set; }
        
    }
}
