namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("suspect")]
    public partial class Suspect
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public suspect()
        //{
        //    prospects = new HashSet<Prospect>();
        //    suspect_status = new HashSet<suspect_status>();
        //    suspect_role = new HashSet<suspect_role>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idsuspect { get; set; }

        [StringLength(90)]
        public string suspectnumber { get; set; }

        [ForeignKey("Person")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Person Person { get; set; }

        [ForeignKey("SalesmanCoordinator")]
        [MaxLength(16)]
        public byte[] idsalescoordinator { get; set; }
        public Salesman SalesmanCoordinator { get; set; }

        [ForeignKey("Salesman")]
        [MaxLength(16)]
        public byte[] idsalesman { get; set; }
        public Salesman Salesman { get; set; }

        [ForeignKey("PostalAddress")]
        [MaxLength(16)]
        public byte[] idaddress { get; set; }
        public PostalAddress PostalAddress { get; set; }

        [ForeignKey("SuspectType")]
        public int? idsuspecttyp { get; set; }
        public SuspectType SuspectType { get; set; }

        [StringLength(6)]
        public string salesdt { get; set; }

        [StringLength(300)]
        public string marketname { get; set; }

        public decimal? repurchaseprob { get; set; }

        public decimal? priority { get; set; }

        public int? idsaletype { get; set; }

        [MaxLength(16)]
        public byte[] idlsgpro { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        //public virtual OrganizationSuspect organization_suspect { get; set; }

        //public virtual PersonSuspect person_suspect { get; set; }

        public ICollection<Prospect> Prospect { get; set; }

        public ICollection<SuspectStatus> SuspectStatus { get; set; }

        public ICollection<SuspectRole> SuspectRole { get; set; }

        
    }
}
