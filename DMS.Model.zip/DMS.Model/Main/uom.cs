namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("uom")]
    public partial class Uom
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Uom()
        //{
        //    fixed_asset = new HashSet<fixed_asset>();
        //    goods = new HashSet<good>();
        //    services = new HashSet<service>();
        //    uom_conversion = new HashSet<uom_conversion>();
        //    uom_conversion1 = new HashSet<uom_conversion>();
        //}

        [Key]
        [StringLength(30)]
        public string iduom { get; set; }

        [ForeignKey("UomType")]
        public int? iduomtyp { get; set; }
        public UomType UomType { get; set; }

        [StringLength(50)]
        public string description { get; set; }

        public ICollection<FixedAsset> FixedAsset { get; set; }

        public ICollection<Good> Goods { get; set; }

        public ICollection<Service> Services { get; set; }

        public ICollection<UomConversion> UomConversion { get; set; }

        public ICollection<UomConversion> UomConversion1 { get; set; }

    }
}
