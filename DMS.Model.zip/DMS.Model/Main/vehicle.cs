namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vehicle")]
    public partial class Vehicle
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Vehicle()
        //{
        //    agreement_motor_item = new HashSet<AgreementMotorItem>();
        //    carriers = new HashSet<carrier>();
        //    pkbs = new HashSet<pkb>();
        //    vehicle_service_history = new HashSet<vehicle_service_history>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    vehicle_identification = new HashSet<vehicle_identification>();
        //    vehicle_work_requirement = new HashSet<vehicle_work_requirement>();
        //    work_order_booking = new HashSet<work_order_booking>();
        //}

        [Key]
        [MaxLength(16)]
        public byte[] idvehicle { get; set; }

        [ForeignKey("Good")]
        [StringLength(30)]
        public string idproduct { get; set; }
        public Good Good { get; set; }

        [ForeignKey("Feature")]
        public int? idcolor { get; set; }
        public Feature Feature { get; set; } 

        [StringLength(50)]
        public string idmachine { get; set; }
        
        [StringLength(50)]
        public string idframe { get; set; }

        public int? yearofass { get; set; }

        [ForeignKey("Internal")]
        [StringLength(30)]
        public string idinternal { get; set; }
        public _internal Internal { get; set; }

        [ForeignKey("VehicleType")]
        public int? IdVehicleType { get; set; }
        public VehicleType VehicleType { get; set; }

        [StringLength(30)]
        public string fuel { get; set; }

        [StringLength(50)]
        public string merkoil { get; set; }

        [StringLength(50)]
        public string ServiceBookNumber { get; set; }

        


        public ICollection<AgreementMotorItem> AgreementMotorItem { get; set; }
        public ICollection<Pkb> Pkb { get; set; }
        public ICollection<VehicleServiceHistory> VehicleServiceHistory { get; set; }
        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }
        public ICollection<VehicleIdentification> VehicleIdentification { get; set; }
        public ICollection<VehicleWorkRequirement> VehicleWorkRequirement { get; set; }
        public ICollection<WorkOrderBooking> WorkOrderBooking { get; set; }
}
}
