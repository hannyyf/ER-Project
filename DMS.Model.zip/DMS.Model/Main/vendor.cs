namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("vendor")]
    public partial class Vendor
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        //public Vendor()
        //{
        //    billing_disbursement = new HashSet<BillingDisbursement>();
        //    drivers = new HashSet<driver>();
        //    mechanics = new HashSet<mechanic>();
        //    POes = new HashSet<PO>();
        //    vehicle_document_requirement = new HashSet<vehicle_document_requirement>();
        //    vendor_order = new HashSet<vendor_order>();
        //    vendor_product = new HashSet<vendor_product>();
        //    vendor_relationship = new HashSet<vendor_relationship>();
        //}

        [Key]
        [StringLength(30)]
        public string idvendor { get; set; }

        [ForeignKey("VendorType")]
        public int? idvndtyp { get; set; }
        public VendorType VendorType { get; set; }

        [ForeignKey("RoleType")]
        public int? idroletype { get; set; }
        public RoleType RoleType { get; set; }

        [ForeignKey("Party")]
        [MaxLength(16)]
        public byte[] idparty { get; set; }
        public Party Party { get; set; }

        //public virtual organization organization { get; set; }

        public ICollection<BillingDisbursement> BillingDisbursement { get; set; }

        public ICollection<Driver> Drivers { get; set; }

        public ICollection<Mechanic> Mechanics { get; set; }

        public ICollection<PO> POes { get; set; }

        public ICollection<VehicleDocumentRequirement> VehicleDocumentRequirement { get; set; }

        public ICollection<VendorOrder> VendorOrder { get; set; }

        public ICollection<VendorProduct> VendorProduct { get; set; }

        public ICollection<VendorRelationship> VendorRelationship { get; set; }

        
    }
}
