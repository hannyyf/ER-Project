namespace DMS.Model.Main
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("village")]
    public partial class Village :GeoBoundary
    {

    }
    public class VillageDTO
    {
        [StringLength(36)]
        public string idgeobou { get; set; }

        Village village = new Village();

        public override string ToString()
        {
            return "Village{" + "idGeobou=" + idgeobou + ", idGeobou='" + village.idgeobou + "'" + '}';
        }
    }
}
